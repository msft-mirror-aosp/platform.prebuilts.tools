## <a name="cla"></a> Signing the CLA

Please sign the [Google Contributor License Agreement
(CLA)](https://cla.developers.google.com/)
before sending pull requests. For any code changes to be
accepted, the CLA must be signed. It's a quick process, I
promise!
