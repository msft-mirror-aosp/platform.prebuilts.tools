/*
 * Copyright 2010-2026 JetBrains s.r.o. and Kotlin Programming Language contributors.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the license/LICENSE.txt file.
 */

package org.jetbrains.kotlin.analysis.api.descriptors.symbols.descriptorBased

import com.intellij.psi.PsiElement
import org.jetbrains.kotlin.analysis.api.annotations.KaAnnotationList
import org.jetbrains.kotlin.analysis.api.descriptors.Fe10AnalysisContext
import org.jetbrains.kotlin.analysis.api.descriptors.symbols.base.KaFe10Symbol
import org.jetbrains.kotlin.analysis.api.descriptors.symbols.calculateHashCode
import org.jetbrains.kotlin.analysis.api.descriptors.symbols.descriptorBased.base.*
import org.jetbrains.kotlin.analysis.api.descriptors.symbols.isEqualTo
import org.jetbrains.kotlin.analysis.api.descriptors.symbols.pointers.KaFe10NeverRestoringSymbolPointer
import org.jetbrains.kotlin.analysis.api.descriptors.utils.cached
import org.jetbrains.kotlin.analysis.api.impl.base.annotations.KaBaseEmptyAnnotationList
import org.jetbrains.kotlin.analysis.api.lifetime.withValidityAssertion
import org.jetbrains.kotlin.analysis.api.symbols.*
import org.jetbrains.kotlin.analysis.api.symbols.pointers.KaSymbolPointer
import org.jetbrains.kotlin.analysis.api.types.KaType
import org.jetbrains.kotlin.descriptors.PropertyDescriptor
import org.jetbrains.kotlin.descriptors.ValueParameterDescriptor
import org.jetbrains.kotlin.descriptors.Visibilities
import org.jetbrains.kotlin.descriptors.Visibility
import org.jetbrains.kotlin.name.CallableId
import org.jetbrains.kotlin.name.Name
import org.jetbrains.kotlin.resolve.descriptorUtil.isEffectivelyExternal

internal class KaFe10DescDefaultPropertySetterSymbol(
    private val propertyDescriptor: PropertyDescriptor,
    override val analysisContext: Fe10AnalysisContext,
) : KaPropertySetterSymbol(), KaFe10Symbol {
    override val parameter: KaValueParameterSymbol by cached {
        KaDefaultValueParameterSymbol(propertyDescriptor, analysisContext)
    }

    override val isNotDefault: Boolean
        get() = withValidityAssertion { false }

    @Deprecated("Use `!isNotDefault` instead", replaceWith = ReplaceWith("!isNotDefault"))
    override val isDefault: Boolean
        get() = withValidityAssertion { true }

    override val isInline: Boolean
        get() = withValidityAssertion { false }

    override val isOverride: Boolean
        get() = withValidityAssertion { propertyDescriptor.isExplicitOverride }

    @Deprecated("Use `isCustom` instead", replaceWith = ReplaceWith("isCustom"))
    override val hasBody: Boolean
        get() = withValidityAssertion { false }

    override val isExpect: Boolean
        get() = withValidityAssertion { propertyDescriptor.isExpect }

    override val hasStableParameterNames: Boolean
        get() = withValidityAssertion { true }

    override val callableId: CallableId?
        get() = withValidityAssertion { propertyDescriptor.setterCallableIdIfNotLocal }

    override val returnType: KaType
        get() = withValidityAssertion { analysisContext.builtIns.unitType.toKtType(analysisContext) }

    override val origin: KaSymbolOrigin
        get() = withValidityAssertion { propertyDescriptor.getSymbolOrigin(analysisContext) }

    override val psi: PsiElement?
        get() = withValidityAssertion { null }

    override val receiverParameter: KaReceiverParameterSymbol?
        get() = withValidityAssertion { propertyDescriptor.extensionReceiverParameter?.toKtReceiverParameterSymbol(analysisContext) }

    override val modality: KaSymbolModality
        get() = withValidityAssertion { propertyDescriptor.kaSymbolModality }

    override val compilerVisibility: Visibility
        get() = withValidityAssertion { propertyDescriptor.ktVisibility }

    override val annotations: KaAnnotationList
        get() = withValidityAssertion { KaBaseEmptyAnnotationList(token) }

    override val isExternal: Boolean
        get() = withValidityAssertion { propertyDescriptor.isEffectivelyExternal() }

    override fun createPointer(): KaSymbolPointer<KaPropertySetterSymbol> = withValidityAssertion {
        KaFe10NeverRestoringSymbolPointer()
    }

    class KaDefaultValueParameterSymbol(
        private val propertyDescriptor: PropertyDescriptor,
        override val analysisContext: Fe10AnalysisContext,
    ) : KaValueParameterSymbol(), KaFe10Symbol {
        val descriptor: ValueParameterDescriptor?
            get() = propertyDescriptor.setter?.valueParameters?.singleOrNull()

        override val hasDefaultValue: Boolean
            get() = withValidityAssertion { false }

        override val hasDeclaredDefaultValue: Boolean
            get() = withValidityAssertion { false }

        override val hasSynthesizedName: Boolean
            get() = withValidityAssertion { false }

        override val isVararg: Boolean
            get() = withValidityAssertion { false }

        override val isImplicitLambdaParameter: Boolean
            get() = withValidityAssertion { false }

        override val isCrossinline: Boolean
            get() = withValidityAssertion { false }

        override val isNoinline: Boolean
            get() = withValidityAssertion { false }

        override val name: Name
            get() = withValidityAssertion { Name.identifier("value") }

        override val compilerVisibility: Visibility
            get() = withValidityAssertion { descriptor?.ktVisibility ?: Visibilities.Public }

        override val returnType: KaType
            get() = withValidityAssertion { propertyDescriptor.type.toKtType(analysisContext) }

        override val origin: KaSymbolOrigin
            get() = withValidityAssertion { propertyDescriptor.getSymbolOrigin(analysisContext) }

        override val psi: PsiElement?
            get() = withValidityAssertion { null }

        override val annotations: KaAnnotationList
            get() = withValidityAssertion { KaBaseEmptyAnnotationList(token) }

        override fun createPointer(): KaSymbolPointer<KaValueParameterSymbol> = withValidityAssertion {
            KaFe10NeverRestoringSymbolPointer()
        }
    }

    override fun equals(other: Any?): Boolean = isEqualTo(other)
    override fun hashCode(): Int = calculateHashCode()
}
