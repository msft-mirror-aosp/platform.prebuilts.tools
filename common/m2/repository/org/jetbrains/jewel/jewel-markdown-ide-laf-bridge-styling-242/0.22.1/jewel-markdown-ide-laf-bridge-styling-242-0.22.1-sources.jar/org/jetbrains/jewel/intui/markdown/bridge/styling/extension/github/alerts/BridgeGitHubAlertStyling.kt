package org.jetbrains.jewel.intui.markdown.bridge.styling.extension.github.alerts

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.intellij.ui.JBColor
import org.jetbrains.jewel.markdown.extensions.github.alerts.AlertStyling
import org.jetbrains.jewel.markdown.extensions.github.alerts.CautionAlertStyling
import org.jetbrains.jewel.markdown.extensions.github.alerts.ImportantAlertStyling
import org.jetbrains.jewel.markdown.extensions.github.alerts.NoteAlertStyling
import org.jetbrains.jewel.markdown.extensions.github.alerts.TipAlertStyling
import org.jetbrains.jewel.markdown.extensions.github.alerts.WarningAlertStyling

public fun AlertStyling.Companion.create(
    note: NoteAlertStyling = NoteAlertStyling.create(),
    tip: TipAlertStyling = TipAlertStyling.create(),
    important: ImportantAlertStyling = ImportantAlertStyling.create(),
    warning: WarningAlertStyling = WarningAlertStyling.create(),
    caution: CautionAlertStyling = CautionAlertStyling.create(),
): AlertStyling = AlertStyling(note, tip, important, warning, caution)

public fun NoteAlertStyling.Companion.create(
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    lineWidth: Dp = 3.dp,
    lineColor: Color = if (JBColor.isBright()) Color(0xFF0969DA) else Color(0xFF1F6EEB),
    pathEffect: PathEffect? = null,
    strokeCap: StrokeCap = StrokeCap.Square,
    titleTextStyle: TextStyle = TextStyle(fontWeight = FontWeight.Medium, color = lineColor),
    titleIconPath: String? = "icons/markdown/extensions/github/alerts/alert-note.svg",
    titleIconTint: Color = lineColor,
    textColor: Color = Color.Unspecified,
): NoteAlertStyling =
    NoteAlertStyling(
        padding,
        lineWidth,
        lineColor,
        pathEffect,
        strokeCap,
        titleTextStyle,
        titleIconPath,
        titleIconTint,
        textColor,
    )

public fun TipAlertStyling.Companion.create(
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    lineWidth: Dp = 3.dp,
    lineColor: Color = if (JBColor.isBright()) Color(0xFF1F883D) else Color(0xFF238636),
    pathEffect: PathEffect? = null,
    strokeCap: StrokeCap = StrokeCap.Square,
    titleTextStyle: TextStyle = TextStyle(fontWeight = FontWeight.Medium, color = lineColor),
    titleIconPath: String? = "icons/markdown/extensions/github/alerts/alert-tip.svg",
    titleIconTint: Color = lineColor,
    textColor: Color = Color.Unspecified,
): TipAlertStyling =
    TipAlertStyling(
        padding,
        lineWidth,
        lineColor,
        pathEffect,
        strokeCap,
        titleTextStyle,
        titleIconPath,
        titleIconTint,
        textColor,
    )

public fun ImportantAlertStyling.Companion.create(
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    lineWidth: Dp = 3.dp,
    lineColor: Color = if (JBColor.isBright()) Color(0xFF8250DF) else Color(0xFF8957E5),
    pathEffect: PathEffect? = null,
    strokeCap: StrokeCap = StrokeCap.Square,
    titleTextStyle: TextStyle = TextStyle(fontWeight = FontWeight.Medium, color = lineColor),
    titleIconPath: String? = "icons/markdown/extensions/github/alerts/alert-important.svg",
    titleIconTint: Color = lineColor,
    textColor: Color = Color.Unspecified,
): ImportantAlertStyling =
    ImportantAlertStyling(
        padding,
        lineWidth,
        lineColor,
        pathEffect,
        strokeCap,
        titleTextStyle,
        titleIconPath,
        titleIconTint,
        textColor,
    )

public fun WarningAlertStyling.Companion.create(
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    lineWidth: Dp = 3.dp,
    lineColor: Color = if (JBColor.isBright()) Color(0xFF9A6601) else Color(0xFF9E6A02),
    pathEffect: PathEffect? = null,
    strokeCap: StrokeCap = StrokeCap.Square,
    titleTextStyle: TextStyle = TextStyle(fontWeight = FontWeight.Medium, color = lineColor),
    titleIconPath: String? = "icons/markdown/extensions/github/alerts/alert-warning.svg",
    titleIconTint: Color = lineColor,
    textColor: Color = Color.Unspecified,
): WarningAlertStyling =
    WarningAlertStyling(
        padding,
        lineWidth,
        lineColor,
        pathEffect,
        strokeCap,
        titleTextStyle,
        titleIconPath,
        titleIconTint,
        textColor,
    )

public fun CautionAlertStyling.Companion.create(
    padding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
    lineWidth: Dp = 3.dp,
    lineColor: Color = if (JBColor.isBright()) Color(0xFFCF222E) else Color(0xFFDA3633),
    pathEffect: PathEffect? = null,
    strokeCap: StrokeCap = StrokeCap.Square,
    titleTextStyle: TextStyle = TextStyle(fontWeight = FontWeight.Medium, color = lineColor),
    titleIconPath: String? = "icons/markdown/extensions/github/alerts/alert-caution.svg",
    titleIconTint: Color = lineColor,
    textColor: Color = Color.Unspecified,
): CautionAlertStyling =
    CautionAlertStyling(
        padding,
        lineWidth,
        lineColor,
        pathEffect,
        strokeCap,
        titleTextStyle,
        titleIconPath,
        titleIconTint,
        textColor,
    )
