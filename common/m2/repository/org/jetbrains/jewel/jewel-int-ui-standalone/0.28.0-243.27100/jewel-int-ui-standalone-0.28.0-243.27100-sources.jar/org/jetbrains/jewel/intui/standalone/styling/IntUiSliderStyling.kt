package org.jetbrains.jewel.intui.standalone.styling

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import org.jetbrains.jewel.intui.core.theme.IntUiDarkTheme
import org.jetbrains.jewel.intui.core.theme.IntUiLightTheme
import org.jetbrains.jewel.ui.component.styling.SliderColors
import org.jetbrains.jewel.ui.component.styling.SliderMetrics
import org.jetbrains.jewel.ui.component.styling.SliderStyle

public fun SliderStyle.Companion.light(
    colors: SliderColors = SliderColors.light(),
    metrics: SliderMetrics = SliderMetrics.defaults(),
    thumbShape: Shape = CircleShape,
): SliderStyle = SliderStyle(colors, metrics, thumbShape)

public fun SliderStyle.Companion.dark(
    colors: SliderColors = SliderColors.dark(),
    metrics: SliderMetrics = SliderMetrics.defaults(),
    thumbShape: Shape = CircleShape,
): SliderStyle = SliderStyle(colors, metrics, thumbShape)

public fun SliderColors.Companion.light(
    track: Color = IntUiLightTheme.colors.gray(10),
    trackFilled: Color = IntUiLightTheme.colors.blue(6),
    trackDisabled: Color = IntUiLightTheme.colors.gray(12),
    trackFilledDisabled: Color = IntUiLightTheme.colors.gray(11),
    stepMarker: Color = track,
    thumbFill: Color = IntUiLightTheme.colors.gray(14),
    thumbFillDisabled: Color = thumbFill,
    thumbFillFocused: Color = thumbFill,
    thumbFillPressed: Color = thumbFill,
    thumbFillHovered: Color = thumbFill,
    thumbBorder: Color = IntUiLightTheme.colors.gray(8),
    thumbBorderFocused: Color = IntUiLightTheme.colors.blue(4),
    thumbBorderDisabled: Color = IntUiLightTheme.colors.gray(11),
    thumbBorderPressed: Color = IntUiLightTheme.colors.gray(7),
    thumbBorderHovered: Color = IntUiLightTheme.colors.gray(9),
): SliderColors =
    SliderColors(
        track,
        trackFilled,
        trackDisabled,
        trackFilledDisabled,
        stepMarker,
        thumbFill,
        thumbFillDisabled,
        thumbFillFocused,
        thumbFillPressed,
        thumbFillHovered,
        thumbBorder,
        thumbBorderFocused,
        thumbBorderDisabled,
        thumbBorderPressed,
        thumbBorderHovered,
    )

public fun SliderColors.Companion.dark(
    track: Color = IntUiDarkTheme.colors.gray(4),
    trackFilled: Color = IntUiDarkTheme.colors.blue(7),
    trackDisabled: Color = IntUiDarkTheme.colors.gray(3),
    trackFilledDisabled: Color = IntUiDarkTheme.colors.gray(4),
    stepMarker: Color = track,
    thumbFill: Color = IntUiDarkTheme.colors.gray(2),
    thumbFillDisabled: Color = IntUiDarkTheme.colors.gray(3),
    thumbFillFocused: Color = thumbFill,
    thumbFillPressed: Color = thumbFill,
    thumbFillHovered: Color = thumbFill,
    thumbBorder: Color = IntUiDarkTheme.colors.gray(7),
    thumbBorderFocused: Color = IntUiDarkTheme.colors.blue(6),
    thumbBorderDisabled: Color = IntUiDarkTheme.colors.gray(5),
    thumbBorderPressed: Color = IntUiDarkTheme.colors.gray(8),
    thumbBorderHovered: Color = IntUiDarkTheme.colors.gray(9),
): SliderColors =
    SliderColors(
        track,
        trackFilled,
        trackDisabled,
        trackFilledDisabled,
        stepMarker,
        thumbFill,
        thumbFillDisabled,
        thumbFillFocused,
        thumbFillPressed,
        thumbFillHovered,
        thumbBorder,
        thumbBorderFocused,
        thumbBorderDisabled,
        thumbBorderPressed,
        thumbBorderHovered,
    )

public fun SliderMetrics.Companion.defaults(
    trackHeight: Dp = 4.dp,
    thumbSize: DpSize = DpSize(14.dp, 14.dp),
    thumbBorderWidth: Dp = 1.dp,
    stepLineHeight: Dp = 8.dp,
    stepLineWidth: Dp = 1.dp,
    trackToStepSpacing: Dp = thumbSize.height / 2 + 4.dp,
): SliderMetrics =
    SliderMetrics(trackHeight, thumbSize, thumbBorderWidth, stepLineHeight, stepLineWidth, trackToStepSpacing)
