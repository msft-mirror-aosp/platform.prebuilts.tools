/**
 * Copyright (c) 2016-2018 TypeFox and others.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 * 
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */
package org.eclipse.lsp4j;

import org.eclipse.lsp4j.jsonrpc.util.Preconditions;
import org.eclipse.lsp4j.jsonrpc.util.ToStringBuilder;
import org.eclipse.lsp4j.jsonrpc.validation.NonNull;

/**
 * A MarkupContent literal represents a string value which content is interpreted based on its
 * kind flag. Currently the protocol supports {@link MarkupKind#PLAINTEXT plaintext} and
 * {@link MarkupKind#MARKDOWN markdown} as markup kinds.
 * <p>
 * If the kind is {@link MarkupKind#MARKDOWN markdown} then the value can contain fenced code blocks like in GitHub issues.
 * See https://help.github.com/articles/creating-and-highlighting-code-blocks/#syntax-highlighting
 * <p>
 * Please Note that clients might sanitize the return markdown. A client could decide to
 * remove HTML from the markdown to avoid script execution.
 * <p>
 * Since 3.3.0
 */
@SuppressWarnings("all")
public class MarkupContent {
  /**
   * The type of the Markup.
   * <p>
   * See {@link MarkupKind} for allowed values.
   */
  @NonNull
  private String kind;

  /**
   * The content itself.
   */
  @NonNull
  private String value;

  public MarkupContent() {
  }

  public MarkupContent(@NonNull final String kind, @NonNull final String value) {
    this.kind = Preconditions.<String>checkNotNull(kind, "kind");
    this.value = Preconditions.<String>checkNotNull(value, "value");
  }

  /**
   * The type of the Markup.
   * <p>
   * See {@link MarkupKind} for allowed values.
   */
  @NonNull
  public String getKind() {
    return this.kind;
  }

  /**
   * The type of the Markup.
   * <p>
   * See {@link MarkupKind} for allowed values.
   */
  public void setKind(@NonNull final String kind) {
    this.kind = Preconditions.checkNotNull(kind, "kind");
  }

  /**
   * The content itself.
   */
  @NonNull
  public String getValue() {
    return this.value;
  }

  /**
   * The content itself.
   */
  public void setValue(@NonNull final String value) {
    this.value = Preconditions.checkNotNull(value, "value");
  }

  @Override
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("kind", this.kind);
    b.add("value", this.value);
    return b.toString();
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    MarkupContent other = (MarkupContent) obj;
    if (this.kind == null) {
      if (other.kind != null)
        return false;
    } else if (!this.kind.equals(other.kind))
      return false;
    if (this.value == null) {
      if (other.value != null)
        return false;
    } else if (!this.value.equals(other.value))
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.kind== null) ? 0 : this.kind.hashCode());
    return prime * result + ((this.value== null) ? 0 : this.value.hashCode());
  }
}
