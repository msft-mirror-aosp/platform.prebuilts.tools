/**
 * Copyright (c) 2017, 2020 Kichwa Coders Ltd. and others.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 * 
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */
package org.eclipse.lsp4j.debug;

import org.eclipse.lsp4j.jsonrpc.util.Preconditions;
import org.eclipse.lsp4j.jsonrpc.util.ToStringBuilder;
import org.eclipse.lsp4j.jsonrpc.validation.NonNull;

/**
 * A Variable is a name/value pair.
 * <p>
 * The `type` attribute is shown if space permits or when hovering over the variable's
 * name.
 * <p>
 * The 'kind' attribute is used to render additional properties of the variable, e.g. different icons can be used to
 * indicate that a variable is public or private.
 * <p>
 * If the value is structured (has children), a handle is provided to retrieve the children with the
 * `variables` request.
 * <p>
 * If the number of named or indexed children is large, the numbers should be returned via the
 * 'namedVariables' and 'indexedVariables' attributes.
 * <p>
 * The client can use this information to present the children in a paged UI and fetch them in chunks.
 */
@SuppressWarnings("all")
public class Variable {
  /**
   * The variable's name.
   */
  @NonNull
  private String name;

  /**
   * The variable's value. This can be a multi-line text, e.g. for a function the body of a function.
   * <p>
   * For structured variables (which do not have a simple value), it is recommended to provide a
   * one-line representation of the structured object. This helps to identify the structured object
   * in the collapsed state when its children are not yet visible.
   * <p>
   * An empty string can be used if no value should be shown in the UI.
   */
  @NonNull
  private String value;

  /**
   * The type of the variable's value. Typically shown in the UI when hovering over the value.
   * <p>
   * This attribute should only be returned by a debug adapter if the corresponding capability
   * {@link InitializeRequestArguments#getSupportsVariableType} is true.
   * <p>
   * This is an optional property.
   */
  private String type;

  /**
   * Properties of a variable that can be used to determine how to render the variable in the UI.
   * <p>
   * This is an optional property.
   */
  private VariablePresentationHint presentationHint;

  /**
   * The evaluatable name of this variable which can be passed to the 'EvaluateRequest' to fetch the variable's
   * value.
   * <p>
   * This is an optional property.
   */
  private String evaluateName;

  /**
   * If `variablesReference` is &gt; 0, the variable is structured and its children can be retrieved by passing
   * `variablesReference` to the `variables` request as long as execution remains suspended.
   * See 'Lifetime of Object References' in the {@link DebugProtocol#Overview} section for details.
   */
  private int variablesReference;

  /**
   * The number of named child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  private Integer namedVariables;

  /**
   * The number of indexed child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  private Integer indexedVariables;

  /**
   * A memory reference associated with this variable.
   * <p>
   * For pointer type variables, this is generally a reference to the memory address contained in the pointer.
   * <p>
   * For executable data, this reference may later be used in a `disassemble` request.
   * <p>
   * This attribute may be returned by a debug adapter if corresponding capability
   * {@link InitializeRequestArguments#getSupportsMemoryReferences} is true.
   * <p>
   * This is an optional property.
   */
  private String memoryReference;

  /**
   * A reference that allows the client to request the location where the variable is declared. This should be
   * present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  private Integer declarationLocationReference;

  /**
   * A reference that allows the client to request the location where the variable's value is declared. For example,
   * if the variable contains a function pointer, the adapter may be able to look up the function's location.
   * This should be present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  private Integer valueLocationReference;

  /**
   * The variable's name.
   */
  @NonNull
  public String getName() {
    return this.name;
  }

  /**
   * The variable's name.
   */
  public void setName(@NonNull final String name) {
    this.name = Preconditions.checkNotNull(name, "name");
  }

  /**
   * The variable's value. This can be a multi-line text, e.g. for a function the body of a function.
   * <p>
   * For structured variables (which do not have a simple value), it is recommended to provide a
   * one-line representation of the structured object. This helps to identify the structured object
   * in the collapsed state when its children are not yet visible.
   * <p>
   * An empty string can be used if no value should be shown in the UI.
   */
  @NonNull
  public String getValue() {
    return this.value;
  }

  /**
   * The variable's value. This can be a multi-line text, e.g. for a function the body of a function.
   * <p>
   * For structured variables (which do not have a simple value), it is recommended to provide a
   * one-line representation of the structured object. This helps to identify the structured object
   * in the collapsed state when its children are not yet visible.
   * <p>
   * An empty string can be used if no value should be shown in the UI.
   */
  public void setValue(@NonNull final String value) {
    this.value = Preconditions.checkNotNull(value, "value");
  }

  /**
   * The type of the variable's value. Typically shown in the UI when hovering over the value.
   * <p>
   * This attribute should only be returned by a debug adapter if the corresponding capability
   * {@link InitializeRequestArguments#getSupportsVariableType} is true.
   * <p>
   * This is an optional property.
   */
  public String getType() {
    return this.type;
  }

  /**
   * The type of the variable's value. Typically shown in the UI when hovering over the value.
   * <p>
   * This attribute should only be returned by a debug adapter if the corresponding capability
   * {@link InitializeRequestArguments#getSupportsVariableType} is true.
   * <p>
   * This is an optional property.
   */
  public void setType(final String type) {
    this.type = type;
  }

  /**
   * Properties of a variable that can be used to determine how to render the variable in the UI.
   * <p>
   * This is an optional property.
   */
  public VariablePresentationHint getPresentationHint() {
    return this.presentationHint;
  }

  /**
   * Properties of a variable that can be used to determine how to render the variable in the UI.
   * <p>
   * This is an optional property.
   */
  public void setPresentationHint(final VariablePresentationHint presentationHint) {
    this.presentationHint = presentationHint;
  }

  /**
   * The evaluatable name of this variable which can be passed to the 'EvaluateRequest' to fetch the variable's
   * value.
   * <p>
   * This is an optional property.
   */
  public String getEvaluateName() {
    return this.evaluateName;
  }

  /**
   * The evaluatable name of this variable which can be passed to the 'EvaluateRequest' to fetch the variable's
   * value.
   * <p>
   * This is an optional property.
   */
  public void setEvaluateName(final String evaluateName) {
    this.evaluateName = evaluateName;
  }

  /**
   * If `variablesReference` is &gt; 0, the variable is structured and its children can be retrieved by passing
   * `variablesReference` to the `variables` request as long as execution remains suspended.
   * See 'Lifetime of Object References' in the {@link DebugProtocol#Overview} section for details.
   */
  public int getVariablesReference() {
    return this.variablesReference;
  }

  /**
   * If `variablesReference` is &gt; 0, the variable is structured and its children can be retrieved by passing
   * `variablesReference` to the `variables` request as long as execution remains suspended.
   * See 'Lifetime of Object References' in the {@link DebugProtocol#Overview} section for details.
   */
  public void setVariablesReference(final int variablesReference) {
    this.variablesReference = variablesReference;
  }

  /**
   * The number of named child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  public Integer getNamedVariables() {
    return this.namedVariables;
  }

  /**
   * The number of named child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  public void setNamedVariables(final Integer namedVariables) {
    this.namedVariables = namedVariables;
  }

  /**
   * The number of indexed child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  public Integer getIndexedVariables() {
    return this.indexedVariables;
  }

  /**
   * The number of indexed child variables.
   * <p>
   * The client can use this information to present the children in a paged UI and fetch them in chunks.
   * <p>
   * This is an optional property.
   */
  public void setIndexedVariables(final Integer indexedVariables) {
    this.indexedVariables = indexedVariables;
  }

  /**
   * A memory reference associated with this variable.
   * <p>
   * For pointer type variables, this is generally a reference to the memory address contained in the pointer.
   * <p>
   * For executable data, this reference may later be used in a `disassemble` request.
   * <p>
   * This attribute may be returned by a debug adapter if corresponding capability
   * {@link InitializeRequestArguments#getSupportsMemoryReferences} is true.
   * <p>
   * This is an optional property.
   */
  public String getMemoryReference() {
    return this.memoryReference;
  }

  /**
   * A memory reference associated with this variable.
   * <p>
   * For pointer type variables, this is generally a reference to the memory address contained in the pointer.
   * <p>
   * For executable data, this reference may later be used in a `disassemble` request.
   * <p>
   * This attribute may be returned by a debug adapter if corresponding capability
   * {@link InitializeRequestArguments#getSupportsMemoryReferences} is true.
   * <p>
   * This is an optional property.
   */
  public void setMemoryReference(final String memoryReference) {
    this.memoryReference = memoryReference;
  }

  /**
   * A reference that allows the client to request the location where the variable is declared. This should be
   * present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  public Integer getDeclarationLocationReference() {
    return this.declarationLocationReference;
  }

  /**
   * A reference that allows the client to request the location where the variable is declared. This should be
   * present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  public void setDeclarationLocationReference(final Integer declarationLocationReference) {
    this.declarationLocationReference = declarationLocationReference;
  }

  /**
   * A reference that allows the client to request the location where the variable's value is declared. For example,
   * if the variable contains a function pointer, the adapter may be able to look up the function's location.
   * This should be present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  public Integer getValueLocationReference() {
    return this.valueLocationReference;
  }

  /**
   * A reference that allows the client to request the location where the variable's value is declared. For example,
   * if the variable contains a function pointer, the adapter may be able to look up the function's location.
   * This should be present only if the adapter is likely to be able to resolve the location.
   * <p>
   * This reference shares the same lifetime as the `variablesReference`.
   * See 'Lifetime of Object References' in the Overview section for details.
   * <p>
   * This is an optional property.
   * <p>
   * Since 1.68
   */
  public void setValueLocationReference(final Integer valueLocationReference) {
    this.valueLocationReference = valueLocationReference;
  }

  @Override
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("name", this.name);
    b.add("value", this.value);
    b.add("type", this.type);
    b.add("presentationHint", this.presentationHint);
    b.add("evaluateName", this.evaluateName);
    b.add("variablesReference", this.variablesReference);
    b.add("namedVariables", this.namedVariables);
    b.add("indexedVariables", this.indexedVariables);
    b.add("memoryReference", this.memoryReference);
    b.add("declarationLocationReference", this.declarationLocationReference);
    b.add("valueLocationReference", this.valueLocationReference);
    return b.toString();
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    Variable other = (Variable) obj;
    if (this.name == null) {
      if (other.name != null)
        return false;
    } else if (!this.name.equals(other.name))
      return false;
    if (this.value == null) {
      if (other.value != null)
        return false;
    } else if (!this.value.equals(other.value))
      return false;
    if (this.type == null) {
      if (other.type != null)
        return false;
    } else if (!this.type.equals(other.type))
      return false;
    if (this.presentationHint == null) {
      if (other.presentationHint != null)
        return false;
    } else if (!this.presentationHint.equals(other.presentationHint))
      return false;
    if (this.evaluateName == null) {
      if (other.evaluateName != null)
        return false;
    } else if (!this.evaluateName.equals(other.evaluateName))
      return false;
    if (other.variablesReference != this.variablesReference)
      return false;
    if (this.namedVariables == null) {
      if (other.namedVariables != null)
        return false;
    } else if (!this.namedVariables.equals(other.namedVariables))
      return false;
    if (this.indexedVariables == null) {
      if (other.indexedVariables != null)
        return false;
    } else if (!this.indexedVariables.equals(other.indexedVariables))
      return false;
    if (this.memoryReference == null) {
      if (other.memoryReference != null)
        return false;
    } else if (!this.memoryReference.equals(other.memoryReference))
      return false;
    if (this.declarationLocationReference == null) {
      if (other.declarationLocationReference != null)
        return false;
    } else if (!this.declarationLocationReference.equals(other.declarationLocationReference))
      return false;
    if (this.valueLocationReference == null) {
      if (other.valueLocationReference != null)
        return false;
    } else if (!this.valueLocationReference.equals(other.valueLocationReference))
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.name== null) ? 0 : this.name.hashCode());
    result = prime * result + ((this.value== null) ? 0 : this.value.hashCode());
    result = prime * result + ((this.type== null) ? 0 : this.type.hashCode());
    result = prime * result + ((this.presentationHint== null) ? 0 : this.presentationHint.hashCode());
    result = prime * result + ((this.evaluateName== null) ? 0 : this.evaluateName.hashCode());
    result = prime * result + this.variablesReference;
    result = prime * result + ((this.namedVariables== null) ? 0 : this.namedVariables.hashCode());
    result = prime * result + ((this.indexedVariables== null) ? 0 : this.indexedVariables.hashCode());
    result = prime * result + ((this.memoryReference== null) ? 0 : this.memoryReference.hashCode());
    result = prime * result + ((this.declarationLocationReference== null) ? 0 : this.declarationLocationReference.hashCode());
    return prime * result + ((this.valueLocationReference== null) ? 0 : this.valueLocationReference.hashCode());
  }
}
