/**
 * Copyright (c) 2017, 2020 Kichwa Coders Ltd. and others.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 * 
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */
package org.eclipse.lsp4j.debug;

/**
 * Declaration of parameters, response bodies, and event bodies for
 * the <a href="https://microsoft.github.io/debug-adapter-protocol/">Debug Adapter Protocol</a>
 */
@SuppressWarnings("all")
public class DebugProtocol {
  /**
   * Version of Debug Protocol
   */
  public static final String SCHEMA_VERSION = "1.69.0";

  /**
   * Refer to the Debug Adapter Protocol's
   * <a href="https://microsoft.github.io/debug-adapter-protocol/overview">Overview</a> on the
   * specification's website.
   */
  public static final String Overview = "Overview";
}
