/**
 * Copyright (c) 2017, 2020 Kichwa Coders Ltd. and others.
 * 
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 * 
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */
package org.eclipse.lsp4j.debug;

import org.eclipse.lsp4j.jsonrpc.util.Preconditions;
import org.eclipse.lsp4j.jsonrpc.util.ToStringBuilder;
import org.eclipse.lsp4j.jsonrpc.validation.NonNull;

/**
 * The event indicates that a thread has started or exited.
 * <p>
 * Represents the {@code body} of {@code ThreadEvent} defined in spec.
 */
@SuppressWarnings("all")
public class ThreadEventArguments {
  /**
   * The reason for the event.
   * <p>
   * Possible values include - but not limited to those defined in {@link ThreadEventArgumentsReason}
   */
  @NonNull
  private String reason;

  /**
   * The identifier of the thread.
   */
  private int threadId;

  /**
   * The reason for the event.
   * <p>
   * Possible values include - but not limited to those defined in {@link ThreadEventArgumentsReason}
   */
  @NonNull
  public String getReason() {
    return this.reason;
  }

  /**
   * The reason for the event.
   * <p>
   * Possible values include - but not limited to those defined in {@link ThreadEventArgumentsReason}
   */
  public void setReason(@NonNull final String reason) {
    this.reason = Preconditions.checkNotNull(reason, "reason");
  }

  /**
   * The identifier of the thread.
   */
  public int getThreadId() {
    return this.threadId;
  }

  /**
   * The identifier of the thread.
   */
  public void setThreadId(final int threadId) {
    this.threadId = threadId;
  }

  @Override
  public String toString() {
    ToStringBuilder b = new ToStringBuilder(this);
    b.add("reason", this.reason);
    b.add("threadId", this.threadId);
    return b.toString();
  }

  @Override
  public boolean equals(final Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    ThreadEventArguments other = (ThreadEventArguments) obj;
    if (this.reason == null) {
      if (other.reason != null)
        return false;
    } else if (!this.reason.equals(other.reason))
      return false;
    if (other.threadId != this.threadId)
      return false;
    return true;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.reason== null) ? 0 : this.reason.hashCode());
    return prime * result + this.threadId;
  }
}
