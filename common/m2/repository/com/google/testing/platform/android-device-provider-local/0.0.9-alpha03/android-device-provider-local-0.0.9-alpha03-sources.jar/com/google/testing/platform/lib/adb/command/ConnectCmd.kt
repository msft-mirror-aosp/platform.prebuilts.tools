/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import java.time.Duration

/** Connects to a device over TCP/IP. */
interface ConnectCmd {
  /**
   * Connect to the device on the specified host and port.
   *
   * @param host the host to connect to (usually "localhost")
   * @param port the device port number
   * @param timeout for this command, defaults to 120 seconds when no timeout is given.
   * @return the exit code (0 means success, otherwise indicates failure reason)
   */
  fun connect(host: String, port: Int, timeout: Duration = Duration.ofSeconds(120L)): Int
}
