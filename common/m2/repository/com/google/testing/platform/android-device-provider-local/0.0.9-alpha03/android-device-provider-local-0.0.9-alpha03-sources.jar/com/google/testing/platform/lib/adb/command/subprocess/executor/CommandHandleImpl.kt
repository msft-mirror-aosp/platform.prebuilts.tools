package com.google.testing.platform.lib.adb.command.subprocess.executor

import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.lib.process.Handle
import java.time.Duration

/** Implementation of [CommandHandle] that delegates to [Handle]. */
class CommandHandleImpl(private val delegatehandle: Handle) : CommandHandle {
  override fun exitCode(): Int = delegatehandle.exitCode()

  override fun stop() = delegatehandle.destroy()

  override fun isRunning(): Boolean = delegatehandle.isAlive()

  override fun waitFor(timeout: Duration?) = delegatehandle.waitFor(timeout)
}
