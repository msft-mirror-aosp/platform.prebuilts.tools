/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.subprocess.executor

import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.lib.adb.command.AdbCommandException
import com.google.testing.platform.lib.adb.command.AdbTimeoutException
import com.google.testing.platform.lib.adb.command.CommandExecutor
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.lib.process.inject.DaggerSubprocessComponent
import com.google.testing.platform.lib.process.inject.SubprocessComponent
import com.google.testing.platform.lib.process.logger.SubprocessLoggerFactory.AdbSubprocessLoggerFactory
import java.time.Duration
import java.util.concurrent.TimeoutException
import javax.inject.Inject

/**
 * Runs adb commands.
 *
 * Commands are executed in the following format:
 *
 * adb <command> <list_of_args>
 *
 * Example: {@code adb devices}
 *
 * @see <a href="https://developer.android.com/studio/command-line/adb">Android Debug Bridge (adb)
 *   </a>
 */
@kotlinx.coroutines.ExperimentalCoroutinesApi
class AdbCommandExecutor
constructor(
  private val config: AdbConfig,
  private val androidSdk: AndroidSdk,
  private val subprocessComponent: SubprocessComponent
) : CommandExecutor {

  private var environmentVariables: Map<String, String>

  @Inject
  constructor(
    config: AdbConfig,
    androidSdk: AndroidSdk
  ) : this(
    config = config,
    androidSdk = androidSdk,
    subprocessComponent =
      DaggerSubprocessComponent.builder()
        .subprocessLoggerFactory(AdbSubprocessLoggerFactory(config.outputDirectory))
        .build()
  )

  init {
    this.environmentVariables =
      mapOf(ANDROID_SDK_HOME to this.androidSdk.sdkPath, ANDROID_ADB to this.androidSdk.adbPath)
  }

  companion object {
    @JvmStatic private val logger = getLogger()

    private const val ANDROID_SDK_HOME = "ANDROID_SDK_HOME"
    private const val ANDROID_ADB = "ANDROID_ADB"
  }

  private fun setUpArgs(commandArgs: Array<String>): List<String> {
    val args = mutableListOf(config.adbPath)
    if (!config.adbServerHost.isNullOrEmpty()) args.addAll(arrayOf("-H", config.adbServerHost!!))
    if (config.adbServerPort != null) args.addAll(arrayOf("-P", config.adbServerPort.toString()))
    args.addAll(commandArgs)
    return args
  }

  override fun execute(commandArgs: Array<String>, timeout: Duration): CommandResult {
    val args = setUpArgs(commandArgs)
    logger.fine("Executing Adb command: $args")
    try {
      val processHandler = subprocessComponent.subprocess()
      return processHandler.execute(args = args, environment = environmentVariables, timeout).also {
        if (it.statusCode != 0) {
          logger.warning(
            """Adb call failed.
            |Exit code: ${it.statusCode}
            |Command: ${args.joinToString(" ")}
            |Timeout: $timeout"""
              .trimMargin()
          )
        }
      }
    } catch (exception: TimeoutException) {
      // AdbTimeoutException extends TimeoutException which doesn't take a cause.
      throw AdbTimeoutException(
        """Adb command timed out.
      |Command: ${args.joinToString(" ")}
      |Timeout: $timeout
      |Message: ${exception.message}"""
          .trimMargin()
      )
    } catch (exception: Exception) {
      throw AdbCommandException(
        """Failed to execute adb command.
          |Command: ${args.joinToString(" ")}
          |Timeout: $timeout"""
          .trimMargin(),
        exception
      )
    }
  }

  override fun executeAsync(
    commandArgs: Array<String>,
    processor: (String) -> Unit
  ): CommandHandle {
    val args = setUpArgs(commandArgs)
    logger.fine("Executing Adb command: $args")
    try {
      val processHandler = subprocessComponent.subprocess()
      var handle =
        processHandler.executeAsync(
          args = args,
          environment =
            mapOf(ANDROID_SDK_HOME to androidSdk.sdkPath, ANDROID_ADB to androidSdk.adbPath),
          stdoutProcessor = processor
        )
      return CommandHandleImpl(handle)
    } catch (exception: Exception) {
      throw AdbCommandException(
        "Failed to execute async adb command.Command: ${args.joinToString(" ")} ",
        exception
      )
    }
  }
}
