/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.api.device.CommandResult
import java.time.Duration
import javax.inject.Inject

/**
 * Installs an APK file on an Android device.
 *
 * adb install [options] <apk>
 */
class InstallApkOnDeviceCmdImpl
@Inject
constructor(private val commandExecutor: DeviceCommandExecutor) : InstallApkOnDeviceCmd {

  private companion object {
    private const val PARTIAL_FAILURE_MESSAGE = "Failure ["
  }

  override fun execute(
    apkPath: String,
    timeout: Duration,
    additionalFlags: List<String>
  ): CommandResult {
    val args = listOfNotNull("install", *additionalFlags.toTypedArray(), apkPath).toTypedArray()
    val result = commandExecutor.execute(args, timeout)

    if (result.output.any { it.contains(PARTIAL_FAILURE_MESSAGE) }) {
      throw AdbCommandException(
        "Failed to install $apkPath with error code ${result.statusCode}:\n" +
          result.output.joinToString("\n")
      )
    }
    return result
  }
}
