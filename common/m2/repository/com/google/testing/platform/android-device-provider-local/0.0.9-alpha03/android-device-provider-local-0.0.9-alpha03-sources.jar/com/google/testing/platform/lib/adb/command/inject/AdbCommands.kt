/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

import com.google.testing.platform.lib.adb.command.AsyncCommand
import com.google.testing.platform.lib.adb.command.Command
import com.google.testing.platform.lib.adb.command.ConnectCmd
import com.google.testing.platform.lib.adb.command.GetAvdNameCmd
import com.google.testing.platform.lib.adb.command.GetDeviceEnvVariablesCmd
import com.google.testing.platform.lib.adb.command.GetDevicePropertiesCmd
import com.google.testing.platform.lib.adb.command.InstallApkOnDeviceCmd
import com.google.testing.platform.lib.adb.command.ListDevicesCmd
import com.google.testing.platform.lib.adb.command.PullFromDeviceCmd
import com.google.testing.platform.lib.adb.command.PushToDeviceCmd
import javax.inject.Inject
import javax.inject.Provider

/**
 * A convenience factory to make it easier to use the [DaggerAdbCommandComponent]
 * to create new adb command instances.
 */
data class AdbCommands @Inject constructor(
  /**
   * Provides a new [AsyncCommand] instance.
   */
  val asyncCommand: Provider<AsyncCommand>,

  /**
   * Provides a new [ConnectCmd] instance.
   */
  val connect: Provider<ConnectCmd>,

  /**
   * Provides a new [Command] instance.
   */
  val command: Provider<Command>,

  /**
   * Provides a new [InstallApkOnDeviceCmd] instance.
   */
  val installApkOnDevice: Provider<InstallApkOnDeviceCmd>,

  /**
   * Provides a new [ListDevicesCmd] instance.
   */
  val listDevices: Provider<ListDevicesCmd>,

  /**
   * Provides a new [GetDeviceEnvVariablesCmd] instance.
   */
  val getDeviceEnvVariables: Provider<GetDeviceEnvVariablesCmd>,

  /**
   * Provides a new [GetDevicePropertiesCmd] instance.
   */
  val getDeviceProperties: Provider<GetDevicePropertiesCmd>,

  /**
   * Provides a new [GetAvdNameCmd] instance.
   */
  val getAvdName: Provider<GetAvdNameCmd>,

  /**
   * Provides a new [PullFromDeviceCmd] instance.
   */
  val pullFromDevice: Provider<PullFromDeviceCmd>,

  /**
   * Provides a new [PushToDeviceCmd] instance.
   */
  val pushToDevice: Provider<PushToDeviceCmd>
)
