/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.api.device.CommandResult
import java.time.Duration

/**
 * Runs the "adb *args" command.
 *
 * Example: {@code adb shell chmod +x file_name} {@code adb logcat}
 *
 * Please refer to {@link https://developer.android.com/studio/command-line/adb#shellcommands} for
 * more information on running shell commands.
 */
interface Command {

  /**
   * Runs an adb command against a target device.
   *
   * @param args The args passes to @code{adb <args>}.
   * @param timeout for this command.
   * @return the exit code, 0 means success, otherwise indicates failure reason.
   */
  fun execute(args: List<String>, timeout: Duration = Duration.ofSeconds(120L)): CommandResult
}

fun Command(commandExecutor: DeviceCommandExecutor): Command = DefaultCommand(commandExecutor)
