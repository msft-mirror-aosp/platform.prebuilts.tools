/*
 *
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import java.time.Duration

/**
 * Gets the list of devices. The implementation should return a list of devices along with the
 * command's exit code.
 *
 * Runs the command: {@code adb devices}
 */
interface ListDevicesCmd {

  /**
   * Executes the command to list devices: {@code adb devices}
   *
   * If no devices are present, it returns an empty list.
   *
   * Upon failure of executing the command (command returns an exit code other than zero), it also
   * return an empty list.
   *
   * @param timeout for this command, defaults to 120 seconds when no timeout is given.
   *
   * @return a list of devices along with the exit code of the command
   */
  fun execute(timeout: Duration = Duration.ofSeconds(120L)): DevicesList
}
