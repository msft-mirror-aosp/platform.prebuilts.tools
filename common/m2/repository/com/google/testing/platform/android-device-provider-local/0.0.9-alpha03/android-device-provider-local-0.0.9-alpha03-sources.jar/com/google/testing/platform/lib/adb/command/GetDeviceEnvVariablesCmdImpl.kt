/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.lib.adb.command.parser.ShellVariableParser
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Duration
import javax.inject.Inject

/** Runs the {@code adb shell printenv} command and returns the device environment variables. */
class GetDeviceEnvVariablesCmdImpl
@Inject
constructor(
  private val commandExecutor: DeviceCommandExecutor,
  private val parser: ShellVariableParser
) : GetDeviceEnvVariablesCmd {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  override fun execute(timeout: Duration): DeviceEnvVars {
    val (exitCode, output) = commandExecutor.execute(arrayOf("shell", "printenv"), timeout)
    if (exitCode != 0) {
      throw AdbCommandException(
        """Adb printenv command failed.
        |Exit Code: $exitCode"
        |Output: $output
        |"""
          .trimMargin()
      )
    }
    val deviceVariables = parser.from(output)
    return DeviceEnvVars(deviceVariables, exitCode)
  }
}
