/*
 *
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.api.device.CommandResult
import java.time.Duration

/** Installs an APK file on an Android device or emulator. */
interface InstallApkOnDeviceCmd {
  /**
   * Installs an apk on device.
   *
   * @param apkPath path to the apk to install.
   * @param additionalFlags additional flags to pass to the install command (if any).
   * @param timeout for this command, defaults to 600 seconds when no timeout is given.
   */
  fun execute(
    apkPath: String,
    timeout: Duration = Duration.ofSeconds(600L),
    additionalFlags: List<String>
  ): CommandResult
}
