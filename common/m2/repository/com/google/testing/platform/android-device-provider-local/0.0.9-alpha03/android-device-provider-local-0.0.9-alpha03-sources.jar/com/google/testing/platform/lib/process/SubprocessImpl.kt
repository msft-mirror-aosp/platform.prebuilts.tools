/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process

import com.google.errorprone.annotations.concurrent.GuardedBy
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.lib.process.logger.SubprocessLogger
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.lang.ProcessBuilder
import java.time.Duration
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import javax.inject.Inject
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout

/**
 * Implementation of [Subprocess] using [ProcessBuilder]
 *
 * The [executeAsync] method can only be invoked once.
 *
 * @param coroutineScope CoroutineScope to use when running command
 * @param logDir log the process's output & error streams to file along with the environment
 *   variables
 */
@ExperimentalCoroutinesApi
@Suppress("UnsafeCoroutineCrossing")
class SubprocessImpl
@Inject
constructor(val coroutineScope: CoroutineScope, val subprocessLogger: SubprocessLogger) :
  Subprocess, Handle {
  // Delegate lambda to stop this process.
  // No-op if the process is already dead.
  @GuardedBy("mutex")
  private var kill: (forciblyAfter: Duration?) -> Unit = {
    throw IllegalStateException("Process hasn't started yet and cannot be destroyed.")
  }
  private lateinit var deferredProcess: Deferred<Int>
  private lateinit var invalidCommandThrowable: Throwable

  private var started: Boolean = false

  private val mutex = Mutex()

  private val processStarted: CompletableJob = Job()
  private val finishedLogging: CompletableJob = Job()

  private var processId: Long = -1
  private var processCommand: List<String> = emptyList()

  /**
   * Class to supply each line from the command output along with its publishing state.
   *
   * @param line single line of output generated.
   * @param isActive current output processing state. Not the state of the process itself.
   */
  private data class ProcessOutput(val line: String, val isActive: Boolean)

  /**
   * Executes the command built using a [ProcessBuilder] with [args] and [environment] supplied.
   *
   * Writes the executing process's stdout and stderr lines in [stdoutPublisher] and
   * [stderrPublisher] respectively.
   * * If [stderrPublisher] is not supplied then the underlying process's stdout and stderr streams
   *   are merged and supplied using [stdoutPublisher]
   * * If [stderrPublisher] is supplied, launch a child coroutine to supply the stderr lines using
   *   the [stderrPublisher] explicitly.
   */
  private suspend fun executeInternal(
    args: List<String>,
    environment: Map<String, String>,
    stdoutPublisher: MutableSharedFlow<ProcessOutput>,
    stderrPublisher: MutableSharedFlow<ProcessOutput>?,
    scope: CoroutineScope,
  ): Int {
    var process: Process? = null
    var stderrEmitterJob: Job? = null
    try {
      process =
        ProcessBuilder()
          .apply {
            command(args)
            redirectErrorStream(stderrPublisher == null)
            environment().clear() // if the user wants to inherit a variable, it should be explicit
            environment().putAll(environment)
          }
          .start()
      processCommand = args
      mutex.withLock {
        processId = process.pid()
        kill = { forciblyAfter: Duration? ->
          if (process.isAlive()) {
            process.destroy()
            if (forciblyAfter != null) {
              scope.launch(CoroutineName("${process.pid()} wait: ${args.first()}")) {
                if (!process.waitFor(forciblyAfter.toMillis(), TimeUnit.MILLISECONDS)) {
                  process.destroyForcibly()
                }
              }
            }
          }
        }
      }
      processStarted.complete() // Notify process has started.

      // Launch a coroutine to read the stderr stream if necessary
      stderrPublisher?.let {
        stderrEmitterJob =
          coroutineScope.launch(CoroutineName("$processId stderr: ${args.first()}")) {
            process.errorStream.bufferedReader().use { bufferedErrorStream ->
              readFromInputStream(bufferedErrorStream, stderrPublisher, process::isAlive, scope)
            }
          }
      }
      process.inputStream.bufferedReader().use { bufferedReader ->
        readFromInputStream(bufferedReader, stdoutPublisher, process::isAlive, scope)
      }

      process.waitForProcessToTerminate()
      return process.exitValue()
    } catch (ioException: IOException) {
      invalidCommandThrowable = ioException
      return -1
    } finally {
      // Process should be dead by now but call kill nonetheless, it's an idempotent operation.
      if (processStarted.isCompleted) kill(null)
      processStarted
        .complete() // Applicable only if an invalid command was supplied. Idempotent operation.
      process?.waitForProcessToTerminate()
      processId = -1
      stderrEmitterJob?.join()
      // Emit explicit ProcessOutput to ensure the last element has been received by subscribers
      // and there are no more output lines henceforth, i.e., subscribers can stop collecting.
      stdoutPublisher.emit(ProcessOutput("", false))
      stderrPublisher?.emit(ProcessOutput("", false))
    }
  }

  /**
   * Read from a stream, line by line.
   *
   * This method will block waiting to read lines from the underlying stream. There will be a
   * dedicated thread for each stream being read. Kills the process if an exception occurred.
   */
  private suspend fun readFromInputStream(
    bufferedReader: BufferedReader,
    publisher: MutableSharedFlow<ProcessOutput>,
    isAlive: () -> Boolean,
    scope: CoroutineScope,
  ) {
    bufferedReader.use { reader ->
      try {
        scope.ensureActive() // Check for cancellation
        // Will block until a line is read or the stream is closed
        var line = reader.readLine()
        while ((isAlive() || line != null) && scope.isActive) {
          line?.let {
            publisher.emit(
              ProcessOutput(it, true)
            ) // Will suspend if the buffer is full and until all subscribers can receive the value.
          }
          // Will block until a line is read or the stream is closed
          line = reader.readLine()
        }
      } catch (ex: Exception) {
        kill(null)
      }
    }
  }

  /**
   * Execute a shell command asynchronously supplied by [args].
   *
   * This method launches an async coroutine where the command is executed with 2 broadcast channels
   * for both stdout and stderr (if necessary).
   * * Launches a coroutine that processes lines by subscribing to the stdoutchannel.
   * * Launches a coroutine that processes lines by subscribing to the stderrchannel if necessary.
   * * If [logdir] is set, then initialize [SubprocessLogger] and launches a coroutine which
   *   subscribes to the stdout broadcast channel.
   * * Launch an additional coroutine to subscribe and write the stderr messages if explicit
   *   handling of stderr is requested.
   *
   * The below flow illustrates the hierarchy.
   *
   * ```
   *    [executeAsync]
   *     |      |
   *     |   [async]__________[executeInternal] (execute process and blocks till termination)
   *     |      |                 |__________[stderrJob]* (if necessary)
   *     |      |__________[stdout Processor Subscriber]* (if necessary)
   *     |      |__________[stderr Processor Subscriber]* (if necessary)
   *     |      |__________[stdout Logger Subscriber] (logs stdout messages)
   *     |      |__________[stderr Logger Subscriber]* (if necessary)
   *     |
   * ```
   *
   * @param args list of strings composing the command.
   * @param environment set up additional environment variable for the process. Default: empty map.
   * @param stdoutProcessor lambda to handle lines generated as part of stdout by the process. If
   *   [stdoutProcessor] is not supplied, command will execute and not return any output.
   * @param stderrProcessor lambda to handle lines generated as part of stderr by the process. If
   *   [stderrProcessor] is not supplied, the stdout and stderr output streams are merged.
   * @return [Handle] representing the state of the process.
   */
  override fun executeAsync(
    args: List<String>,
    environment: Map<String, String>,
    stdoutProcessor: ((String) -> Unit)?,
    stderrProcessor: ((String) -> Unit)?,
  ): Handle {
    check(!started) { "Process has started. execute has already been called." }
    started = true
    require(args.isNotEmpty()) { "Args supplied cannot be empty." }
    subprocessLogger.startLogging(args, environment)

    // Run the flow collection in its own coroutine scope. The flow inherits the scope of the
    // coroutine that started it.
    deferredProcess =
      coroutineScope.async(CoroutineName("$processId flow: ${args.first()}")) {
        // The publisher may start emitting before the subscribers are ready to collect, set up a
        // replay cache with a suitable size.
        val stdoutEmitter: MutableSharedFlow<ProcessOutput> =
          MutableSharedFlow(replay = BUFFER_CAPACITY)
        val stdoutCollector = stdoutEmitter.asSharedFlow()
        var stderrEmitter: MutableSharedFlow<ProcessOutput>? = null

        var stderrProcessorSubscriber: Job? = null
        var stdoutProcessorSubscriber: Job? = null
        var stderrLoggerSubscriber: Job? = null
        var stdoutLoggerSubscriber: Job? = null
        try {
          // Start all the subscribers in their own coroutine before publishing/emitting values.
          // Launch coroutine to receive on the stderr channel if necessary
          stderrProcessor?.run {
            stderrEmitter = MutableSharedFlow(replay = BUFFER_CAPACITY)
            val stderrCollector = stderrEmitter!!.asSharedFlow()
            // Launch a coroutine to process the stderr stream separately if necessary
            stderrProcessorSubscriber =
              stderrCollector
                .takeWhile { it.isActive }
                .onEach { stderrProcessor(it.line) }
                .launchInUndispatched(coroutineScope)

            // Launch a coroutine to write stderr logs.
            stderrLoggerSubscriber =
              stderrCollector
                .takeWhile { it.isActive }
                .onEach { subprocessLogger.writeLine(it.line) }
                .launchInUndispatched(coroutineScope)
          }
          stdoutProcessor?.run {
            // Launch a coroutine to process the stdout stream separately if necessary
            stdoutProcessorSubscriber =
              stdoutCollector
                .takeWhile { it.isActive }
                .onEach { stdoutProcessor(it.line) }
                .launchInUndispatched(coroutineScope)
          }
          // Launch a coroutine to write stdout logs.
          stdoutLoggerSubscriber =
            stdoutCollector
              .takeWhile { it.isActive }
              .onEach { subprocessLogger.writeLine(it.line) }
              .launchInUndispatched(coroutineScope)

          return@async executeInternal(args, environment, stdoutEmitter, stderrEmitter, this)
        } finally {
          // Wait for all the subscribers to terminate normally.
          stdoutProcessorSubscriber?.join()
          stderrProcessorSubscriber?.join()
          // Explicitly wait for the logger jobs to finish before finishing the log file. Otherwise,
          // the logger file could be closed for writing before processing all the lines in the
          // channel.
          stderrLoggerSubscriber?.join()
          stdoutLoggerSubscriber?.join()
        }
      }
    deferredProcess.invokeOnCompletion {
      subprocessLogger.finishLogging(deferredProcess.getCompleted())
      finishedLogging.complete()
    }
    deferredProcess.start()
    // Wait until the underlying process has been started before returning to the caller.
    runBlocking(coroutineScope.coroutineContext) { processStarted.join() }

    // Throw if there was an issue with the command supplied.
    if (this::invalidCommandThrowable.isInitialized) throw invalidCommandThrowable
    return this
  }

  override fun execute(
    args: List<String>,
    environment: Map<String, String>,
    timeout: Duration?,
  ): CommandResult {
    check(!started) { "Process has started. execute has already been called." }
    started = true
    subprocessLogger.startLogging(args, environment)
    val processHandler =
      ProcessBuilder()
        .apply {
          command(args)
          environment().clear() // if the user wants to inherit a variable, it should be explicit
          environment().putAll(environment)
          redirectErrorStream(true)
        }
        .start()
    val readerJob =
      coroutineScope.async(CoroutineName("$processId outputStream: ${args.first()}")) {
        val outputStream = ByteArrayOutputStream() // Does not need to be closed.
        processHandler.inputStream.use { it.transferTo(outputStream) }
        return@async outputStream.toByteArray()
      }
    val exitCode =
      if (timeout == null) {
        processHandler.waitFor()
      } else {
        if (!processHandler.waitFor(timeout.toMillis(), TimeUnit.MILLISECONDS)) {
          processHandler.destroyForcibly()
          throw TimeoutException(
            "Process timed out when executing command ${args.joinToString(" ")}"
          )
        }
        processHandler.exitValue()
      }

    runBlocking(coroutineScope.coroutineContext) { readerJob.join() }
    val output = readerJob.getCompleted()
    String(output, Charsets.UTF_8).lines().forEach { subprocessLogger.writeLine(it) }
    subprocessLogger.finishLogging(exitCode)
    return CommandResult(exitCode, output)
  }

  override fun destroy(forciblyAfter: Duration?) {
    runBlocking(coroutineScope.coroutineContext) { mutex.withLock { kill(forciblyAfter) } }
  }

  override fun isAlive(): Boolean = deferredProcess.isActive

  override fun waitFor(timeout: Duration?) {
    runBlocking(coroutineScope.coroutineContext) {
      try {
        timeout?.let { withTimeout(timeout.toMillis()) { waitForProcessAndLogger() } }
          ?: waitForProcessAndLogger()
      } catch (ex: TimeoutCancellationException) {
        kill(null)
        val timeoutException = TimeoutException("Command $processCommand timed out: $timeout")
        timeoutException.initCause(ex)
        throw timeoutException
      }
    }
  }

  override fun exitCode(): Int {
    check(!deferredProcess.isActive) {
      "Process still running. Use Process#isAlive() to check for process completeness."
    }
    return deferredProcess.getCompleted()
  }

  override fun pid(): Long {
    check(processId != -1L) { "No process is currently running." }
    return processId
  }

  /** Helper extension function to wait for process to terminate. */
  private suspend fun Process.waitForProcessToTerminate() {
    while (isAlive) {
      delay(500L)
    }
  }

  /** Wait for the process coroutine and any associated logging to complete. */
  private suspend fun waitForProcessAndLogger() {
    deferredProcess.await()
    finishedLogging.join()
  }

  /**
   * Helper function analogous to [launchIn] to ensure the coroutine is ready to collect.
   *
   * The default start mode dispatches it to the coroutine scheduler, this ensures it is started and
   * ready to collect values that are emitted upstream.
   */
  private fun <T> Flow<T>.launchInUndispatched(scope: CoroutineScope): Job =
    scope.launch(start = CoroutineStart.UNDISPATCHED) { collect() }

  private companion object {
    // Replay buffer size value.
    const val BUFFER_CAPACITY = 1024
  }
}
