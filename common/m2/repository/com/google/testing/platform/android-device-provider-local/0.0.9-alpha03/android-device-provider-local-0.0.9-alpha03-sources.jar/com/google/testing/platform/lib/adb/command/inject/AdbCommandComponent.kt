/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.lib.adb.command.inject.annotation.AdbCommandScope
import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor
import dagger.BindsInstance
import dagger.Component

/**
 * Dagger component to create all adb-related classes.
 *
 * This class isn't used directly by other projects - instead, use [AdbCommands] which wraps this
 * component as the main entry point into the adb commands.
 */
@AdbCommandScope
@Component(modules = [AdbCommandModule::class, AdbExecutorModule::class])
interface AdbCommandComponent {
  val adbCommands: AdbCommands

  @Component.Builder
  interface Builder {

    @BindsInstance fun adbConfig(adbConfig: AdbConfig): Builder

    @BindsInstance fun androidSdk(androidSdk: AndroidSdk): Builder

    @BindsInstance fun deviceMonitor(deviceMonitor: DeviceMonitor): Builder

    fun build(): AdbCommandComponent
  }
}
