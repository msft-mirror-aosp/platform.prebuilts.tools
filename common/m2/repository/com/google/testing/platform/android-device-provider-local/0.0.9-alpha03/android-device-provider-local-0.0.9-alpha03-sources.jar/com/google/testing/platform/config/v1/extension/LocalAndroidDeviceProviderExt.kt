/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config.v1.extension

import com.google.testing.platform.proto.api.config.LocalAndroidDeviceProviderProto.LocalAndroidDeviceProvider

private const val DEFAULT_HOST = "localhost"
private const val DEFAULT_ADB_PORT = 5555
private val DEFAULT_ADB_SERVER_PORT: Int? = null
private val DEFAULT_CONSOLE_PORT: Int? = null

/**
 * Validates a device is fully identified.
 * Returns true if at least either of the following configuration values were provided:
 * 1. server port and serial; or
 * 2. server host, port, and adbPort
 *
 * The reason either serial or host+adbPort are valid is because typically one could be
 * inferred from the other, assuming the serial has the format "host:adbPort".
 */
fun LocalAndroidDeviceProvider.isValid() =
  adbServerPort > 0 && ((host.isNotBlank() && adbPort > 0) || serial.isNotBlank())

/**
 * The host the device is connected to.
 * Default is "localhost".
 * */
val LocalAndroidDeviceProvider.hostOrDefault
  get() = if (host.isNotBlank()) host else DEFAULT_HOST

/**
 * Port number for the emulator ADB connection.
 * Default is 5555.
 *
 * For information on the port numbers used by ADB, see:
 * https://developer.android.com/studio/command-line/adb and
 */
val LocalAndroidDeviceProvider.adbPortOrDefault
  get() = if (adbPort > 0) adbPort else DEFAULT_ADB_PORT

/**
 * Port number the ADB server is listing on.
 * Default is null, in which case adb will use port 5037 as hardcoded in the adb.h source file.
 *
 * @see https://github.com/aosp-mirror/platform_system_core/blob/master/adb/adb.h
 */
val LocalAndroidDeviceProvider.adbServerPortOrDefault
  get() = if (adbServerPort > 0) adbServerPort else DEFAULT_ADB_SERVER_PORT

/**
 * The device serial number.
 * Default is "<host>:<adbPort>".
 */
val LocalAndroidDeviceProvider.deviceSerialOrDefault
  get() = if (serial.isNotBlank()) serial else "$hostOrDefault:$adbPortOrDefault"

/**
 * Port number for the emulator console.
 * Default is null.
 * For more information on the Android Emulator Console, see:
 * https://developer.android.com/studio/run/emulator-console
 */
val LocalAndroidDeviceProvider.consolePortOrDefault
  get() = if (consolePort > 0) consolePort else DEFAULT_CONSOLE_PORT
