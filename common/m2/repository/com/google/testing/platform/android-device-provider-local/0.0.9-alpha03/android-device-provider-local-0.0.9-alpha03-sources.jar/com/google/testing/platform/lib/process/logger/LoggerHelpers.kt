/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process.logger

import java.io.File
import java.util.logging.Logger

/** Helper functions for loggers. */
object LoggerHelpers {
  private val ADB_EQUIVALENTS = listOf("adb", "adb.static", "waterfall_bin")
  private val ADB_FLAGS_WITH_ARGS = listOf("-s", "-H", "-P", "-t", "-L", "--one-device")
  private val ANDROID_PREFIX_COMMANDS = listOf("am", "pm")
  private val BASH = Regex("""(/.*/)?(ba)?sh$""")
  private val DIRECT_ADB_COMMANDS = listOf("install", "pull", "push")
  private val INVALID_FILENAME_CHARS = Regex("""[^-=@.,\w]""")
  private val MAX_FILENAME_LENGTH = 64 // hard limit is 255 bytes; this is for human readability
  private val SH_VARIABLE_ASSIGNMENT = Regex("""^\w+=(\$\([^)]+\)|\S*)\s*""")
  private val WHITESPACE = Regex("""\s+""")

  private val logger = Logger.getLogger("LoggerHelpers")

  private fun String.truncateStart() =
    if (length > MAX_FILENAME_LENGTH) {
      "...${this.takeLast(MAX_FILENAME_LENGTH)}"
    } else {
      this
    }

  private fun String.truncateEnd() =
    if (length > MAX_FILENAME_LENGTH) {
      "${this.take(MAX_FILENAME_LENGTH)}..."
    } else {
      this
    }

  /**
   * Given a command, create an appropriate filename for a log of that command. The caller is
   * expected to prepend something like "waterfall_command.023." and append something like
   * ".fail.txt".
   */
  fun summarizeCommandForFilename(args: List<String>): String {
    logger.finest("[${args.joinToString("] [")}]")
    if (args.isEmpty()) return "NO_COMMAND" // backstop in case of malformed command

    var argv = args

    // Someone might have stuffed an entire command into a single argv element.
    if (argv.first().contains(WHITESPACE)) {
      return summarizeCommandForFilename(argv.first().split(WHITESPACE))
    }

    val filename = argv.first().split(File.separator).last()

    if (argv.size >= 2) {
      when {
        ADB_EQUIVALENTS.contains(filename) -> return summarizeAdbCommand(argv.drop(1))
        // Commands for the ActivityManager and PackageManager ("am" and "pm") make a lot more
        // sense if you can see the next parameter.
        ANDROID_PREFIX_COMMANDS.contains(filename) -> {
          return "${filename}.${argv.get(1)}".truncateEnd()
        }
        BASH.matches(filename) -> return summarizeBashCommand(argv.drop(1))
        // The following adb commands come in without "adb" in front.
        DIRECT_ADB_COMMANDS.contains(filename) -> return summarizeAdbCommand(argv)
      }
    }

    // If we're here, all "adb shell" and "sh" have been stripped away, and presumably we have the
    // command that's being run.
    return filename.replace(INVALID_FILENAME_CHARS, "_").truncateEnd()
  }

  /**
   * Reports specific adb commands, or strips away "adb shell" and sends it for another pass through
   * summarizeCommandForFilename.
   */
  private fun summarizeAdbCommand(args: List<String>): String {
    logger.finest("[${args.joinToString("] [")}]")

    var argv = args

    // Drop two-argument flags.
    while (argv.size >= 2) {
      when {
        // Drop two-argument flags with their argument.
        ADB_FLAGS_WITH_ARGS.contains(argv.first()) -> argv = argv.drop(2)
        // Drop one-argument flags.
        argv.first().startsWith("-") -> argv = argv.drop(1)
        else -> break
      }
    }
    if (argv.size >= 2) {
      when {
        argv.first() == "shell" -> {
          argv = argv.drop(1)
          while (argv.size > 0 && SH_VARIABLE_ASSIGNMENT.matches(argv.first())) argv = argv.drop(1)
          return summarizeCommandForFilename(argv)
        }
        // Sifting through multiple broker logs all say ".install.ok.txt" is tedious, so make it
        // easier to figure out which log is worth a look.
        argv.first() == "install" -> {
          argv = argv.drop(1)
          while (argv.size >= 1 && argv.first().startsWith("-")) {
            if (argv.size >= 2 && listOf("-i", "-p", "--user").contains(argv.first())) {
              argv = argv.drop(2)
            } else {
              argv = argv.drop(1)
            }
          }
          if (argv.size >= 1) {
            val apk = argv.first().split(File.separator).last().truncateStart()
            return "install.$apk"
          } else {
            return "install" // backstop in case of malformed command
          }
        }
        listOf("pull", "push").contains(argv.first()) -> {
          val verb = argv.first()
          argv = argv.drop(1)
          while (argv.size >= 1) {
            when {
              argv.size >= 2 && argv.first() == "-z" -> argv = argv.drop(2)
              argv.first().startsWith("-") -> argv = argv.drop(1)
              else -> break
            }
          }
          if (argv.size == 0) return verb
          // adb pull can pull entire directories; make sure split doesn't give us an empty string.
          var target =
            argv
              .first()
              .trimEnd { File.separator.contains(it) }
              .split(File.separator)
              .last()
              .truncateStart()
          return "$verb.$target"
        }
      }
    }
    // Use the simple adb command.
    return argv.first()
  }

  /**
   * Strips away bash-related clutter and sends the results for another pass through
   * summarizeCommandForFilename.
   */
  private fun summarizeBashCommand(args: List<String>): String {
    logger.finest("[${args.joinToString("] [")}]")

    var argv = args

    while (argv.size >= 2) {
      // "sh -c" can have an entire command line as the next argument.
      if (argv.first() == "-c") {
        argv = argv.drop(1)
        // Remove variable assignments before the split, since they might contain spaces.
        var line = argv.first()
        while (line.contains(SH_VARIABLE_ASSIGNMENT)) {
          line = line.replace(SH_VARIABLE_ASSIGNMENT, "")
        }
        return summarizeCommandForFilename(line.split(" "))
      }

      // Remove flags and variable assignments from the sh invocation.
      when {
        argv.first().startsWith("-") -> argv = argv.drop(1)
        SH_VARIABLE_ASSIGNMENT.matches(argv.first()) -> argv = argv.drop(1)
        else -> break
      }
    }

    return summarizeCommandForFilename(argv)
  }
}
