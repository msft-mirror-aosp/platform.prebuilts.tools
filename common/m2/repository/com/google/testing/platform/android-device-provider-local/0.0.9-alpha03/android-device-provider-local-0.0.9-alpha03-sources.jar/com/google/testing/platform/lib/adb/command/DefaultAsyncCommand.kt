/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.api.device.CommandHandle
import javax.inject.Inject

/**
 * Runs the adb command, "adb *args" command.
 *
 * Example:
 * {@code adb shell chmod +x file_name}
 * {@code adb logcat}
 *
 * The command will always run against a specfic device.
 * If [AdbConfig] does not have a device serial this will fail.
 */
class DefaultAsyncCommand @Inject constructor(
  private val commandExecutor: DeviceCommandExecutor
) : AsyncCommand {

  override fun execute(args: List<String>, processor: (String) -> Unit): CommandHandle {
    return commandExecutor.executeAsync(args.toTypedArray(), processor)
  }
}
