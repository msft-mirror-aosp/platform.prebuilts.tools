/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import java.time.Duration
import javax.inject.Inject

/**
 * Connects to a device over TCP/IP using the "adb connect" command, for example:
 *
 * {@code adb -H localhost -P 5037 connect localhost:5555}
 */
class ConnectCmdImpl @Inject constructor(private val commandExecutor: CommandExecutor) :
  ConnectCmd {

  override fun connect(host: String, port: Int, timeout: Duration): Int {
    return commandExecutor.execute(arrayOf("connect", "$host:$port"), timeout).statusCode
  }
}
