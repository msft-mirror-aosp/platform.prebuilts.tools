/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process.logger

import java.io.File
import java.nio.file.Paths
import javax.inject.Inject

/**
 * Helper class to log adb commands.
 *
 * This class helps determine the sub command running on the device as part of `adb shell`.
 */
class AdbSubprocessLogger(private val delegateSubprocessLogger: SubprocessLogger) :
  SubprocessLogger by delegateSubprocessLogger {

  private lateinit var originalPrefix: String
  private lateinit var adbSubCommandPrefix: String

  @Inject
  constructor(
    logDir: String,
    flushEagerly: Boolean = false
  ) : this(delegateSubprocessLogger = DefaultSubprocessLogger(logDir, flushEagerly))

  override fun startLogging(args: List<String>, environment: Map<String, String>) {
    delegateSubprocessLogger.startLogging(args, environment)
    adbSubCommandPrefix = getLogPrefix(args)
  }

  override fun getLogPrefix(args: List<String>): String {
    var commandPrefix = delegateSubprocessLogger.getLogPrefix(args)
    originalPrefix = commandPrefix
    return "${commandPrefix}.${LoggerHelpers.summarizeCommandForFilename(args)}"
  }

  override fun finishLogging(exitCode: Int): String {
    val logFilePath = delegateSubprocessLogger.finishLogging(exitCode)
    val existingLogFile = File(logFilePath)
    var newLogFileName = existingLogFile.name.replace(originalPrefix, adbSubCommandPrefix)
    // If there's a sequence number in the log file, move it closer to the front so the logs will
    // be listed in order, and pad it to three digits so the filenames sort properly. It'll look
    // something like "adb.foo.2.ok.txt" and we want it to be "adb.002.foo.ok.txt".
    val components = newLogFileName.split(".").toMutableList()
    if (components.get(components.size - 3).all { Character.isDigit(it) }) {
      val sequence = components.removeAt(components.size - 3).toInt()
      components.add(1, sequence.toString().padStart(3, '0'))
      newLogFileName = components.joinToString(".")
    }
    return Paths.get(existingLogFile.parent, newLogFileName).toFile().let { newFile ->
      existingLogFile.renameTo(newFile)
      newFile.absolutePath
    }
  }
}
