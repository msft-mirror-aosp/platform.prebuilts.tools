package com.google.testing.platform.runtime.android.logcat

import com.google.testing.platform.proto.api.core.LogMessageProto
import kotlinx.coroutines.flow.Flow

/** Returns a [Flow] of logcat lines parsed as [LogMessageProto.LogMessage] when subscribed. */
interface LogcatReader {
  fun getLogcatFlow(): Flow<LogMessageProto.LogMessage>
}
