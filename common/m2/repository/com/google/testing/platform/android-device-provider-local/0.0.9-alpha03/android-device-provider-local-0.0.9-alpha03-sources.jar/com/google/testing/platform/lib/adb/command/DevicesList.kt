/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

/**
 * List of devices returned by [ListDevicesCmd.execute].
 *
 * TODO(b/117439208): use List<AdbDevice> here instead of List<SerialIds>
 */
data class DevicesList(
  /**
   * List of devices. Each item in the list denotes the serial number of the device.
   */
  val devices: List<String>,

  /**
   * The exit code of the adb command.
   */
  val exitCode: Int
)
