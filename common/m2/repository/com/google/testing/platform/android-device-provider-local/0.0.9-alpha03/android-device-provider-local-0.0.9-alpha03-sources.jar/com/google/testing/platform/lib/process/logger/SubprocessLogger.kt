/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process.logger

/** Interface to write debug logs for commands executed through [Subprocess] */
interface SubprocessLogger {

  /** Factory interface to create unique instance of the logger. */
  interface Factory {
    /** Create an instance of [SubprocessLogger] */
    fun create(): SubprocessLogger
  }

  /**
   * Start logging the command to file.
   *
   * @param args represents the command being executed.
   * @param environment environment directory supplied to execute the command.
   */
  fun startLogging(args: List<String>, environment: Map<String, String>)

  /**
   * Write the output of the command.
   *
   * @param channel receive channel that accepts individual lines.
   */
  fun writeLine(line: String)

  /**
   * Finish logging the command.
   *
   * @param exitCode exit code of the command.
   * @return absolute path of the log file.
   */
  fun finishLogging(exitCode: Int): String

  /**
   * Setup the file name for the command to be logged.
   *
   * @param args represents the command being executed.
   */
  fun getLogPrefix(args: List<String>): String
}
