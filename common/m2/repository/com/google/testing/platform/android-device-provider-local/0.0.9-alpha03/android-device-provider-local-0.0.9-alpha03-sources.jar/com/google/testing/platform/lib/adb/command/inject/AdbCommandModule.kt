/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

import com.google.testing.platform.lib.adb.command.AsyncCommand
import com.google.testing.platform.lib.adb.command.Command
import com.google.testing.platform.lib.adb.command.ConnectCmd
import com.google.testing.platform.lib.adb.command.ConnectCmdImpl
import com.google.testing.platform.lib.adb.command.DefaultAsyncCommand
import com.google.testing.platform.lib.adb.command.DefaultCommand
import com.google.testing.platform.lib.adb.command.GetAvdNameCmd
import com.google.testing.platform.lib.adb.command.GetAvdNameCmdImpl
import com.google.testing.platform.lib.adb.command.GetDeviceEnvVariablesCmd
import com.google.testing.platform.lib.adb.command.GetDeviceEnvVariablesCmdImpl
import com.google.testing.platform.lib.adb.command.GetDevicePropertiesCmd
import com.google.testing.platform.lib.adb.command.GetDevicePropertiesCmdImpl
import com.google.testing.platform.lib.adb.command.InstallApkOnDeviceCmd
import com.google.testing.platform.lib.adb.command.InstallApkOnDeviceCmdImpl
import com.google.testing.platform.lib.adb.command.ListDevicesCmd
import com.google.testing.platform.lib.adb.command.ListDevicesCmdImpl
import com.google.testing.platform.lib.adb.command.ListInstrumentationsCmd
import com.google.testing.platform.lib.adb.command.ListInstrumentationsCmdImpl
import com.google.testing.platform.lib.adb.command.PullFromDeviceCmd
import com.google.testing.platform.lib.adb.command.PullFromDeviceCmdImpl
import com.google.testing.platform.lib.adb.command.PushToDeviceCmd
import com.google.testing.platform.lib.adb.command.PushToDeviceCmdImpl
import dagger.Binds
import dagger.Module

/**
 * Provides ADB command classes for Dagger.
 */
@Module
interface AdbCommandModule {

  @Binds
  fun asyncCommand(asyncCommand: DefaultAsyncCommand): AsyncCommand

  @Binds
  fun command(command: DefaultCommand): Command

  @Binds
  fun connectCmd(connectCmd: ConnectCmdImpl): ConnectCmd

  @Binds
  fun listDevicesCmd(listDevicesCmd: ListDevicesCmdImpl): ListDevicesCmd

  @Binds
  fun printAvdNameCmd(printAvdNameCmd: GetAvdNameCmdImpl): GetAvdNameCmd

  @Binds
  fun printEnvCmd(printEnvCmd: GetDeviceEnvVariablesCmdImpl): GetDeviceEnvVariablesCmd

  @Binds
  fun printGetPropCmd(printGetPropCmd: GetDevicePropertiesCmdImpl): GetDevicePropertiesCmd

  @Binds
  fun pullFromDeviceCmd(pullFromDeviceCmd: PullFromDeviceCmdImpl): PullFromDeviceCmd

  @Binds
  fun pushToDeviceCmd(pushToDeviceCmd: PushToDeviceCmdImpl): PushToDeviceCmd

  @Binds
  fun installApkOnDeviceCmd(installApkOnDeviceCmd: InstallApkOnDeviceCmdImpl): InstallApkOnDeviceCmd

  @Binds
  fun listInstrumentationsCmd(
    listInstrumentationsCmd: ListInstrumentationsCmdImpl
  ): ListInstrumentationsCmd
}
