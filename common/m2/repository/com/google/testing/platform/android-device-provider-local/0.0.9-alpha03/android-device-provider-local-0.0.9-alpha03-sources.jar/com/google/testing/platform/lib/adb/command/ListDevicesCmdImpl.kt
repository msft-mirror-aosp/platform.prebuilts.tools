/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.lib.adb.command.parser.DevicesListParser
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Duration
import javax.inject.Inject

/** Runs the {@code adb devices} command and returns the list of connected devices. */
class ListDevicesCmdImpl
@Inject
constructor(private val commandExecutor: CommandExecutor, private val parser: DevicesListParser) :
  ListDevicesCmd {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  override fun execute(timeout: Duration): DevicesList {
    val (exitCode, output) = commandExecutor.execute(arrayOf("devices"), timeout)
    val devices = parser.from(output)
    if (exitCode != 0 && devices.isNotEmpty()) {
      logger.warning(
        "Unexpected state: adb returned ${devices.size} device(s) " +
          "but the exit code is $exitCode"
      )
    }
    return DevicesList(devices, exitCode)
  }
}
