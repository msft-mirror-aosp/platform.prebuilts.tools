/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.config

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.config.Config
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.events

/** Wrapper context for Android runtime components. */
@ThreadSafe
class AndroidUTPContext(private val delegate: Context, config: Config? = null) : Context {
  private val contextMap =
    mapOf<String, Any?>(
      Context.CONFIG_KEY to config,
      Context.EVENTS_KEY to delegate.events,
    )

  override fun get(key: String): Any? {
    return contextMap[key] ?: delegate[key]
  }
}
