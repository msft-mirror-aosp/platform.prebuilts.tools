/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.provider.local

import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.device.Device.DeviceType
import com.google.testing.platform.config.v1.extension.adbServerPortOrDefault
import com.google.testing.platform.proto.api.config.LocalAndroidDeviceProviderProto.LocalAndroidDeviceProvider
import com.google.testing.platform.runtime.android.device.AndroidDevice
import com.google.testing.platform.runtime.android.device.AndroidDeviceProperties

private const val DEFAULT_HOST = "localhost"
private val EMULATOR_REGEX = Regex("""\w+[\-](\d+)""") // matches emulator-5554
private val HOST_REGEX = Regex("""([\w\-]+)[:](\d+)""") // matches localhost:5555

/**
 * Creates an [AndroidDevice] from a device serial number string as returned by "adb devices".
 *
 * The device serial string typically has one of the following formats:
 * <ol>
 * <li>emulator-5554</li>
 * <li>localhost:5555</li>
 * <li>deviceSerial</li>
 * </ol>
 *
 * In the first example, 5554 represents the emulator console port number. In the second example,
 * 5555 represents the adb port number. The third example shows a physical device connected locally.
 *
 * @param serial the device serial number string to parse
 * @return the new [AndroidDevice] instance
 */
fun deviceFromSerial(
  serial: String,
  config: LocalAndroidDeviceProvider,
  environment: Environment
): AndroidDevice {
  var hostName = if (config.host.isNotBlank()) config.host else DEFAULT_HOST
  var adbPort: Int? = null
  var consolePort: Int? = null
  var deviceType = DeviceType.valueOf(config.deviceType.name)

  // Try to match emulator name in the format "emulator-<console-port>"
  tryParseSerial(EMULATOR_REGEX, serial) { (port, _) ->
    consolePort = port.toInt()
    adbPort = config.adbPort.let { if (it > 0) it else consolePort?.plus(1) }
    if (deviceType == DeviceType.UNKNOWN_DEVICE) {
      deviceType = DeviceType.VIRTUAL
    }
  }

  // Try to match a connected device name in the format "<host>:<adb-port>"
  if (consolePort == null) {
    tryParseSerial(HOST_REGEX, serial) { (host, port) ->
      hostName = host
      adbPort = port.toInt()
    }
  }

  return AndroidDevice(
    host = hostName,
    serial = serial,
    type = deviceType,
    port = adbPort,
    emulatorPort = consolePort,
    serverPort = config.adbServerPortOrDefault,
    properties = AndroidDeviceProperties(logcatOptions = environment.androidLogcatOptions)
  )
}

/** Try to match the serial and passes the destructured match group values to the [block]. */
private fun tryParseSerial(
  pattern: Regex,
  serial: String,
  block: (MatchResult.Destructured) -> Unit
) = pattern.matchEntire(serial)?.destructured?.also(block)
