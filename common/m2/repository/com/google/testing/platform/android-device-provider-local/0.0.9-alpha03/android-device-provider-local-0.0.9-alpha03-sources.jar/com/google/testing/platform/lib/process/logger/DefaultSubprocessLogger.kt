/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process.logger

import com.google.common.annotations.VisibleForTesting
import com.google.errorprone.annotations.concurrent.GuardedBy
import java.io.BufferedWriter
import java.io.File
import java.nio.file.Files
import java.nio.file.Paths
import java.time.Duration
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject

/**
 * Helper class to write debug logs for commands executed.
 *
 * @param logDir directory to write logs to.
 */
class DefaultSubprocessLogger
@Inject
constructor(private val logDir: String, private val flushEagerly: Boolean = false) :
  SubprocessLogger {
  @GuardedBy("this") private lateinit var bufferedWriter: BufferedWriter
  private lateinit var logFile: File

  // Instrument the process execution
  private lateinit var startTime: Instant
  private lateinit var endTime: Instant
  private lateinit var duration: Duration

  companion object {
    @VisibleForTesting val COMMAND_COUNT: AtomicInteger = AtomicInteger(0)

    private val DATETIME_PATTERN =
      DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.systemDefault())
    private val DATETIME_PATTERN_NANO =
      DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSSSS").withZone(ZoneId.systemDefault())

    private val LINE_SEPARATOR = System.lineSeparator()
  }

  @Synchronized
  override fun startLogging(args: List<String>, environment: Map<String, String>) {
    Files.createDirectories(Paths.get(logDir))
    var logFilePrefix = getLogPrefix(args)
    logFile = Paths.get(logDir, "$logFilePrefix.${COMMAND_COUNT.incrementAndGet()}.txt").toFile()
    bufferedWriter = logFile.outputStream().bufferedWriter() // Default buffer size 8 Kb.
    startTime = Instant.now()

    bufferedWriter.write(
      "EXECUTING: ${args.joinToString(" ")}$LINE_SEPARATOR"
        .plus("CURRENT_WORKING_DIRECTORY: ${System.getProperty("user.dir")}$LINE_SEPARATOR")
        .plus("START_TIME: ${DATETIME_PATTERN.format(startTime)}$LINE_SEPARATOR")
        .plus("START_TIME-NANOS: ${DATETIME_PATTERN_NANO.format(startTime)}$LINE_SEPARATOR")
    )
    formatEnvironmentMap(environment)
    bufferedWriter.flush()
  }

  @Synchronized
  private fun formatEnvironmentMap(envMap: Map<String, String>) {
    bufferedWriter.write(
      "ENVIRONMENT:$LINE_SEPARATOR"
        .plus(envMap.toList().map { "${it.first}=${it.second}" }.joinToString(LINE_SEPARATOR))
        .plus("$LINE_SEPARATOR*****************************************$LINE_SEPARATOR")
        .plus("STDOUT/STDERR BELOW$LINE_SEPARATOR")
        .plus("===================$LINE_SEPARATOR")
    )
  }

  @Synchronized
  override fun writeLine(line: String) {
    bufferedWriter.write(line.plus(LINE_SEPARATOR))
    if (flushEagerly) bufferedWriter.flush()
  }

  @Synchronized
  override fun finishLogging(exitCode: Int): String {
    endTime = Instant.now()
    duration = Duration.between(startTime, endTime)
    bufferedWriter.write(
      "===================$LINE_SEPARATOR"
        .plus("END_TIME: ${DATETIME_PATTERN.format(endTime)}$LINE_SEPARATOR")
        .plus("END_TIME-NANOS: ${DATETIME_PATTERN_NANO.format(endTime)}$LINE_SEPARATOR")
        .plus("DURATION: ${duration.toMillis()}ms$LINE_SEPARATOR")
        .plus("EXIT CODE: $exitCode$LINE_SEPARATOR")
    )
    bufferedWriter.flush()
    bufferedWriter.close()
    var suffix =
      when (exitCode) {
        0 -> ".ok.txt"
        143 -> ".aborted.txt" // SIGTERM signal, process explicitly killed.
        else -> ".fail.txt"
      }
    var newName = logFile.absolutePath.replace(Regex(".txt$"), suffix)
    File(newName).let {
      logFile.renameTo(it)
      return it.absolutePath
    }
  }

  override fun getLogPrefix(args: List<String>): String = args.first().split(File.separator).last()
}
