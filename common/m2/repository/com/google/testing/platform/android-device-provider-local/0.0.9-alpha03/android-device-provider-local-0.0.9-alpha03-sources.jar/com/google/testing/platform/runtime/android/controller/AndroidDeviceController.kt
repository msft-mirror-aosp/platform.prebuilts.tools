/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.controller

import com.google.auto.service.AutoService
import com.google.common.annotations.VisibleForTesting
import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.api.device.Device
import com.google.testing.platform.api.device.Device.DeviceType
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.lib.adb.command.inject.AdbCommands
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.adb.command.inject.AdbTimeout
import com.google.testing.platform.proto.api.config.AdbConfigProto
import com.google.testing.platform.proto.api.core.LogMessageProto
import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestArtifactProto.ArtifactType.ANDROID_APK
import com.google.testing.platform.proto.api.core.artifact
import com.google.testing.platform.proto.api.core.path
import com.google.testing.platform.runtime.android.config.AndroidDeviceControllerConfig
import com.google.testing.platform.runtime.android.controller.ext.deviceShell
import com.google.testing.platform.runtime.android.controller.ext.getExtraInstallOptions
import com.google.testing.platform.runtime.android.device.AndroidDevice
import com.google.testing.platform.runtime.android.device.AndroidDeviceProperties
import com.google.testing.platform.runtime.android.device.ext.buildDetail
import com.google.testing.platform.runtime.android.logcat.DefaultLogcatReader
import com.google.testing.platform.runtime.android.logcat.LogcatReader
import java.io.File
import java.time.Duration
import kotlinx.coroutines.flow.Flow

/**
 * Android specific implementation of [DeviceController]. This controller behavior should be able to
 * control most Android devices out of the box, and is a useful "base" [DeviceController] for
 * anything that wants to be an Android [DeviceController]. This will be loaded by the
 * [DeviceProvider].
 *
 * Example Controller Implementations that Delegate to [AndroidDeviceController]:
 *
 * @see
 *   com.google.testing.platform.runtime.android.interactive.controller.InteractiveDeviceController
 *
 * TODO(b/139004294)
 */
@AutoService(DeviceController::class)
class AndroidDeviceController : DeviceController, Configurable {
  companion object {
    private val DEFAULT_ADB_TIMEOUT = Duration.ofSeconds(120L)
    private const val SYSTEM_USER = "0"

    // Max length of a command that be run via adb is 1018, i.e.,
    // The adb protocol limit is 1024. For shell commands the format is 'shell:<command>'
    // The maximum supported limit is 1018 (UTF-8).
    const val MAX_ADB_DEVICE_SHELL_COMMAND_LENGTH = 1018

    private const val SHELL_BINARY = "/system/bin/sh"

    // Interim script prefix for running large commands.
    @VisibleForTesting val DEVICE_SCRIPT_PREFIX = "run_command_"
  }

  lateinit var adbCommands: AdbCommands
  private lateinit var adbTimeout: AdbTimeout
  private lateinit var controlledDevice: AndroidDevice
  private lateinit var environment: Environment
  private lateinit var adbConfig: AdbConfigProto.AdbConfig
  private lateinit var logcatReader: LogcatReader

  override fun configure(context: Context) {
    val config = context.config
    config as AndroidDeviceControllerConfig

    environment = config.environment
    adbConfig = config.adbConfig
    adbTimeout =
      AdbTimeout(
        defaultTimeout =
          if (adbConfig.adbTimeout.defaultAdbTimeout <= 0) {
            DEFAULT_ADB_TIMEOUT
          } else {
            Duration.ofSeconds(adbConfig.adbTimeout.defaultAdbTimeout)
          },
        installCmdTimeout =
          if (adbConfig.adbTimeout.installCmdTimeout <= 0) {
            null
          } else {
            Duration.ofSeconds(adbConfig.adbTimeout.installCmdTimeout)
          },
      )
    adbCommands = config.adbCommands
  }

  override fun getDevice() = controlledDevice

  override fun setDevice(device: Device) {
    device as AndroidDevice
    val originalProperties = device.properties
    controlledDevice = device
    // Create Device controller component which provides TestOrchestrator
    configDeviceProperties(originalProperties)
    configureLogcatReader(controlledDevice)
  }

  override fun streamLogs(): Flow<LogMessageProto.LogMessage> {
    return logcatReader.getLogcatFlow()
  }

  private fun configureLogcatReader(device: Device) {
    logcatReader = DefaultLogcatReader(adbCommands, device)
  }

  private fun configDeviceProperties(originalProperties: AndroidDeviceProperties) {
    val user =
      Telemetry.createEvent("GetUser") {
          phase = TestPhase.SETUP
          run {
            this@AndroidDeviceController.deviceShell(listOf("am", "get-current-user"))
              .output
              .first()
          }
        }
        .getOrThrow()

    controlledDevice.properties =
      Telemetry.createEvent("GetDeviceProperties") {
          phase = TestPhase.SETUP
          onComplete = AndroidDeviceProperties::buildDetail
          run {
            val propMap = getAndroidDevicePropertiesMap()
            val avdName =
              if (controlledDevice.type == DeviceType.VIRTUAL) {
                adbCommands.getAvdName.get().execute(adbTimeout.defaultTimeout)
              } else {
                null
              }
            val props =
              AndroidDeviceProperties(
                propMap,
                avdName = avdName,
                currentUser = user,
                logcatOptions = originalProperties.logcatOptions,
              )
            // By default, /storage is symlinked to /storage/emulated/0. If we are running as a
            // different
            // user, we need to push to the directory (/storage/emulated/USER) instead.
            when {
              user != SYSTEM_USER && props.deviceApiLevel.toInt() >= 30 -> {
                AndroidDeviceProperties(
                  propMap,
                  autoExtraStorageDir = "/mnt/pass_through/$user/emulated/$user/",
                  avdName = avdName,
                  currentUser = user,
                  logcatOptions = originalProperties.logcatOptions,
                )
              }
              user != SYSTEM_USER && props.deviceApiLevel.toInt() >= 28 -> {
                AndroidDeviceProperties(
                  propMap,
                  autoExtraStorageDir = "/storage/emulated/$user",
                  avdName = avdName,
                  currentUser = user,
                  logcatOptions = originalProperties.logcatOptions,
                )
              }
              else -> props
            }
          }
        }
        .getOrThrow()
  }

  private fun getAndroidDevicePropertiesMap(): Map<String, String> {
    return adbCommands.getDeviceEnvVariables
      .get()
      .execute(adbTimeout.defaultTimeout)
      .environmentVars +
      adbCommands.getDeviceProperties.get().execute(adbTimeout.defaultTimeout).deviceProperties
  }

  override fun install(artifact: Artifact): CommandResult {
    require(ANDROID_APK == artifact.type) {
      "Artifact needs to be of type: $ANDROID_APK, but was ${artifact.type}"
    }
    require(artifact.hasSourcePath()) { "Artifact source path needs to be set!" }
    return adbCommands.installApkOnDevice
      .get()
      .execute(
        apkPath = artifact.sourcePath.path,
        timeout = adbTimeout.installCmdTimeout ?: adbTimeout.defaultTimeout,
        additionalFlags =
          this@AndroidDeviceController.getExtraInstallOptions(
            grandRuntimePermissions = true,
            allowVersionDowngrade = true,
          ),
      )
  }

  @CanIgnoreReturnValue
  override fun execute(args: List<String>, timeout: Duration?): CommandResult {
    val cmdTimeout = timeout ?: adbTimeout.defaultTimeout
    val result =
      adbCommands.command.get().execute(convertCommandToShellScriptIfNecessary(args), cmdTimeout)
    return CommandResult(result.statusCode, result.byteOutput)
  }

  override fun executeAsync(args: List<String>, processor: (String) -> Unit): CommandHandle {
    return adbCommands.asyncCommand
      .get()
      .execute(convertCommandToShellScriptIfNecessary(args), processor)
  }

  override fun push(artifact: Artifact): Int {
    require(artifact.hasSourcePath() && artifact.hasDestinationPath()) {
      "Artifact source and destination paths need to be set!"
    }
    return adbCommands.pushToDevice
      .get()
      .execute(artifact.sourcePath.path, artifact.destinationPath.path, adbTimeout.defaultTimeout)
  }

  override fun pull(artifact: Artifact): Int {
    require(artifact.hasSourcePath() && artifact.hasDestinationPath()) {
      "Artifact source and destination paths need to be set!"
    }
    return adbCommands.pullFromDevice
      .get()
      .execute(artifact.destinationPath.path, artifact.sourcePath.path, adbTimeout.defaultTimeout)
  }

  /**
   * Convert device shell commands to a script if necessary and pushes it to the device.
   *
   * @param args list of strings forming the complete shell command
   * @return List of strings with the final command, could be the original command or the fully
   *   formed command to run the script.
   */
  private fun convertCommandToShellScriptIfNecessary(args: List<String>): List<String> {
    // Check if the command is to run on the device shell.
    if (args[0] != "shell") return args
    val fullCommand = args.drop(1).joinToString(" ") // Drop the shell keyword.
    if (fullCommand.length < MAX_ADB_DEVICE_SHELL_COMMAND_LENGTH) {
      return args // Do nothing. The command can run as is.
    }

    val localScript =
      File.createTempFile(DEVICE_SCRIPT_PREFIX, ".sh", File(environment.tempDirectory)).also {
        it.deleteOnExit()
      }
    localScript.writeText(fullCommand)

    // Calculate the device path using posix semantics vs utp host (windows/posix) semantics.
    // Note: We assume externalStorageDir is a posix path.
    val devicePath = "${controlledDevice.properties.externalStorageDir}/${localScript.name}"
    val tempArtifact = artifact {
      sourcePath = path { path = localScript.absolutePath }
      destinationPath = path { path = devicePath }
    }
    this.push(tempArtifact)
    // Since we're using the 'sh' binary directly, we don't need to change the permissions on the
    // script.
    return listOf("shell", SHELL_BINARY, devicePath) // Args of the final command to run.
  }
}
