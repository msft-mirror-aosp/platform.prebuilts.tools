/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.provider.local

import com.google.auto.service.AutoService
import com.google.common.annotations.VisibleForTesting
import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.Setup
import com.google.testing.platform.api.config.androidSdk
import com.google.testing.platform.api.config.environment
import com.google.testing.platform.api.config.parseConfig
import com.google.testing.platform.api.config.setup
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.device.Device.DeviceType
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.config.v1.extension.adbServerPortOrDefault
import com.google.testing.platform.config.v1.extension.deviceSerialOrDefault
import com.google.testing.platform.config.v1.extension.hostOrDefault
import com.google.testing.platform.config.v1.extension.isValid
import com.google.testing.platform.core.device.DeviceProviderErrorSummary
import com.google.testing.platform.core.device.DeviceProviderException
import com.google.testing.platform.lib.adb.command.ListDevicesCmd
import com.google.testing.platform.lib.adb.command.ListDevicesCmdImpl
import com.google.testing.platform.lib.adb.command.inject.AdbCommandComponent
import com.google.testing.platform.lib.adb.command.inject.AdbCommands
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.adb.command.inject.DaggerAdbCommandComponent
import com.google.testing.platform.lib.adb.command.monitor.AdbDeviceMonitor
import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor
import com.google.testing.platform.lib.adb.command.monitor.NoopDeviceMonitor
import com.google.testing.platform.lib.adb.command.parser.AdbDevicesLineProcessor
import com.google.testing.platform.lib.adb.command.subprocess.executor.AdbCommandExecutor
import com.google.testing.platform.lib.adb.command.subprocess.parser.DevicesListLineProcessorParser
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.LocalAndroidDeviceProviderProto.LocalAndroidDeviceProvider as LocalAndroidDeviceProviderConfig
import com.google.testing.platform.runtime.android.AndroidDeviceProvider
import com.google.testing.platform.runtime.android.device.AndroidDevice
import com.google.testing.platform.runtime.android.provider.ext.loadAndConfigureAndroidDeviceController

/**
 * Provisions an [AndroidDevice] and returns a [DeviceController]. Gets an Android device by
 * connecting to a specific device with {@code adb connect} or finds any available device by running
 * {@code adb devices}.
 */
@AutoService(DeviceProvider::class)
class LocalAndroidDeviceProvider(
  private val adbCommandComponentBuilder: AdbCommandComponent.Builder,
  private val deviceMonitorSupplier: (config: AdbConfig) -> DeviceMonitor,
  private val listDevicesCmdSupplier:
    (adbConfig: AdbConfig, androidSdk: AndroidSdk) -> ListDevicesCmd,
) : AndroidDeviceProvider, Configurable {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  private lateinit var context: Context
  private lateinit var environment: Environment
  private lateinit var testSetup: Setup
  private lateinit var androidSdk: AndroidSdk
  private lateinit var deviceMonitor: DeviceMonitor

  // Accessed by MobileDeviceFarmLocalAndroidDeviceProvider which uses this class as a delegate.
  lateinit var adbCommands: AdbCommands

  @VisibleForTesting lateinit var deviceProviderConfig: LocalAndroidDeviceProviderConfig

  // No-arg constructor for Autoservice
  constructor() :
    this(
      adbCommandComponentBuilder = DaggerAdbCommandComponent.builder(),
      deviceMonitorSupplier = { adbConfig: AdbConfig -> AdbDeviceMonitor(adbConfig) },
      listDevicesCmdSupplier = { adbConfig: AdbConfig, androidSdk: AndroidSdk ->
        ListDevicesCmdImpl(
          AdbCommandExecutor(adbConfig, androidSdk),
          DevicesListLineProcessorParser(AdbDevicesLineProcessor()),
        )
      },
    )

  /**
   * Called to 'inject' config into this class. as
   *
   * @param config The config class which has all the required data classes.
   */
  override fun configure(context: Context) {
    this.context = context
    val config = context.config
    environment = config.environment
    testSetup = config.setup
    androidSdk = config.androidSdk
    deviceProviderConfig = validateLocalDeviceProviderConfig(config.parseConfig()!!)
  }

  override fun cancel(aborted: Boolean) = false

  /**
   * Provides an [AndroidDevice]. Throws [DeviceProviderException] when no device is available or if
   * the Adb command returned with a failed exit code. Provides the device from the config. If no
   * device was provided in the config, the first device connected to the adb server is provided
   * instead.
   */
  private fun makeDevice(): AndroidDevice {
    // This is just to find the connected device if serial/adbPort is not specified
    var foundDevice: AndroidDevice? = null
    if (!deviceProviderConfig.isValid()) {
      val tmpAdbConfig =
        AdbConfig(outputDirectory = environment.outputDirectory, adbPath = androidSdk.adbPath)
      foundDevice =
        findDevice(listDevicesCmdSupplier(tmpAdbConfig, androidSdk), deviceProviderConfig)
    }
    val adbConfig =
      AdbConfig(
        outputDirectory = environment.outputDirectory,
        adbPath = androidSdk.adbPath,
        adbServerPort = deviceProviderConfig.adbServerPortOrDefault,
        deviceSerial =
          if (deviceProviderConfig.isValid()) deviceProviderConfig.deviceSerialOrDefault
          else foundDevice!!.serial,
        adbServerHost = deviceProviderConfig.host,
        adbPort = deviceProviderConfig.adbPort,
      )
    // Use the AdbDeviceMonitor if necessary.
    deviceMonitor =
      if (deviceProviderConfig.enableDeviceStateMonitoring) {
        deviceMonitorSupplier(adbConfig)
      } else {
        NoopDeviceMonitor()
      }
    val adbCommandComponent: AdbCommandComponent =
      adbCommandComponentBuilder
        .adbConfig(adbConfig)
        .androidSdk(androidSdk)
        .deviceMonitor(deviceMonitor)
        .build()
    adbCommands = adbCommandComponent.adbCommands
    logger.fine("Device provider configuration: $deviceProviderConfig")
    return if (deviceProviderConfig.isValid()) {
      connectAndReturnDevice(adbCommands, deviceProviderConfig)
    } else {
      foundDevice!!
    }
  }

  override fun provideDevice(): DeviceController {
    val androidDevice = makeDevice()
    val deviceController: DeviceController
    try {
      // Start the monitor before running any commands on the device.
      deviceMonitor.start()
      deviceController =
        loadAndConfigureAndroidDeviceController(
          environment,
          testSetup,
          androidSdk,
          deviceProviderConfig.adbConfig,
          deviceProviderConfig.androidInstrumentationRuntime,
          adbCommands,
          context,
        )
    } catch (throwable: Throwable) {
      throw DeviceProviderException(
        "Loading and configuring DeviceController failed, make sure the device controller is" +
          " present as a part of the same jar the DeviceProvider is part of.",
        DeviceProviderErrorSummary.UNDETERMINED,
        throwable,
      )
    }
    deviceController.setDevice(androidDevice)
    return deviceController
  }

  override fun releaseDevice() {
    // No need to release the local device after usage since we didn't start it.
    // Close device monitors.
    deviceMonitor.close()
  }

  /**
   * Makes sure there is configuration info to contact adb server. Does not use config.isValid()
   * since that validates the config fully identifies a device.
   */
  private fun validateLocalDeviceProviderConfig(
    config: LocalAndroidDeviceProviderConfig
  ): LocalAndroidDeviceProviderConfig {
    require(config.hostOrDefault.isNotBlank()) {
      "DeviceProviderConfig must contain adbServerPort and either host, was given:\n$config"
    }
    return config
  }

  private fun deviceIsConnected(deviceSerial: String): Boolean {
    return adbCommands.listDevices.get().execute().devices.any { it == deviceSerial }
  }

  private fun connectAndReturnDevice(
    adbCommands: AdbCommands,
    config: LocalAndroidDeviceProviderConfig,
  ): AndroidDevice {
    val device = deviceFromConfig(config, environment)

    // It's a physical device and we do not need to connect using "adb connect".
    if (device.port == null || device.type == DeviceType.PHYSICAL) {
      return device
    }

    if (deviceIsConnected(device.serial)) {
      return device
    }

    logger.fine("Connecting to device: ${device.serial}")
    val connectCmd = adbCommands.connect.get()
    val exitCode = connectCmd.connect(device.host, device.port!!)
    if (exitCode != 0) {
      throw DeviceProviderException("Couldn't connect to device: ${device.serial}")
    }
    return device
  }

  private fun findDevice(
    listDevicesCmd: ListDevicesCmd,
    config: LocalAndroidDeviceProviderConfig,
  ): AndroidDevice {
    val deviceList = listDevicesCmd.execute()
    val devices = deviceList.devices
    logger.fine("Found ${devices.size} device(s): $devices")
    when {
      devices.isEmpty() ->
        throw DeviceProviderException(
          """Unable to find an Android device. Adb exit code: ${deviceList.exitCode}.
          |Did you forget to start/plug in your device? Also check whether your device is listed
          |when running `adb devices`. If your device is plugged in but not listed, it's likely adb
          |did not connect to your device automatically, as adb only looks for devices listening on
          |ports between 5555 and 5585. Try manually connecting to the device using
          |`adb connect ${'$'}DEVICE_IP_ADDRESS:${'$'}PORT` if your device is using a port outside
          |of the range.
          """
            .trimMargin()
        )
      devices.size > 1 -> {
        logger.info("More than one device found. Using the first device: ${devices[0]}")
      }
    }
    return deviceFromSerial(devices[0], config, environment).also {
      logger.fine("Using device: $it")
    }
  }
}
