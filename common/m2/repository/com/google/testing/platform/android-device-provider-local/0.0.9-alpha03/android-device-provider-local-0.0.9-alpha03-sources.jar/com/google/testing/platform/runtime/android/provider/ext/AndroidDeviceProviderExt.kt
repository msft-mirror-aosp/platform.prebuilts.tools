/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.provider.ext

import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.Setup
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.lib.adb.command.inject.AdbCommands
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.AdbConfigProto
import com.google.testing.platform.proto.api.config.RuntimeProto
import com.google.testing.platform.runtime.android.AndroidDeviceProvider
import com.google.testing.platform.runtime.android.config.AndroidDeviceControllerConfig
import com.google.testing.platform.runtime.android.config.AndroidUTPContext
import java.util.ServiceLoader
import java.util.logging.Logger

/**
 * Service loads and configures the [DeviceController]. Loads the [DeviceController] in the same
 * [ClassLoader] as the []DeviceProvider]. If more than two implementations are found loads the
 * first one and logs a warning.
 */
fun AndroidDeviceProvider.loadAndConfigureAndroidDeviceController(
  environment: Environment,
  testSetup: Setup,
  androidSdk: AndroidSdk,
  adbConfig: AdbConfigProto.AdbConfig,
  instrumentationRuntimeConfig: RuntimeProto.AndroidInstrumentationRuntime,
  adbCommands: AdbCommands,
  context: Context,
  defaultLogger: Logger = getLogger(),
): DeviceController {
  val serviceLoader = ServiceLoader.load(DeviceController::class.java, this.javaClass.classLoader)
  val service = serviceLoader.first()

  if (serviceLoader.spliterator().exactSizeIfKnown > 2) {
    defaultLogger.warning(
      "More than one implementation of device controller found!" + " Using the first one."
    )
  }
  service as Configurable
  val config =
    AndroidDeviceControllerConfig(
      environment,
      testSetup,
      androidSdk,
      adbConfig,
      instrumentationRuntimeConfig,
      adbCommands,
    )
  service.configure(AndroidUTPContext(delegate = context, config = config))
  return service
}
