/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import java.time.Duration

/**
 * Executes a given shell command. The implementation is responsible for determining the environment
 * in which the command is executed.
 */
interface CommandExecutor {

  /**
   * Executes a command.
   *
   * @param commandArgs an ordered array of strings that construct a command, e.g. {"echo", "hello"}
   * @param timeout the timeout for this command.
   * @return [CommandResult] with status code and command output
   */
  fun execute(commandArgs: Array<String>, timeout: Duration): CommandResult

  /**
   * Execute a command asynchronusly.
   *
   * @param commandArgs an ordered array of strings that construct a command, e.g. {"echo", "hello"}
   * @param processor a lambda that processes output lines on the fly.
   * @return [CommandHandle] which can be used to interact with the command.
   */
  fun executeAsync(commandArgs: Array<String>, processor: (String) -> Unit): CommandHandle
}
