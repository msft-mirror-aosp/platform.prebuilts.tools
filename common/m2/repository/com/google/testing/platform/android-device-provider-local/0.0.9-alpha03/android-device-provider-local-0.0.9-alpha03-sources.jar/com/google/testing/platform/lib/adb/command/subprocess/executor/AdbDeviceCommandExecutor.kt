/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.subprocess.executor

import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.api.device.DeviceErrorSummary
import com.google.testing.platform.api.device.DeviceException
import com.google.testing.platform.lib.adb.command.CommandExecutor
import com.google.testing.platform.lib.adb.command.DeviceCommandExecutor
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor
import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor.DeviceState
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Duration
import javax.inject.Inject

/**
 * Runs adb commands on a specific device or emulator.
 *
 * Commands are executed in the following format:
 *
 * adb -s <serial> <command> <list_of_args>
 *
 * Examples:
 *
 * Emulator:
 * ```
 *     adb -s emulator-5555 push foo.txt /sdcard/foo.txt
 * ```
 *
 * Real Device:
 * ```
 *     adb -s 0a388e93 install HelloWorld.apk
 *
 * @see
 * ```
 *
 * <a href="https://developer.android.com/studio/command-line/adb">Android Debug Bridge (adb) </a>
 */
class AdbDeviceCommandExecutor
@Inject
constructor(
  private val config: AdbConfig,
  private val adbCommandExecutor: CommandExecutor,
  private val deviceMonitor: DeviceMonitor,
) : DeviceCommandExecutor {

  init {
    check(!config.deviceSerial.isNullOrBlank()) {
      "Invalid adb config. No device serial specified.\n$config"
    }
  }

  private fun supplyTargetDevice(commandArgs: Array<String>): Array<String> {
    return arrayOf("-s", config.deviceSerial!!, *commandArgs)
  }

  override fun execute(commandArgs: Array<String>, timeout: Duration): CommandResult {
    checkDeviceState()
    return adbCommandExecutor.execute(supplyTargetDevice(commandArgs), timeout)
  }

  override fun executeAsync(
    commandArgs: Array<String>,
    processor: (String) -> Unit,
  ): CommandHandle {
    checkDeviceState()
    return adbCommandExecutor.executeAsync(supplyTargetDevice(commandArgs), processor)
  }

  /**
   * Check [DeviceState] is DEVICE which means the device is connected and can be interacted with.
   *
   * Note: Even after this check, there could be scenarios where the device disconnects before any
   * device command is executed.
   */
  private fun checkDeviceState() {
    if (deviceMonitor.state != DeviceState.DEVICE) {
      throw DeviceException(
        errorSummary = DeviceErrorSummary.DEVICE_DISCONNECTED,
        message =
          "Device ${config.deviceSerial} disconnected. Current state: ${deviceMonitor.state}.",
      )
    }
  }

  companion object {
    @JvmStatic private val logger = getLogger()
  }
}
