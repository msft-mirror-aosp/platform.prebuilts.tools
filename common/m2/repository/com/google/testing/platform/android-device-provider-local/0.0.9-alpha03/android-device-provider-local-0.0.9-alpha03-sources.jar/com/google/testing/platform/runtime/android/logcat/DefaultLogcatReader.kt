/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.logcat

import com.google.testing.platform.api.device.Device
import com.google.testing.platform.lib.adb.command.inject.AdbCommands
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.LogMessageProto
import com.google.testing.platform.proto.api.core.LogMessageProto.LogMessage
import com.google.testing.platform.proto.api.core.LogMessageProto.LogMessage.Level
import com.google.testing.platform.proto.api.core.logMessage
import com.google.testing.platform.runtime.android.device.AndroidDevice
import com.google.type.Date
import com.google.type.TimeOfDay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.logging.Level as JavaLogLevel
import java.util.regex.Pattern
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.ChannelResult
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map

/**
 * Starts the logcat process and parse the lines into a [LogMessageProto.LogMessage]
 *
 * The stream starts from the current device time when the stream is requested. If it fails to get
 * the current device time, the whole buffer will be dumped.
 *
 * We use the logcat command's '-T' option to filter the logcat messages from the time of
 * invocation, when available. If not, we use `logcat -c` to clear the log.
 * * '-T' option does not exist on APIs <= 19.
 * * '-T' option does not accept year for API level <= 23 : "12-25 13:10:45.123" is the supported
 *   timestamp.
 * * '-T' option accepts year for API level > 23: "2022-12-25 13:10:45.123" and "12-25 13:10:45.123"
 *   are valid.
 */
class DefaultLogcatReader(private val adbCommands: AdbCommands, private val device: Device) :
  LogcatReader {

  private val logcatFlow =
    callbackFlow {
        device as AndroidDevice
        var currentDeviceTimeLogcatCmdOption = emptyList<String>()
        val apiLevel = device.properties.deviceApiLevel.toIntOrNull() ?: 0
        if (apiLevel >= 21) {
          val currentDeviceTime = adbCommands.command.get().execute(DATE_COMMAND)
          if (currentDeviceTime.statusCode == 0) {
            currentDeviceTimeLogcatCmdOption = listOf("-T", "\"${currentDeviceTime.output[0]}\"")
          } else {
            logger.warning(
              "Failed to get device time.\n" +
                "${currentDeviceTime.output.joinToString(System.lineSeparator())}"
            )
          }
        } else {
          adbCommands.command.get().execute(CLEAR_LOGCAT_COMMAND)
        }
        val logcatCommandHandle =
          adbCommands.asyncCommand
            .get()
            .execute(
              args =
                listOf("shell", "logcat", "-v", "threadtime") +
                  currentDeviceTimeLogcatCmdOption +
                  device.properties.logcatOptions,
              processor = { message ->
                val result: ChannelResult<Unit> = trySend(message)
                if (result.isFailure) {
                  result.exceptionOrNull()?.let { exception ->
                    val level =
                      when {
                        // "kotlinx.coroutines.flow.internal.ChildCancelledException: Child of the
                        // scoped flow was cancelled" is normal, so don't log it.
                        exception is CancellationException -> JavaLogLevel.FINEST
                        else -> JavaLogLevel.WARNING
                      }
                    logger.log(level, "Failed to send $message", exception)
                  }
                }
              },
            )
        awaitClose {
          if (logcatCommandHandle.isRunning()) {
            logcatCommandHandle.stop()
            logcatCommandHandle.waitFor()
          }
        }
      }
      // Start buffering before we map, because dalvikvm can get very bursty
      .buffer(capacity = LOGCAT_MAX_BUFFER_SIZE, onBufferOverflow = BufferOverflow.DROP_OLDEST)
      .map { parseLogcatLine(it) }
      .filterNotNull()

  override fun getLogcatFlow(): Flow<LogMessage> {
    return logcatFlow
  }

  companion object {

    val logger = getLogger()

    // Date command used to display the current device time and stream logcat messages only from
    // that instant. For milliseconds we just append .000 since '%3N' option is available only from
    // API 27 and above. We ignore year as it is supported in logcat only from API level > 23.
    // For API level >= 27 `date "%m-%d\ %H:%M:%S.%3N"` is valid. (to get the timestamp at a
    // millisecond level)
    // For API level < 27 `date "+%m-%d\ %H:%M:%S.000` is valid
    private val DATE_COMMAND = listOf("shell", "date", "+%m-%d\\ %H:%M:%S.000")

    private val CLEAR_LOGCAT_COMMAND = listOf("shell", "logcat", "-c")

    // Maximum size of the logcat buffer on device is 16 MB.
    const val LOGCAT_MAX_BUFFER_SIZE = 16 * 1024 * 1024

    // Logcat from the "threadtime" format. Example line:
    // 12-16 00:00:00.000 481 481 E netmgr : Failed to open QEMU pipe 'qemud:network': Invalid
    // argument
    // The tag field will be a minimum of 8 characters with spaces being padded until ": "
    // which is the separator before the log message starts.
    // The tag field supports ":" and whitespaces.
    private val ANDROID_LOGCAT_THREADTIME_REGEX =
      Pattern.compile(
          // timestamp
          """^(\d{2})-(\d{2}) (\d{2}:\d{2}:\d{2}.\d{3})\s+""" +
            // pid tid priority
            """(\d+)\s+(\d+)\s+([VDIWEFS])\s""" +
            // tag: message
            """(.{8,}?):\s(.*)$"""
        )
        .toRegex()

    fun parseLogcatLine(line: String): LogMessage {
      val result =
        ANDROID_LOGCAT_THREADTIME_REGEX.matchEntire(line) ?: return logMessage { message = line }

      val (month, day, time, processId, threadId, logLevel, tag, message) = result.destructured
      val parsedTime = LocalTime.parse(time, DateTimeFormatter.ofPattern("HH:mm:ss.SSS"))
      try {
        return logMessage {
          pid = processId.toInt()
          tid = threadId.toInt()

          // Unfortunately Android levels 22 and lower do not support additional format modifiers
          // like "threadtime[UTC|epoch|year]". This makes it hard to reliably fetch the year of the
          // logs in threadtime format. So we simply set the year to 0 as the year is not a terribly
          // useful part of a log message.
          date =
            Date.newBuilder()
              .apply {
                year = 0
                this.month = month.toInt()
                this.day = day.toInt()
              }
              .build()
          this.time =
            TimeOfDay.newBuilder()
              .apply {
                this.hours = parsedTime.hour
                this.minutes = parsedTime.minute
                this.seconds = parsedTime.second
                this.nanos = parsedTime.nano
              }
              .build()
          level =
            when (logLevel) {
              "V" -> Level.VERBOSE
              "D" -> Level.DEBUG
              "I" -> Level.INFO
              "W" -> Level.WARNING
              "E" -> Level.ERROR
              "F" -> Level.FATAL
              else -> Level.LEVEL_UNSPECIFIED
            }
          // Logcat adds whitespace padding for tags less than 8 characters long
          tags += tag.trimEnd()
          this.message = message
        }
      } catch (e: Exception) {
        // Best effort to parse a log line. Return the full line we received.
        return logMessage { this.message = line.trim() }
      }
    }
  }
}
