/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process

import java.time.Duration
import java.util.concurrent.TimeoutException

/** Interface to interact with a running process invoked by [Subprocess.execute] */
interface Handle {
  /**
   * Get exit code of the command.
   *
   * If this method is called before the process terminates, an [IllegalStateException] will be
   * thrown.
   */
  @Throws(IllegalStateException::class) fun exitCode(): Int

  /**
   * Stop a process. Whether the subprocess represented by the process object is forcibly terminated
   * or not is implementation dependent. Will be a no-op if the process has already stopped. If a
   * timeout is specified, destroys the process forcibly if it does not join after the timeout.
   *
   * It returns immediately after sending the termination signal to the process. Use
   * [destroyAndJoin] to wait for the underlying process to exit.
   */
  fun destroy(forciblyAfter: Duration? = null)

  /** Check if the process is still running. */
  fun isAlive(): Boolean

  /**
   * Wait for the process to exit
   *
   * Will wait indefinitely if the [timeout] is `null`.
   *
   * @params timeout timeout to wait for the process to exit. Default: null
   * @throws TimeoutExceptoon if the process doesn't exit within the given timeout
   */
  @Throws(TimeoutException::class) fun waitFor(timeout: Duration? = null)

  /** Returns the native process id of the handle. Returns -1 if the process is not alive. */
  fun pid(): Long
}

/**
 * Stop a process. Whether the subprocess represented by the process object is forcibly terminated
 * or not is implementation dependent. Will be a no-op if the process has already stopped.
 *
 * It waits for the process to exit before returning. Use [destroy] to return immediately after
 * sending the termination signal to the underlying process.
 */
fun Handle.destroyAndJoin() {
  destroy()
  waitFor()
}
