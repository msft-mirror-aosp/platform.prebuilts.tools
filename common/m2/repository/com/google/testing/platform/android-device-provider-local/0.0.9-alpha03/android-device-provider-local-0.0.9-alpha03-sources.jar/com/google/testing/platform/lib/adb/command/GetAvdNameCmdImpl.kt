/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Duration
import javax.inject.Inject

/** Runs the {@code adb emu get name} command and returns the avd name. */
class GetAvdNameCmdImpl @Inject constructor(private val commandExecutor: DeviceCommandExecutor) :
  GetAvdNameCmd {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  override fun execute(timeout: Duration): String? {
    val (exitCode, outputs) = commandExecutor.execute(arrayOf("emu", "avd", "name"), timeout)
    if (exitCode != 0) {
      return null
    }
    // The output has the following format:
    // (optional) "* daemon not running; starting now at tcp:5037"
    // (optional) "* daemon started successfully"
    // "[AVD name]"
    // "OK"
    // Sometimes there are extra empty lines on Windows.
    val outputsNoEmptyLine = outputs.mapNotNull { if (it.isNotEmpty()) it.trim() else null }
    val okLineIdx = outputsNoEmptyLine.indexOfFirst { it == "OK" }
    if (okLineIdx <= 0) return null
    return outputsNoEmptyLine[okLineIdx - 1].trim()
  }
}
