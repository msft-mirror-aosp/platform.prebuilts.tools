/*
 *
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import java.time.Duration

/**
 * Gets the getprop set of the device currently. The implementation should return a map of variables
 * along with the command's exit code.
 *
 * Runs the command: {@code adb emu avd name}
 */
interface GetAvdNameCmd {
  /**
   * Executes the command to get AVD name: {@code adb emu avd name}
   *
   * If the device is not an emulator, it will return null.
   *
   * Upon failure of executing the command (command returns an exit code other than zero), it also
   * returns null.
   *
   * @param timeout for this command, defaults to 120 seconds when no timeout is given.
   * @return the AVD name.
   */
  fun execute(timeout: Duration = Duration.ofSeconds(120L)): String?
}
