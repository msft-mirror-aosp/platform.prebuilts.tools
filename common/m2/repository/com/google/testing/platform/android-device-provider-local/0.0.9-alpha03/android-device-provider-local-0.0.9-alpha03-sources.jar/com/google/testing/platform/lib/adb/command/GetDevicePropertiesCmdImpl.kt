/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.lib.adb.command.parser.ShellGetPropParser
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Duration
import javax.inject.Inject

/** Runs the [adb shell getprop ] command and returns the read only device properties. */
class GetDevicePropertiesCmdImpl
@Inject
constructor(
  private val commandExecutor: DeviceCommandExecutor,
  private val parser: ShellGetPropParser
) : GetDevicePropertiesCmd {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  override fun execute(timeout: Duration): DeviceProperties {
    // Get the read only properties from the device (those that start with ro. are read only)
    val (exitCode, output) = commandExecutor.execute(arrayOf("shell", "getprop"), timeout)
    if (exitCode != 0) {
      throw AdbCommandException(
        """Adb getprop command failed.
        |Exit Code: $exitCode"
        |Output: $output
        |"""
          .trimMargin()
      )
    }
    val deviceProperties = parser.from(output)
    return DeviceProperties(deviceProperties, exitCode)
  }
}
