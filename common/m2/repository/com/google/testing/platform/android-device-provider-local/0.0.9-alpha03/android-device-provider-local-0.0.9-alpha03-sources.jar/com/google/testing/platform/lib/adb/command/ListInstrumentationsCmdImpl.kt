/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

import com.google.testing.platform.lib.adb.command.parser.InstrumentationListParser
import java.time.Duration
import javax.inject.Inject

/** Lists instrumentations on the device. */
class ListInstrumentationsCmdImpl
@Inject
constructor(
  private val commandExecutor: DeviceCommandExecutor,
  private val parser: InstrumentationListParser
) : ListInstrumentationsCmd {
  override fun execute(timeout: Duration): Instrumentations {
    val (exitCode, output) =
      commandExecutor.execute(arrayOf("shell", "pm", "list", "instrumentation"), timeout)

    val instrumentations = parser.from(output)
    return Instrumentations(instrumentations.mapNotNull { it }.toSet(), exitCode)
  }
}
