/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process.inject

import com.google.common.util.concurrent.ThreadFactoryBuilder
import com.google.testing.platform.lib.process.Subprocess
import com.google.testing.platform.lib.process.SubprocessImpl
import com.google.testing.platform.lib.process.annotation.SubprocessCoroutineScope
import com.google.testing.platform.lib.process.logger.SubprocessLogger
import dagger.Module
import dagger.Provides
import java.util.concurrent.Executors
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.asCoroutineDispatcher

/** Dagger module for [Subprocess] */
@ExperimentalCoroutinesApi
@Module
class SubprocessModule {
  @Provides
  fun subprocess(
    subprocessLoggerFactory: SubprocessLogger.Factory,
    @SubprocessCoroutineScope scope: CoroutineScope,
  ): Subprocess =
    SubprocessImpl(coroutineScope = scope, subprocessLogger = subprocessLoggerFactory.create())

  @Provides
  @Singleton
  @SubprocessCoroutineScope
  fun ioCoroutineScope(): CoroutineScope =
    CoroutineScope(
      Executors.newCachedThreadPool(ThreadFactoryBuilder().setNameFormat("Subprocess-%d").build())
        .asCoroutineDispatcher() + CoroutineName("ioCoroutineScope")
    )
}
