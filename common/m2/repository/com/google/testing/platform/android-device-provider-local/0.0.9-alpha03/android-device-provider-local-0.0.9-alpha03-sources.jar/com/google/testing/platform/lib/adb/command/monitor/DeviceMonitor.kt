/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.monitor

/** Interface to track devices and their current state reported by adb. */
interface DeviceMonitor : AutoCloseable {

  /**
   * Enum states corresponding to the states returned by adb for devices.
   *
   * Source :
   * https://cs.android.com/android/platform/superproject/main/+/main:packages/modules/adb/adb.h;l=105;drc=d0db47dcdf941673f405e1095e6ffb5e565902e5
   */
  enum class DeviceState {
    DEVICE,
    OFFLINE,
    RECOVERY,
    RESCUE,
    SIDELOAD,
    UNAUTHORIZED,
    AUTHORIZING,
    CONNECTING,
    MISSING,
    UNKNOWN
  }

  /** Start monitoring device state from adb. */
  fun start()

  /** The current state of the device. */
  val state: DeviceState
}
