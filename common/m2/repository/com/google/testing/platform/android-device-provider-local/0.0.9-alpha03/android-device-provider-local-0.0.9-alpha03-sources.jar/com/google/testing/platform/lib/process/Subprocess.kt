/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.process

import com.google.testing.platform.api.device.CommandResult
import java.time.Duration

/** Interface to execute a shell command. */
interface Subprocess {
  /**
   * Executes a shell command asynchronously supplied by [args].
   *
   * @param args list of strings composing the command.
   * @param environment set up additional environment variable for the process. Default: empty map.
   * @param stdoutProcessor lambda to handle lines generated as part of stdout by the process. If
   *   [stdoutProcessor] is not supplied, command will execute and not return any output.
   * @param stderrProcessor lambda to handle lines generated as part of stderr by the process. If
   *   [stderrProcessor] is not supplied, the stdout and stderr output streams are merged.
   * @return [Handle] representing the state of the process.
   */
  fun executeAsync(
    args: List<String>,
    environment: Map<String, String> = emptyMap(),
    stdoutProcessor: ((String) -> Unit)? = null,
    stderrProcessor: ((String) -> Unit)? = null
  ): Handle

  /**
   * Executes a shell command synchronously supplied by [args] and returns the output as a byte
   * array.
   *
   * This is a blocking call.
   *
   * @param args list of strings composing the command.
   * @param environment set up additional environment variable for the process. Default: empty map.
   * @param timeout duration to wait for the command to complete. Default: No timeout. The call will
   *   block till the process exits.
   * @return the command result.
   * @throws TimeoutException when the process doesn't exit within the given [timeout] duration.
   *   Upon timeout, we also attempt to destroy the spawned process forcefully.
   */
  fun execute(
    args: List<String>,
    environment: Map<String, String> = emptyMap(),
    timeout: Duration? = null
  ): CommandResult
}

/**
 * Executes a shell command synchronously supplied by [args].
 *
 * This is a blocking call. If [stderrProcessor] is not supplied, the stdout and stderr output
 * streams are merged.
 *
 * @param args list of strings composing the command.
 * @param environment set up additional environment variable for the process. Default: empty map.
 * @param timeout timeout to wait for the command to complete. Default: No timeout. The call will
 *   block till the process exits.
 * @param stdoutProcessor lambda to handle lines generated as part of stdout by the process. If
 *   [stdoutProcessor] is not supplied, command will execute and not return any output.
 * @param stderrProcessor lambda to handle lines generated as part of stderr by the process.
 * @return exit code of the command.
 * @throws TimeoutException if the process doesn't exit within the given timeout.
 */
fun Subprocess.executeSync(
  args: List<String>,
  environment: Map<String, String> = emptyMap(),
  timeout: Duration? = null,
  stdoutProcessor: ((String) -> Unit)? = null,
  stderrProcessor: ((String) -> Unit)? = null
): Int {
  val handle = executeAsync(args, environment, stdoutProcessor, stderrProcessor)
  handle.waitFor(timeout)
  return handle.exitCode()
}
