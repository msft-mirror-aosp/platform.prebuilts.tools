/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.monitor

import com.google.testing.platform.api.device.DeviceErrorSummary
import com.google.testing.platform.api.device.DeviceException
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.adb.command.monitor.AdbProtocolHelper.Status.FAIL
import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor.DeviceState
import com.google.testing.platform.lib.coroutines.NamedThreadFactory
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.net.Inet4Address
import java.net.InetAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** [DeviceMonitor] implementation using adb protocol with the adb server. */
class AdbDeviceMonitor(private val config: AdbConfig) : DeviceMonitor {

  private lateinit var socket: Socket

  private val executor: ExecutorService =
    Executors.newSingleThreadExecutor(NamedThreadFactory("AdbDeviceMonitor-${config.deviceSerial}"))

  private val devicesAndStates = ConcurrentHashMap<String, DeviceState>()

  override fun start() {
    val localhostAddresses = InetAddress.getAllByName("localhost")
    // Try and get IPv4 loopback address if available, otherwise just use the IPv6 address.
    val localhostAddress =
      localhostAddresses.filterIsInstance(Inet4Address::class.java).firstOrNull()
        ?: localhostAddresses.first()
    socket = Socket(localhostAddress, config.adbServerPort ?: DEFAULT_ADB_SERVER_PORT)

    AdbProtocolHelper.sendPayload(socket.getOutputStream(), TRACK_DEVICES_COMMAND)

    val statusResponse = AdbProtocolHelper.readStatusResponse(socket.getInputStream())
    if (statusResponse.status == FAIL) {
      throw DeviceException(
        errorSummary = DeviceErrorSummary.ADB_SERVER_ERROR,
        message =
          "Adb server response for '$TRACK_DEVICES_COMMAND'\nStatus: ${statusResponse.status}\n" +
            "Failure Message: ${statusResponse.failureMessage}",
      )
    }
    logger.info(
      "Monitoring started for device ${config.deviceSerial} on server port ${config.adbServerPort}."
    )

    // Gather the initial device state.
    devicesAndStates.putAll(AdbProtocolHelper.readDeviceState(socket.getInputStream()))

    // Keep track of states asynchronously
    executor.execute { trackDeviceStates() }
  }

  private fun trackDeviceStates() {
    socket.getInputStream().use { inputStream ->
      while (socket.isConnected) {
        val newStateUpdate = AdbProtocolHelper.readDeviceState(inputStream)
        if (newStateUpdate.isNotEmpty()) {
          logger.fine("-------- Updates: ${devicesAndStates.entries.joinToString(", ")} ----------")
          if (devicesAndStates[config.deviceSerial] != newStateUpdate[config.deviceSerial]) {
            logger.info("DEVICE: ${config.deviceSerial} state changed " +
             "${devicesAndStates[config.deviceSerial]} --> ${newStateUpdate[config.deviceSerial]}")
          }
          devicesAndStates.putAll(newStateUpdate)
        }
      }
    }
  }

  override val state: DeviceState
    get() = devicesAndStates[config.deviceSerial] ?: DeviceState.MISSING

  override fun close() {
    logger.info("Stopped monitoring on device ${config.deviceSerial}")
    socket.close()
    executor.shutdown()
  }

  private companion object {
    @JvmStatic private val logger = getLogger()
    const val TRACK_DEVICES_COMMAND = "host:track-devices"

    const val DEFAULT_ADB_SERVER_PORT = 5037
  }
}
