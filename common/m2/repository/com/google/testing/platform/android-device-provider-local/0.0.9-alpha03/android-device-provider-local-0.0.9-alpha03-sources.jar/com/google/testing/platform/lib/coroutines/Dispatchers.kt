/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.coroutines

import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.asCoroutineDispatcher

object Dispatchers {
  /** Creates a CoroutineDispatcher backed by a cached thread pool that gives each thread a name. */
  fun cachedThreadDispatcher(basename: String): ExecutorCoroutineDispatcher =
    Executors.newCachedThreadPool(NamedThreadFactory(basename)).asCoroutineDispatcher()
}

/** A ThreadFactory that names threads "name-N", to aid in understanding logs. */
class NamedThreadFactory(val basename: String) : ThreadFactory {
  val actualFactory = Executors.defaultThreadFactory()
  val nth = AtomicInteger(0)

  override fun newThread(r: Runnable): Thread {
    val t = actualFactory.newThread(r)
    t!!.name = "${basename}-${nth.incrementAndGet()}"
    return t
  }
}
