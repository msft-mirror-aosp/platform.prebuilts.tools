/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.provider.local

import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.device.Device.DeviceType
import com.google.testing.platform.config.v1.extension.adbPortOrDefault
import com.google.testing.platform.config.v1.extension.adbServerPortOrDefault
import com.google.testing.platform.config.v1.extension.consolePortOrDefault
import com.google.testing.platform.config.v1.extension.deviceSerialOrDefault
import com.google.testing.platform.config.v1.extension.hostOrDefault
import com.google.testing.platform.proto.api.config.LocalAndroidDeviceProviderProto.LocalAndroidDeviceProvider
import com.google.testing.platform.runtime.android.device.AndroidDevice
import com.google.testing.platform.runtime.android.device.AndroidDeviceProperties

/**
 * Creates an [AndroidDevice] from the information specified in the provider proto config.
 *
 * @param config the provider's configuration from the proto config
 * @return the new [AndroidDevice] instance
 */
fun deviceFromConfig(config: LocalAndroidDeviceProvider, environment: Environment): AndroidDevice {
  var host = config.hostOrDefault
  var serial = config.deviceSerialOrDefault
  var adbPort: Int? = config.adbPortOrDefault
  var consolePort: Int? = config.consolePortOrDefault
  val adbServerPort = config.adbServerPortOrDefault

  // Either serial or host+adbPort must be specified to use a specific device with "adb connect",
  // so if we have a missing value, try to infer the missing value from what we know.
  if (config.serial.isBlank() && config.host.isNotBlank() && config.adbPort > 0)
    serial = "$host:$adbPort"
  if (config.serial.isNotBlank() && config.adbPort < 1) {
    val device = deviceFromSerial(config.serial, config, environment)
    host = device.host
    adbPort = device.port
    if (config.consolePort < 1 && device.emulatorPort != null) consolePort = device.emulatorPort
  }

  return AndroidDevice(
    host = host,
    serial = serial,
    type = DeviceType.valueOf(config.deviceType.name),
    port = adbPort,
    emulatorPort = consolePort,
    serverPort = adbServerPort,
    properties = AndroidDeviceProperties(logcatOptions = environment.androidLogcatOptions)
  )
}
