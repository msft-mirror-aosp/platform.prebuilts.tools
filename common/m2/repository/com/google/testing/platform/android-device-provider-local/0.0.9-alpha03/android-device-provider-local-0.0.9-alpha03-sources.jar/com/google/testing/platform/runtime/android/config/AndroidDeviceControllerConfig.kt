/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.config

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.config.ConfigBase
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.Setup
import com.google.testing.platform.lib.adb.command.inject.AdbCommands
import com.google.testing.platform.proto.api.config.AdbConfigProto
import com.google.testing.platform.proto.api.config.RuntimeProto
import com.google.testing.platform.proto.api.core.ExtensionProto

/**
 * Provides configuration values to a [DeviceController]. Includes base config and device controller
 * specific config.
 *
 * @param environment [Environment] data class.
 * @param setup [TestSetup] data class.
 * @param androidSdk [AndroidSdk] data class.
 * @param adbConfig the AdbConfig proto to configure the controller.
 * @param instrumentation the instrumentation information.
 * @param adbCommands the base [AdbCommands] to supply to the controller.
 */
class AndroidDeviceControllerConfig(
  override val environment: Environment,
  override val setup: Setup,
  override val androidSdk: AndroidSdk,
  val adbConfig: AdbConfigProto.AdbConfig,
  val instrumentation: RuntimeProto.AndroidInstrumentationRuntime,
  val adbCommands: AdbCommands,
  override val configProto: AnyProto? = null,
  override val configResource: ExtensionProto.ConfigResource? = null,
) : ConfigBase
