/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.monitor

import com.google.testing.platform.lib.adb.command.monitor.DeviceMonitor.DeviceState
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Utility class to create requests and read responses from the adb server using adb protocol
 *
 * Protocol documentation:
 * https://cs.android.com/android/platform/superproject/main/+/main:packages/modules/adb/OVERVIEW.TXT
 * https://cs.android.com/android/platform/superproject/main/+/main:packages/modules/adb/SERVICES.TXT
 */
internal object AdbProtocolHelper {

  /**
   * Enum class to represent ADB server response states. Every request responds with either OKAY or
   * FAIL
   */
  enum class Status {
    OKAY,
    FAIL
  }

  /** [Status] response from the adb server with an optional [failureMessage]. */
  data class StatusResponse(val status: Status, val failureMessage: String? = null)

  /**
   * Create properly formatted request to send to the adb server.
   *
   * Every request/command is prefixed with a 4 byte payload size in hexadecimal followed by the
   * command. For example, if you want to request the version from the adb server, i.e.,
   * "host:version", the full message to send is "000Chost:version".
   */
  fun sendPayload(outputStream: OutputStream, command: String) {
    val request = String.format("%04X%s", command.length, command).toByteArray()
    outputStream.write(request)
  }

  /**
   * Read payload received.
   *
   * Every response is prefixed with a 4 byte payload size in hexadecimal followed by the actual
   * payload.
   */
  fun readPayload(inputStream: InputStream): String? {
    val payloadSize = payloadSize(inputStream)
    if (payloadSize == 0) return null
    val payload = ByteArray(payloadSize)
    inputStream.read(payload)
    return String(payload, Charsets.UTF_8).trim()
  }

  /**
   * Read status response from requests to the adb server.
   *
   * Every command to the adb server responds with OKAY or FAIL. In case of FAIL, the failure
   * message follows prefixed with 4 byte message size in hexadecimal. For example: "FAIL0014unknown
   * host service"
   */
  fun readStatusResponse(inputStream: InputStream): StatusResponse {
    val responseBuffer = ByteArray(4)
    inputStream.read(responseBuffer)
    val response = String(responseBuffer)
    if (response == "OKAY") return StatusResponse(Status.OKAY)
    // Response is FAIL
    check(response == "FAIL") { "Invalid response from adb server. Response: $response" }
    val failureMessageSize = payloadSize(inputStream)
    val payload = ByteArray(failureMessageSize)
    inputStream.read(payload)
    val failureMessage = String(payload, Charsets.UTF_8).trim()
    return StatusResponse(Status.FAIL, failureMessage)
  }

  /**
   * Read the device states from the host:track-devices.
   *
   * An update to any device connected to the adb server will send current state of every connected
   * device. The full payload size in 4 byte hexadecimal, with each device and it's state separated
   * by newline. For example: "002Aemulator-5554 device emulator-5556 offline"
   */
  fun readDeviceState(inputStream: InputStream): Map<String, DeviceState> {
    var devicesAndStates = emptyMap<String, DeviceState>()
    try {
      val response = readPayload(inputStream) ?: return devicesAndStates
      val updates = response.split("\n")
      devicesAndStates =
        updates.associate { update ->
          val (device, state) = update.split("\t")
          device to DeviceState.valueOf(state.uppercase())
        }
    } catch (ioEx: IOException) {
      // Do nothing. Expected if socket is closed during a blocking read.
    }
    return devicesAndStates
  }

  /** Read payload size. */
  private fun payloadSize(inputStream: InputStream): Int {
    val sizeValue = ByteArray(4)
    val size = inputStream.read(sizeValue)
    return if (size <= 0) 0
    else String(sizeValue).toInt(radix = 16) // Payload size is in hexadecimal
  }
}
