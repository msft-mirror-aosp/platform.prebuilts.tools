/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.runtime.android.driver

import androidx.test.services.storage.TestStorageConstants
import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.proto.api.core.TestArtifactProto
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.io.File

/**
 * Extension function to add the coverage file as an test artifact to the test suite result.
 *
 * @param coverageFilePath the coverage file path on the device
 * @param externalStoragePath the external storage file path on the device
 * @param isTestServiceInstalled whether the test service is installed on the device
 * @param coverageFilePathOnHost the file path that the coverage file will be pulled to on the host
 */
@CanIgnoreReturnValue
fun TestSuiteResult.Builder.addCoverageFileArtifact(
  coverageFilePath: String,
  externalStoragePath: String,
  isTestServiceInstalled: Boolean,
  coverageFilePathOnHost: String
): TestSuiteResult.Builder {
  val absoluteCoveragePath =
    if (isTestServiceInstalled) {
      "$externalStoragePath/${TestStorageConstants.ON_DEVICE_PATH_INTERNAL_USE}$coverageFilePath"
    } else {
      coverageFilePath
    }
  return addOutputArtifact(
    Artifact.newBuilder().apply {
      sourcePathBuilder.path = coverageFilePathOnHost
      destinationPathBuilder.path = absoluteCoveragePath
    }
  )
}

/**
 * Adds a plain text file as a test artifact to the [TestSuiteResult].
 *
 * Adds the file to the TestSuiteResult only if the file exists and is not empty.
 *
 * @param testLogFile The instrumentation output [File].
 * @param extensionNamespace the namespace of the extension generating this artifact.
 * @return This [TestSuiteResult.Builder].
 */
fun TestSuiteResult.Builder.addPlainTextArtifact(
  testLogFile: File,
  extensionNamespace: String
): TestSuiteResult.Builder {
  if (!(testLogFile.isFile && testLogFile.length() > 0)) return this
  return addOutputArtifact(
    Artifact.newBuilder().apply {
      labelBuilder.apply {
        label = testLogFile.name
        namespace = extensionNamespace
      }
      sourcePathBuilder.apply { path = testLogFile.absolutePath }
      type = TestArtifactProto.ArtifactType.TEST_DATA
      mimeType = "text/plain"
    }
  )
}
