/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.timing

import com.google.testing.platform.lib.coroutines.atomic.atomic
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.time.Instant

/** Keeps track of when Instrumentation tests were run. */
interface TestTimeTracker {
  /**
   * Returns a [TestTimingData] instance with start and end times represented by [Timestamp] protos.
   */
  val testTimingData: TestTimingData

  /** Call when a test has started. Sets the start time in the tracker to now. */
  fun testStart()

  /** Call when a test has finished. Sets the end time in the tracker to now. */
  fun testEnd()
}

internal class TestTimeTrackerImpl(private val now: () -> Instant) : TestTimeTracker {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  private var hasStarted: Boolean by atomic { false }
  private var hasEnded: Boolean by atomic { false }

  private var startTime = -1L
  private var endTime = -1L

  override val testTimingData: TestTimingData
    get() {
      require(hasStarted) {
        "Called TestTimeTracker.testTimingData before TestTimeTracker.testStart()"
      }
      require(hasEnded) { "Called TestTimeTracker.testTimingData before TestTimeTracker.testEnd()" }
      return TestTimingData(startTime = startTime, endTime = endTime)
    }

  override fun testStart() {
    require(!hasStarted) { "Called TestTimeTracker.testStart() twice" }
    startTime = now().toEpochMilli()
    hasStarted = true
  }

  override fun testEnd() {
    if (!hasStarted) {
      logger.warning(
        """TestTimeTracker.testEnd() was called before TestTimeTracker.testStart(). The test may not
          |have run. Check the test logs for details.""".trimMargin()
      )
      testStart()
    }
    require(!hasEnded) { "Called TestTimeTracker.testEnd() twice" }
    endTime = now().toEpochMilli()
    hasEnded = true
  }
}

/** Factory function for the default implementation of [TestTimeTracker]. */
@Suppress("FunctionName")
fun TestTimeTracker(now: () -> Instant = { Instant.now() }): TestTimeTracker =
  TestTimeTrackerImpl(now)
