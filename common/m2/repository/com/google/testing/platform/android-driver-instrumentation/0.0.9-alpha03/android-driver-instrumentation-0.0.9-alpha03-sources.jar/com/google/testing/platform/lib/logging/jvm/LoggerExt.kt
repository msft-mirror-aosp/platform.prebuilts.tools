/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.logging.jvm

import java.util.logging.Logger

/**
 * Creates a new [Logger] using the receiver's class name. This is effectively the same as calling
 * `Logger.getLogger(MyFoo::class.java.name)!!`
 *
 * Example: ```
 * class MyFoo {
 *   companion object {
 *     @JvmStatic
 *     val logger = getLogger()
 *   }
 * }
 * ```
 */
fun <T : Any> T.getLogger(): Logger {
  return (javaClass.enclosingClass?.name ?: javaClass.name).let {
    Logger.getLogger(it)
  }
}

/**
 * Similar to [getLogger], this is for creating top-level loggers - like when creating extension
 * functions.
 *
 * Example: ```
 * private val logger by lazy { getLogger<T>() }
 * fun NotMyFoo.bar() {
 *  logger.finest("extension bar")
 * }
 * ```
 */
inline fun <reified T : Any> getLogger(): Logger = Logger.getLogger(T::class.java.name)
