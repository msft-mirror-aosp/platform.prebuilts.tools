/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.instrument

/**
 * Default implementation of [AmInstrumentationArgs].
 *
 * TODO(b/136600432): Consider merging this directly into [AmInstrumentationArgs].
 */
internal class DefaultInstrumentationArgs(
  override val instrumentationRunnerClass: String,
  override val noHiddenApiChecks: Boolean = false,
  override val noWindowAnimation: Boolean = false,
  override val rawOutput: Boolean = true,
  override val waitsForInstrumentation: Boolean = true,
  override val additionalOptions: Map<String, String?> = emptyMap(),
  /** Additional args which do not have a -e prefix */
  override val additionalArgs: List<String> = emptyList(),
) : AmInstrumentationArgs {

  override fun toArgs(): List<String> =
    mutableListOf("am", "instrument").apply {
      addAll(additionalArgs)
      if (waitsForInstrumentation) add(AmInstrumentationArgs.WAIT)
      if (rawOutput) add(AmInstrumentationArgs.RAW)
      if (noHiddenApiChecks) add(AmInstrumentationArgs.NO_HIDDEN_API_CHECKS)
      if (noWindowAnimation) add(AmInstrumentationArgs.NO_WINDOW_ANIMATION)
      additionalOptions.forEach { (name, value) ->
        addAll(AmInstrumentationArgs.createInstrumentationOption(name, value))
      }
      add(instrumentationRunnerClass)
    }
}
