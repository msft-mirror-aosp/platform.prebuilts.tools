/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.parser

/** Simple data class to represent an Android Instrumentation. */
data class Instrumentation(
  /** The apps (target) package */
  val appPackage: String = "",
  /** The test package */
  val testPackage: String,
  /** The instrumentation to run a test */
  val instrumentationClass: String
) {
  /** Returns the instrumentation class name and prepends the package name if needeed. */
  val fullInstrumentationClass: String
    get() =
      if (instrumentationClass.startsWith(".")) {
        testPackage + instrumentationClass
      } else {
        instrumentationClass
      }

  /** Returns the test package and instrumentation class separated by '/'. */
  val fullName: String
    get() =
      if (instrumentationClass.isNotEmpty()) {
        "$testPackage/$instrumentationClass"
      } else {
        testPackage
      }

  /**
   * The [Instrumentation] configuration is considered valid if at least the [testPackage] field is
   * set. The [appPackage] and [instrumentationClass] values are optional - if they aren't
   * specified, a suitable instrumentation class will be detected automatically.
   *
   * @return whether this [Instrumentation] instance is valid.
   */
  fun isValid(): Boolean = this.testPackage.isNotBlank()

  /**
   * The [Instrumentation] configuration is considered not configured if none of the [testPackage],
   * [appPackage] and [instrumentationClass] values are set.
   *
   * @return whether this [Instrumentation] instance is configured.
   */
  fun isNull(): Boolean =
    appPackage.isBlank() and testPackage.isBlank() and instrumentationClass.isBlank()

  /**
   * The [Instrumentation] configuration is considered valid if at least the [testPackage] field is
   * set. The [appPackage] and [instrumentationClass] values are optional - if they aren't
   * specified, a suitable instrumentation class will be detected automatically.
   *
   * @return a valid [Instrumentation] instance or null.
   */
  fun isValidOrNull(): Instrumentation? = if (this.testPackage.isNotBlank()) this else null

  /**
   * Compares a partially populated [Instrumentation] with another (presumably fully populated)
   * instance. If the [appPackage] field is filled, then perform a full match. If only the
   * [testPackage] field is filled, then only compare the test package. If the
   * [instrumentationClass] field is filled, try to match it as is, but also try matching with the
   * full class name.
   *
   * @return true if the provided fields in this instance match those in [other]
   */
  fun matches(other: Instrumentation): Boolean {
    // Try exact match if appPackage is given:
    if (appPackage.isNotEmpty()) {
      return this == other
    }
    // At a minimum the testPackage must match:
    if (testPackage.isEmpty() || testPackage != other.testPackage) {
      return false
    }
    // Match the class name if present:
    if (instrumentationClass.isNotEmpty()) {
      return fullInstrumentationClass == other.fullInstrumentationClass
    }
    return true
  }
}
