/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.driver

import com.google.testing.platform.lib.adb.command.instrument.AmInstrumentationArgs
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.AndroidInstrumentationDriverProto.AndroidInstrumentationDriver.ShellExecutionOption
import java.time.Duration

/**
 * Utility class to form the instrumentation command to run Orchestrator V1 or Direct
 * instrumentation.
 */
class AndroidInstrumentationArgs(
  override val instrumentationRunnerClass: String,
  override val noHiddenApiChecks: Boolean,
  override val noWindowAnimation: Boolean,
  override val rawOutput: Boolean,
  override val waitsForInstrumentation: Boolean,
  override val additionalOptions: Map<String, String?>,
  val androidTestPackage: String,
  val testClasses: List<String>,
  val enableDebugging: Boolean,
  val coverageReportPath: String?,
  val instrumentCommandTimeout: Duration,
  val useOrchestrator: Boolean,
  val useTestStorageService: Boolean = false,
  val shellExecutionOption: ShellExecutionOption,
  val useLocalSocket: Boolean = true,
  override val additionalArgs: List<String> = emptyList(),
) : AmInstrumentationArgs {
  companion object {
    @JvmStatic private val logger = getLogger()

    private const val orchestratorBaseInstrumentation =
      "androidx.test.orchestrator/androidx.test.orchestrator.AndroidTestOrchestrator"
  }

  /**
   * Converts this object into a list representing an am instrument command.
   *
   * The general syntax of the am instrument command is: `am instrument [flags]
   * <test_package>/<runner_class>`
   *
   * @see https://developer.android.com/studio/test/command-line#AMSyntax
   */
  override fun toArgs(): List<String> {
    require(androidTestPackage.isNotBlank()) { "AndroidTestPackage cannot be empty" }
    require(instrumentationRunnerClass.isNotBlank()) {
      "InstrumentationRunnerClass cannot be empty"
    }

    val options = mutableMapOf<String, String?>()

    // Timeout for thread state dump
    options["testTimeoutSeconds"] = "${instrumentCommandTimeout.toSeconds()}"

    if (!coverageReportPath.isNullOrEmpty()) {
      logger.fine("Jacoco coverage report requested: [$coverageReportPath]")
      options["coverage"] = "true"
      options["coverageFile"] = "$coverageReportPath"
    }

    if (enableDebugging) {
      options["debug"] = "true"
    }

    testClasses.forEach { className -> options["class"] = className }

    if (useOrchestrator) {
      options["targetInstrumentation"] = "$androidTestPackage/$instrumentationRunnerClass"
    }

    if (useTestStorageService) {
      options["useTestStorageService"] = "true"
    }

    val fullInstrumentation =
      if (useOrchestrator) orchestratorBaseInstrumentation
      else "$androidTestPackage/$instrumentationRunnerClass"

    var instrumentationArgs =
      AmInstrumentationArgs(
          instrumentationRunnerClass = fullInstrumentation,
          noHiddenApiChecks = noHiddenApiChecks,
          noWindowAnimation = noWindowAnimation,
          rawOutput = rawOutput,
          waitsForInstrumentation = waitsForInstrumentation,
          additionalArgs = additionalArgs,
          additionalOptions = additionalOptions + options,
        )
        .toArgs()

    // To enable AndroidTestUtil.executeShellCommand() in tests, the instrument command must be
    // prefixed to start ShellCommandExecutor service.
    val useShellExecutorService =
      useOrchestrator || shellExecutionOption == ShellExecutionOption.STRICT_SHELL_EXECUTION
    if (useShellExecutorService) {
      val shellMain = if (useLocalSocket) "LocalSocketShellMain" else "ShellMain"
      instrumentationArgs =
        listOf(
          "CLASSPATH=$(pm path androidx.test.services)",
          "app_process / androidx.test.services.shellexecutor.$shellMain",
        ) + instrumentationArgs
    }
    return instrumentationArgs
  }
}
