/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.coroutines.atomic

import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty
import kotlinx.atomicfu.atomic

/**
 * Delegate property for declaring variables that are backed by an atomic getter/setter.
 *
 * @see kotlinx.atomicfu.AtomicRef
 * @see kotlinx.atomicfu.AtomicBoolean
 * @see kotlinx.atomicfu.AtomicLong
 * @see kotlinx.atomicfu.AtomicInt
 */
private class AtomicDelegate<R, T> private constructor(
  private val atomicBacked: AtomicBacked<T>
) : ReadWriteProperty<R, T> {
  companion object Factory {
    fun <R, T> from(initial: T): ReadWriteProperty<R, T> {
      @Suppress("UNCHECKED_CAST")
      return AtomicDelegate(
        when (initial) {
          is Boolean -> BooleanBacked(initial)
          is Int -> IntBacked(initial)
          is Long -> LongBacked(initial)
          else -> RefBacked(initial)
        } as AtomicBacked<T>
      )
    }
  }

  /** Helper interface to unify getter and setter calls on all variants of atomic classes. */
  private interface AtomicBacked<T> {
    /** Gets the value. */
    fun get(): T

    /** Sets the value. */
    fun set(v: T)
  }

  /** Does an atomic read of the current value from an atomic backing field. */
  override fun getValue(thisRef: R, property: KProperty<*>): T {
    return atomicBacked.get()
  }

  /** Atomically sets a new value to an atomic backing field. */
  override fun setValue(thisRef: R, property: KProperty<*>, value: T) {
    return atomicBacked.set(value)
  }

  /** Backs a [Boolean] delegate using a [kotlinx.atomicfu.AtomicBoolean]. */
  private class BooleanBacked(initial: Boolean) : AtomicBacked<Boolean> {
    private val atomicValue = atomic(initial)
    override fun get() = atomicValue.value
    override fun set(v: Boolean) = atomicValue.lazySet(v)
  }

  /** Backs a [Int] delegate using a [kotlinx.atomicfu.AtomicInt]. */
  private class IntBacked(initial: Int) : AtomicBacked<Int> {
    private val atomicValue = atomic(initial)
    override fun get() = atomicValue.value
    override fun set(v: Int) = atomicValue.lazySet(v)
  }

  /** Backs a [Long] delegate using a [kotlinx.atomicfu.AtomicLong]. */
  private class LongBacked(initial: Long) : AtomicBacked<Long> {
    private val atomicValue = atomic(initial)
    override fun get() = atomicValue.value
    override fun set(v: Long) = atomicValue.lazySet(v)
  }

  /** Backs the delegate for any [T] using a [kotlinx.atomicfu.AtomicRef<T>]. */
  private class RefBacked<T>(initial: T) : AtomicBacked<T> {
    private val atomicValue = atomic(initial)
    override fun get() = atomicValue.value
    override fun set(v: T) = atomicValue.lazySet(v)
  }
}

/**
 * Generates a new delegate property which is backed by atomic get/set calls.
 *
 * Atomic variables are the recommended way to read/write values that are coroutine and thread safe.
 * These values have a similar API to [Lazy] for reading/writing, and readily benefit from
 * delegate-style interaction.
 *
 * Example usage:
 * ```
 * class AsyncFoo {
 *   private var hasRun: Boolean by atomic { false }
 *   private var runAttemptCount: Int by atomic { 0 }
 *   private var runState: FooState by atomic { FooState.IDLE }
 *
 *   suspend fun run(): Bar {
 *     runAttemptCount += 1
 *     if (hasRun || runState == FooState.RUNNING) return
 *     runState = FooState.RUNNING
 *     coroutineScope { /* do running stuff */ }
 *     hasRun = true
 *     runState = FooState.COMPLETE
 *   }
 * }
 * ```
 *
 * @see kotlinx.atomicfu.AtomicRef
 * @see kotlinx.atomicfu.AtomicBoolean
 * @see kotlinx.atomicfu.AtomicLong
 * @see kotlinx.atomicfu.AtomicInt
 */
fun <R, T> atomic(initialProvider: () -> T): ReadWriteProperty<R, T> {
  return AtomicDelegate.from(initialProvider())
}
