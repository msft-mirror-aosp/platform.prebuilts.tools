/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.context

import com.google.testing.platform.api.cancel.PluginCancellationContext
import com.google.testing.platform.api.config.Config
import com.google.testing.platform.api.driver.TestCoordinator
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.telemetry.core.Diagnostics
import java.util.logging.Level
import java.util.logging.Logger
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking

/**
 * Given a property key, return the corresponding property value, if it exists.
 *
 * @param key The property key
 * @param requiredType The required type of the property value
 * @return The property value associated with this key, or null if no value exists
 * @throws ClassCastException If a property value exists for the given key, but is not of the given
 *   type
 */
@Suppress("UNCHECKED_CAST")
inline fun <reified T> Context.getValue(key: String): T? = get(key) as T?

/**
 * Given a property key, return the corresponding property value, if it exists. Otherwise, call the
 * given function with the key and return the result
 *
 * @param key The property key
 * @return The property value associated with this key, or `computeFunction(key)` otherwise
 */
inline fun <reified T> Context.getOrElse(key: String, computeFunction: (String) -> T): T =
  getValue<T>(key) ?: computeFunction(key)

/** Gets the [PluginCancellationContext] interface for this extension. */
val Context.cancellation: PluginCancellationContext
  get() = get(Context.CANCEL_KEY)!! as PluginCancellationContext

/** Gets the [Config] for this extension. */
val Context.config: Config
  get() = get(Context.CONFIG_KEY)!! as Config

/**
 * Gets a useful prefix to apply to indicate the device with which the Context is associated;
 * usually ends in _, but can be empty when there is only one device.
 */
val Context.devicePrefix: String
  get() = get(Context.DEVICE_PREFIX_KEY) as? String ?: ""

/**
 * Gets the [CoroutineContext] for the top level coroutine.
 *
 * The context should contain a Job and a CoroutineDispatcher.
 *
 * If you are using coroutines, use runBlocking(context.coroutineContext) so if the top-level
 * SupervisorJob is canceled (e.g. because the test timed out and UTP needs to clean up ASAP), your
 * coroutines will be canceled.
 *
 * If the top-level [Job] is already canceled and you're cleaning up, the context will contain a
 * cleanup Job instead (since runBlocking wouldn't run anything with a canceled Job in the
 * CoroutineContext), and a warning will be issued to make this clear. The cleanup Job will be
 * canceled if it doesn't join within the abort timeout.
 *
 * If you are launching jobs, use the context so they'll pick up the underlying cached thread pool,
 * whose threads will be named to make it easy to figure out which device a given thread is
 * associated with.
 */
val Context.coroutineContext: CoroutineContext
  get() {
    var ctx = get(Context.COROUTINE_CONTEXT_KEY) as? CoroutineContext ?: EmptyCoroutineContext
    val inCleanup = ctx[Job]?.let { it.isCompleted || it.isCancelled } ?: false
    val cleanupJob = get(Context.CLEANUP_JOB_KEY) as? Job
    if (inCleanup && cleanupJob != null) {
      ctx = ctx + CoroutineName("UTP Cleanup") + cleanupJob
      val stack = Exception().stackTrace
      if (stack.size > 1) {
        Logger.getLogger(stack[1].className)
          .logp(
            Level.WARNING,
            stack[1].className,
            stack[1].methodName,
            "using cleanup CoroutineContext during cancellation",
          )
      }
    }
    return ctx
  }

/**
 * Gets a [CoroutineScope] for the top level coroutine context. Because the top-level context
 * already has a [Job], it will not create one, so there are no side effects to worry about.
 */
val Context.coroutineScope: CoroutineScope
  get() = CoroutineScope(coroutineContext)

/**
 * Shortcut to perform asynchronous calculation using coroutines.
 *
 * This makes it easy for developers who are new to coroutines to use UTP's coroutine infrastructure
 * correctly.
 *
 * @param name Name to identify the coroutine during debugging. If left null, the code will attempt
 *   to figure it out from the stack trace.
 * @param start How to schedule the created coroutine.
 * @param lambda Calculation to perform.
 * @return A Deferred object that can be used with Context.await() or Context.join().
 */
public fun <T> Context.async(
  name: String? = null,
  start: CoroutineStart = CoroutineStart.DEFAULT,
  lambda: () -> T,
): Deferred<T> {
  val nameContext: CoroutineContext =
    if (name == null) {
      val stack = Exception().stackTrace
      if (stack.size > 2) {
        CoroutineName("${stack[2].className}.${stack[2].methodName}:${stack[2].lineNumber}")
      } else {
        EmptyCoroutineContext
      }
    } else {
      CoroutineName(name)
    }
  // Because the Context's CoroutineContext always contains a Job, no new Job will be created by the
  // call to CoroutineScope here.
  return coroutineScope.async(nameContext, start) {
    // It is up to the user to choose safe behavior in the lambda.
    @Suppress("UnsafeCoroutineCrossing") lambda.invoke()
  }
}

/**
 * Shortcut to run suspending functions in the Context's coroutine context, such as Deferred.await()
 * or Job.join().
 *
 * @param name Name to identify the code block during debugging.
 * @param block Suspending code to run.
 * @return The result of block.
 */
public fun <T> Context.runBlocking(name: String? = null, block: suspend CoroutineScope.() -> T): T =
  runBlocking(
    coroutineContext + (if (name != null) CoroutineName(name) else EmptyCoroutineContext),
    block,
  )

/** Shortcut to await a Deferred result in the Context's coroutine context. */
public fun <T> Context.await(deferred: Deferred<T>, name: String? = null): T =
  runBlocking(name) { deferred.await() }

/** Shortcut to join a Job in the Context's coroutine context. */
public fun Context.join(job: Job, name: String? = null): Unit = runBlocking(name) { job.join() }

/** Gets to [Diagnostics] for this extension */
val Context.diagnostics: Diagnostics
  get() = get(Context.DIAGNOSTICS_KEY)!! as Diagnostics

/** Gets the [Events] for this extension. */
val Context.events: Events
  get() = get(Context.EVENTS_KEY)!! as Events

/** Gets the [PortPicker] from the global context. */
val Context.portPicker: PortPicker?
  get() = get(Context.PORTPICKER_KEY) as? PortPicker

/**
 * Gets the [TestCoordinator] used to synchronize multidevice tests. A TestDriver only needs to use
 * this if it is expected to participate in multidevice tests.
 */
val Context.testCoordinator: TestCoordinator
  get() = get(Context.COORDINATOR_KEY)!! as TestCoordinator
