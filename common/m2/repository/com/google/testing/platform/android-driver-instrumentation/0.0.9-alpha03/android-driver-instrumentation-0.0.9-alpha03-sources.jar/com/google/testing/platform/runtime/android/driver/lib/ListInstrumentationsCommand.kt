/*
 * Copyright (C) 2020 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.driver.lib

import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.config.v1.extension.toInstrumentation
import com.google.testing.platform.lib.adb.command.Instrumentations
import com.google.testing.platform.lib.adb.command.instrument.lib.InstrumentationFinder
import com.google.testing.platform.lib.adb.command.parser.Instrumentation
import com.google.testing.platform.lib.adb.command.parser.InstrumentationListParser
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.RuntimeProto.AndroidInstrumentationRuntime
import com.google.testing.platform.runtime.android.controller.ext.listInstrumentations

/** Issues the `pm list instrumentation` to find instrumentations on the device to run on. */
class ListInstrumentationsCommand
constructor(
  private val parser: InstrumentationListParser,
  private val configInstrumentation: AndroidInstrumentationRuntime
) {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  /**
   * Extracts instrumentations from the device and filters to get first available instrumentation.
   */
  fun getInstrumentation(deviceController: DeviceController): Instrumentation {
    val (exitCode, output) = deviceController.listInstrumentations()

    if (exitCode != 0) {
      logger.warning("pm list instrumentation return non-zero exit code: $exitCode")
    }

    val instrumentations = parser.from(output)

    val availableInstrumentations: Set<Instrumentation> =
      Instrumentations(instrumentations.mapNotNull { it }.toSet(), exitCode).instrumentations

    val instrumentationInfo = configInstrumentation.instrumentationInfo
    val instrumentationFinder =
      InstrumentationFinder(
        availableInstrumentations = availableInstrumentations,
        configInstrumentation = instrumentationInfo.toInstrumentation(),
        instrumentationFilter = instrumentationInfo.instrumentationFilter
      )
    return instrumentationFinder.findFirst()
  }
}
