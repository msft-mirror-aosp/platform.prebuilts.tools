/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.runtime.android.driver

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

/** All the possible error summaries of [AndroidInstrumentationDriverException]. */
enum class AndroidInstrumentationDriverErrorSummary(
  override val errorCode: Int,
  override val errorType: Enum<*>
) : ErrorSummary {
  /**
   * The entire test suite was not executed, possibly due to some wrong test setup which causes the
   * instrumentation process to crash before executing the test suite.
   */
  TEST_SUITE_NOT_EXECUTED(1001, ErrorType.TEST),
  INVALID_INSTRUMENTATION_PROVIDED(1002, ErrorType.CONFIG),

  /**
   * An instrumentation failure was reported from the device.
   *
   * This is usually a user issue such as, but not limited to:
   *
   * * The instrumentation process crashed.
   * * The instrumentation was cancelled.
   * * Less than the expected number of test methods were executed.
   */
  INSTRUMENTATION_FAILURE(1003, ErrorType.TEST),
  UNDETERMINED(1999, ErrorType.UNDETERMINED);

  override val errorName = this.name
  override val namespace =
    "com.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver"
}
