/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.parser

/**
 * Similar to [Parser], but subscribers will receive output as they're parsed by registering.
 *
 * Note: this means that subscription output might not exactly match the {@code from()} output.
 * i.e. {@code from()} returns a list of objects while subscribers receive each individual object as
 * they are parsed.
 */
interface ListenableParser<OutputType> : Parser<OutputType> {
  /**
   * Registers all subscriber methods on object to receive events from the internal EventBus. These
   * objects will need to receive the output objects as part of their {@code @Subscribe} methods.
   * [See here](https://github.com/google/guava/wiki/EventBusExplained) for information on EventBus.
   *
   * @param obj - an object to subscribed to the parser state.
   */
  fun register(obj: Any)

  /**
   * Unregisters all subscriber methods on a registered object from the internal EventBus.
   * [See here](https://github.com/google/guava/wiki/EventBusExplained) for information on EventBus.
   *
   * @param obj - an object to subscribed to the parser state.
   */
  fun unregister(obj: Any)
}
