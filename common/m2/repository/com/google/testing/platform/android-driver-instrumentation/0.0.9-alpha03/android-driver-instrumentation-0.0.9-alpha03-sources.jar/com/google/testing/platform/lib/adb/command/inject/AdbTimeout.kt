/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

import java.time.Duration

val DEFAULT_TIMEOUT = Duration.ofSeconds(360L)

/** Adb timeout configuration. */
data class AdbTimeout(
  /** Default timeout for all ADB commands, unless overridden. */
  val defaultTimeout: Duration = DEFAULT_TIMEOUT,

  /** Install command timeout. */
  val installCmdTimeout: Duration? = null
)
