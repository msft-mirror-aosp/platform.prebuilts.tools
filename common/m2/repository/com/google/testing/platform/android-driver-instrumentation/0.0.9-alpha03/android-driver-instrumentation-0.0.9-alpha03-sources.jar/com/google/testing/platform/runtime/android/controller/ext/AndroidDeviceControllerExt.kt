/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.controller.ext

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.lib.adb.command.network.AdbNetworkSocket
import com.google.testing.platform.lib.adb.command.parser.Instrumentation
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.TestArtifactProto
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.artifact
import com.google.testing.platform.proto.api.core.path
import com.google.testing.platform.runtime.android.controller.ext.Constants.ANDROID_TV_PROPERTY_NAME_VALUE
import com.google.testing.platform.runtime.android.controller.ext.Constants.PRODUCT_NAME_PROP
import com.google.testing.platform.runtime.android.controller.ext.Constants.PRODUCT_SYSTEM_NAME_PROP
import com.google.testing.platform.runtime.android.controller.ext.Constants.SYSTEM_USER
import com.google.testing.platform.runtime.android.controller.ext.Constants.UNLOCK_SCREEN_CMD
import com.google.testing.platform.runtime.android.controller.ext.Constants.WEAR_PROPERTY_NAME_VALUE
import com.google.testing.platform.runtime.android.controller.ext.Constants.WEAR_STEM_PROPERTY
import com.google.testing.platform.runtime.android.device.AndroidDeviceProperties
import java.io.File
import java.nio.file.Path
import java.nio.file.Paths
import java.time.Duration
import java.util.concurrent.TimeUnit
import java.util.logging.Level
import kotlin.io.path.Path
import kotlin.text.Regex

private val logger by lazy { getLogger<DeviceController>() }

/**
 * Extension function to list instrumentations on the device.
 *
 * TODO(b/150468738): Move to AndroidDeviceController.
 */
fun DeviceController.listInstrumentations(timeout: Duration? = null): CommandResult =
  this.deviceShell(listOf("pm", "list", "instrumentation"), timeout)

/**
 * Extension function to list available instrumentations on the device.
 *
 * @return A set of available instrumentation instances detected on the device.
 */
fun DeviceController.listInstrumentationToInstances(): Set<Instrumentation> {
  // Find available instrumentations on the device
  val instrumentationsOutput = this.listInstrumentations().output.joinToString(" ")

  val availableInstrumentations = mutableSetOf<Instrumentation>()

  Regex("instrumentation:(.+?)/(.+?)\\s\\(target=(.+?)\\)")
    .findAll(instrumentationsOutput)
    .iterator()
    .forEach { result ->
      availableInstrumentations.add(
        Instrumentation(
          appPackage = result.groupValues[3],
          testPackage = result.groupValues[1],
          instrumentationClass = result.groupValues[2]
        )
      )
    }
  return availableInstrumentations
}

/**
 * Extension function to execute shell commands on device.
 *
 * @param args list of strings forming the complete shell command
 * @param timeout optional timeout parameter. Use default configured if absent.
 */
@CanIgnoreReturnValue
@Deprecated(message = "Please update to using a Duration for timeout")
fun DeviceController.deviceShell(args: List<String>, timeout: Long): CommandResult =
  this.deviceShell(args, Duration.ofSeconds(timeout))

/**
 * Extension function to execute shell commands on device.
 *
 * @param args list of strings forming the complete shell command
 * @param timeout optional timeout parameter. Use default configured if absent.
 */
@CanIgnoreReturnValue
fun DeviceController.deviceShell(args: List<String>, timeout: Duration? = null): CommandResult =
  this.execute(listOf("shell").plus(args), timeout = timeout)

/**
 * Extension function to execute shell commands on device, and logs a warning message when the
 * command fails.
 *
 * @param args list of strings forming the complete shell command
 * @param timeout optional timeout parameter. Use default configured if absent.
 */
@CanIgnoreReturnValue
fun DeviceController.deviceShellAndLogOnFailure(
  args: List<String>,
  timeout: Duration? = null
): CommandResult = this.execAndLogOnFailure(listOf("shell").plus(args), timeout = timeout)

/**
 * Extension function to execute shell commands on device.
 *
 * @param args list of strings forming the complete shell command
 * @param processor optional lambda that is invoked each time a line of output is emitted during
 *   command execution.
 */
fun DeviceController.asyncShell(
  args: List<String>,
  processor: (String) -> Unit = {}
): CommandHandle = this.executeAsync(listOf("shell").plus(args), processor = processor)

/**
 * Extension function to set up adb reverse tunnel with the device.
 *
 * @param hostSocket socket on the host to connect with
 * @param deviceSocket socket on the device to set up a reverse tunnel
 * @param noRebind add the `--no-rebind` option to fail if connection exists
 * @param timeout optional timeout for command to finish. Default: 120 seconds
 */
fun DeviceController.setUpAdbReverse(
  deviceSocket: AdbNetworkSocket,
  hostSocket: AdbNetworkSocket,
  noRebind: Boolean = false,
  timeout: Duration? = Duration.ofSeconds(120L)
): CommandResult =
  this.execute(
    args =
      listOf("reverse")
        .apply { if (noRebind) plus("--no-rebind") }
        .plus("$deviceSocket")
        .plus("$hostSocket"),
    timeout = timeout
  )

/**
 * Extension function to set up adb forward tunnel with the device.
 *
 * @param hostSocket socket on the host to connect with
 * @param deviceSocket socket on the device to set up tunnel
 * @param noRebind add the `--no-rebind` option to fail if connection exists
 * @param timeout optional timeout for command to finish. Default: 120 seconds
 */
fun DeviceController.setUpAdbForward(
  hostSocket: AdbNetworkSocket,
  deviceSocket: AdbNetworkSocket,
  noRebind: Boolean = false,
  timeout: Duration? = Duration.ofSeconds(120L)
): CommandResult =
  this.execute(
    args =
      listOf("forward")
        .apply { if (noRebind) plus("--no-rebind") }
        .plus("$hostSocket")
        .plus("$deviceSocket"),
    timeout = timeout
  )

/**
 * Executes `adb reverse --remove {hostSocket}`, which removes a specific reverse socket connection.
 *
 * @param hostSocket socket on the host that has an exiting reverse tunnel
 * @param timeout optional timeout for command to finish. Default: 120 seconds
 */
fun DeviceController.removeAdbReverseTunnel(
  hostSocket: AdbNetworkSocket,
  timeout: Duration = Duration.ofSeconds(120L)
): CommandResult =
  this.execute(args = listOf("reverse", "--remove", "$hostSocket"), timeout = timeout)

/**
 * Executes `adb reverse --remove-all`, removing all reverse socket connections from the device.
 *
 * @param timeout optional timeout for command to finish. Default: 120 seconds
 */
fun DeviceController.removeAllAdbReverseTunnels(
  timeout: Duration = Duration.ofSeconds(120L)
): CommandResult = this.execute(args = listOf("reverse", "--remove-all"), timeout = timeout)

/**
 * Executes `adb reverse --list`, list all reverse socket connections from a device.
 *
 * @param timeout optional timeout for command to finish. Default: 120 seconds
 */
fun DeviceController.listReverseTunnel(
  timeout: Duration = Duration.ofSeconds(120L)
): CommandResult = this.execute(args = listOf("remove", "--list"), timeout = timeout)

/**
 * Extension function to unlock screen on an android device.
 *
 * Runs only if the target device is not an android TV device.
 *
 * Don't send MENU/BACK key to AndroidTV emulators.
 *
 * On AndroidTV this is treated as "start screensaver". AndroidTV does not have the lockscreen
 * anyway, so skip it.
 *
 * We should unlock the screen by default on all other devices.
 */
fun DeviceController.unlockScreen(timeout: Duration? = null) {
  val props = getDevice().properties as AndroidDeviceProperties
  val productName = props.map[PRODUCT_NAME_PROP]
  val productSystemName = props.map[PRODUCT_SYSTEM_NAME_PROP]
  val isTv = productName?.contains(ANDROID_TV_PROPERTY_NAME_VALUE) ?: false
  val isWear =
    productSystemName?.contains(WEAR_PROPERTY_NAME_VALUE)
      ?: props.map.containsKey(WEAR_STEM_PROPERTY)
  if (!isTv && !isWear) {
    deviceShell(UNLOCK_SCREEN_CMD, timeout)
  }
}

/**
 * Extension function to set properties on the device.
 *
 * @param prop property to set
 * @param value value of the [prop] property
 */
@CanIgnoreReturnValue
fun DeviceController.setProp(
  prop: String,
  value: String,
  timeout: Duration? = null
): CommandResult {
  require(prop.isNotEmpty()) { "prop cannot be empty." }
  return deviceShell(listOf("setprop", prop, value), timeout)
}

/** Extension function to get the API level of the Android device. */
fun DeviceController.apiLevel(): Int =
  (this.getDevice().properties as AndroidDeviceProperties).deviceApiLevel.toInt()

/**
 * Extension function to get the property value from device's `getprop` or environment variables.
 */
fun DeviceController.getProperty(key: String): String? {
  require(key.isNotEmpty()) { "Key cannot be empty." }
  val properties = getDevice().properties as AndroidDeviceProperties
  return properties.map[key]
}

/** Get the external storage directory on the device. */
fun DeviceController.externalStorageDir(): String {
  val properties = getDevice().properties as AndroidDeviceProperties
  return properties.autoExtraStorageDir ?: properties.externalStorageDir
}

/** Extension function to clear the logcat buffer. */
@CanIgnoreReturnValue
fun DeviceController.clearLogcat(timeout: Duration? = null): CommandResult =
  deviceShell(listOf("logcat", "-c"), timeout)

/** Extension function to clear [targetPackage] data */
fun DeviceController.clearPackageData(targetPackage: String, timeout: Duration? = null) {
  require(targetPackage.isNotEmpty()) { "$targetPackage cannot be empty." }
  deviceShell(listOf("pm", "clear", targetPackage), timeout)
}

/** Extension function to uninstall [targetPackage] on device. */
@CanIgnoreReturnValue
fun DeviceController.uninstall(
  targetPackage: String,
  keepDataAndCache: Boolean = false,
  timeout: Duration? = null
): CommandResult {
  require(targetPackage.isNotEmpty()) { "$targetPackage cannot be empty." }
  return deviceShell(
    mutableListOf("pm", "uninstall").apply {
      if (keepDataAndCache) add("-k")
      add(targetPackage)
    },
    timeout
  )
}

/**
 * Extension function to list packages on device
 *
 * @param options list of options to supply to the command. Optional
 */
fun DeviceController.listPackages(
  options: List<String> = emptyList(),
  timeout: Duration? = null
): CommandResult =
  deviceShell(
    mutableListOf("pm", "list", "packages").apply { if (options.isNotEmpty()) addAll(options) },
    timeout
  )

/** Extension function to check whether AndroidX test services are installed on the device. */
fun DeviceController.isTestServiceInstalled(): Boolean {
  val cmdOutput = listPackages(listOf("androidx.test.services"))
  // It outputs a "package:<package-name>" line if the package exists on the device, otherwise
  // empty.
  return cmdOutput.output.isNotEmpty()
}

/**
 * Extension function to delete files and folders.
 *
 * @param paths list of files or folders to delete.
 * @param recursivelyDelete if true will recursively delete(`-rf`) all files/folders. Default: false
 */
@CanIgnoreReturnValue
fun DeviceController.delete(
  paths: List<String>,
  recursivelyDelete: Boolean = false,
  timeout: Duration? = null,
): CommandResult {
  require(paths.isNotEmpty()) { "No paths to delete." }
  return deviceShell(
    mutableListOf("rm").apply {
      if (recursivelyDelete) add("-rf")
      addAll(paths) // Check if there needs to be filter for allowed directories.
    },
    timeout
  )
}

/**
 * Extension function to make a directory on device.
 *
 * @param absolutePath Must be an absolute path starting at the device root.`
 */
@CanIgnoreReturnValue
fun DeviceController.makeDirectory(absolutePath: String, timeout: Duration? = null): CommandResult {
  require(absolutePath.isNotEmpty() && absolutePath.startsWith("/")) {
    "Invalid path. Has to be an absolute path."
  }
  return deviceShell(listOf("mkdir", "-p", absolutePath), timeout)
}

/**
 * Extension function to get the `versionCode` of the package.
 *
 * @param packageName package name of the application.
 * @return `versionCode` or `null` if the package wasn't found.
 */
fun DeviceController.getAppVersionCode(packageName: String): String? {
  val result = deviceShellAndLogOnFailure(listOf("dumpsys", "package", packageName))
  if (result.statusCode != 0) return null
  val output = result.output.joinToString()
  return " versionCode=(\\d+)".toRegex().find(output)?.groupValues?.get(1)
}

/**
 * Extension function to get the `versionCode` integer of the package. Returns -1 if none is
 * specified.
 */
fun DeviceController.getAppVersionCodeAsInt(packageName: String): Int {
  val versionCode = getAppVersionCode(packageName)
  return versionCode?.toInt() ?: -1
}

/**
 * Extension function to install APK and grant runtime permissions with "adb install -g" command.
 *
 * @param artifact APK artifact to install.
 * @param timeoutSeconds the optional timeout seconds to installation.
 * @return the exit code of the CommandResult.
 */
@Deprecated(message = "Please update to using a Duration for timeout")
fun DeviceController.installAndGrantPermissions(
  artifact: Artifact,
  timeoutSeconds: Long
): CommandResult = installAndGrantPermissions(artifact, Duration.ofSeconds(timeoutSeconds))

/**
 * Extension function to install APK and grant runtime permissions with "adb install -g" command.
 *
 * @param artifact APK artifact to install.
 * @param timeout the optional timeout.
 * @return the exit code of the CommandResult.
 */
fun DeviceController.installAndGrantPermissions(
  artifact: Artifact,
  timeout: Duration?
): CommandResult {
  require(artifact.hasSourcePath()) { "Artifact source path needs to be set." }
  return this.execute(listOf("install", "-g", artifact.sourcePath.path), timeout)
}

/**
 * Extension function to install multiple packages with a single "adb install-multi-package"
 * command. Only work on devices with SDK version >= 29.
 *
 * @param artifacts list of apk artifacts to install.
 * @param timeoutSeconds the optional timeout.
 * @return the exit code of the CommandResult.
 */
fun DeviceController.installMultiPackage(
  artifacts: Set<Artifact>,
  timeout: Duration?
): CommandResult {
  require(artifacts.isNotEmpty()) { "No apk to install." }
  require(artifacts.all { it.hasSourcePath() }) { "All artifact sources need to be set." }
  require(apiLevel() >= 29) {
    "Install-multi-package support requires the minimal API level to 29."
  }
  return this.execute(
    mutableListOf("install-multi-package", "-r", "-t", "-g").apply {
      addAll(artifacts.map { it.sourcePath.path })
    },
    timeout
  )
}

/** Extension function to get the external storage path on the device. */
fun DeviceController.getExternalStoragePath(): String {
  val deviceProperties = getDevice().properties as AndroidDeviceProperties
  return deviceProperties.autoExtraStorageDir ?: deviceProperties.externalStorageDir
}

/**
 * Extension function to get extra install options based on device api level.
 *
 * @param replaceExistingApp reinstalls an existing app, keeping its data.
 * @param allowTestApks allows test APKs to be installed.
 * @param grandRuntimePermissions grants all permissions listed in the app manifest.
 * @param allowVersionDowngrade allows version code downgrade.
 * @return list of extra install options.
 */
fun DeviceController.getExtraInstallOptions(
  replaceExistingApp: Boolean = true,
  allowTestApks: Boolean = true,
  grandRuntimePermissions: Boolean = true,
  allowVersionDowngrade: Boolean = false,
): List<String> {
  val deviceApiLevel = apiLevel()
  return listOfNotNull(
    "-r".takeIf { replaceExistingApp },
    "-t".takeIf { allowTestApks },
    "-g"
      .takeIf {
        grandRuntimePermissions && deviceApiLevel >= 23
      }, // Grant runtime permissions if api supports it.
    "-d"
      .takeIf {
        allowVersionDowngrade && deviceApiLevel >= 21
      } // Allow version code downgrade if api supports it.
  )
}

fun DeviceController.waitForDeviceHealthy(
  timeout: Duration,
  retryInterval: Duration = Duration.ofMillis(100)
): Boolean {
  var lastException: Exception? = null
  for (attempt in 0..(timeout.toMillis() / retryInterval.toMillis())) {
    try {
      if (isDeviceHealthy()) return true
    } catch (x: Exception) {
      lastException = x
    }
    TimeUnit.MILLISECONDS.sleep(retryInterval.toMillis())
  }
  logger.log(Level.WARNING, "Device did not achieve health within $timeout", lastException)
  return false
}

/** Returns true if device is healthy. */
fun DeviceController.isDeviceHealthy(): Boolean {
  return isSystemServerRunning() &&
    isDataMounted() &&
    isSysBootCompletedSet() &&
    isPackageManagerRunning()
}

/** Returns true if system server is running. */
fun DeviceController.isSystemServerRunning(): Boolean {
  // The behavior of "ps" changes on API 26. On APIs 19-23 we could use "ps system_server", but
  // that would break on 24-25.
  val args = mutableListOf<String>()
  if (apiLevel() >= 26) args.add("-ef") // verified through API 33
  return checkStdoutContains("ps", args, "system_server")
}

/** Returns true if data partition is mounted. */
fun DeviceController.isDataMounted(): Boolean {
  return checkStdoutContains("mount", listOfNotNull(), Regex("/data (type )?ext4"))
}

/** Returns true if system boot completed property is set. */
fun DeviceController.isSysBootCompletedSet(): Boolean {
  return checkStdoutContains("getprop", listOfNotNull(), "[sys.boot_completed]: [1]") ||
    checkStdoutContains("getprop", listOfNotNull(), "[dev.bootcomplete]: [1]")
}

/** Returns true if package manager is running. */
fun DeviceController.isPackageManagerRunning(): Boolean {
  return checkStdoutContains(
    "/system/bin/sh",
    listOf("/system/bin/pm", "path", "android"),
    "package:"
  )
}

/**
 * Extension function checks if shell command outputs given string.
 *
 * @param cmd the shell command to execute.
 * @param args the arguments associated with shell command.
 * @param keyword the keyword to check if output contains.
 * @return true if the output contains given keyword string.
 */
fun DeviceController.checkStdoutContains(
  cmd: String,
  args: List<String>,
  keyword: String,
  timeout: Duration? = null,
): Boolean {
  val result = this.deviceShell(listOf(cmd).plus(args), timeout)
  return result.outputLineSequence().any { it.contains(keyword) }
}

/**
 * Extension function checks if shell command outputs given string.
 *
 * @param cmd the shell command to execute.
 * @param args the arguments associated with shell command.
 * @param regex the regex to check against the output.
 * @return true if the output contains given regex.
 */
fun DeviceController.checkStdoutContains(
  cmd: String,
  args: List<String>,
  regex: Regex,
  timeout: Duration? = null
): Boolean {
  val result = this.deviceShell(listOf(cmd).plus(args), timeout)
  return result.outputLineSequence().any { it: String -> regex.containsMatchIn(it) }
}

/**
 * Extension function that returns a list of process IDs matching the given process name.
 *
 * @param processName the process name to match.
 * @return a list of process ids matching the given process name, or an empty list if no matching
 *   process was found.
 */
fun DeviceController.pids(processName: String, timeout: Duration? = null): List<String> {
  val (_, output) = deviceShell(listOf("ps"), timeout)
  if (output.isEmpty()) {
    return listOf()
  }

  val headers = output[0].split("\\s+".toRegex())
  val pidColumnIndex = headers.indexOf("PID")
  val processNameIndex = headers.indexOf("NAME")
  if (pidColumnIndex < 0 || processNameIndex < 0) {
    return listOf()
  }
  val processInfoList = output.subList(1, output.size)
  return processInfoList.mapNotNull { processInfo ->
    val infoList = processInfo.split("\\s+".toRegex())
    val deviceApiLevel = apiLevel()
    val name =
      if (deviceApiLevel >= 26) {
        infoList[processNameIndex]
      } else {
        // Index processNameIndex shows the process running status for API < 26
        infoList[processNameIndex + 1]
      }
    if (name == processName) {
      infoList[pidColumnIndex]
    } else {
      null
    }
  }
}

/**
 * Extension function that captures a thread dump for a given app process.
 *
 * It triggers a thread dump by issuing "kill -3" to the app process, and stages the thread dump
 * files to the given [outputFolder]. For Android API level 26 and below, a file named "traces.txt"
 * will be generated, while for API level 27 and above, the file is named as "trace_00", "trace_01",
 * etc.
 *
 * If no running process is found for the given [appPackage], no thread dump will be generated and
 * the method will return false.
 *
 * @param appPackage the app package name to get a thread dump
 * @param outputFolder the output folder on the host machine to pull the thread dump files to
 * @return true if the thread dump was successfully generated, false otherwise
 */
fun DeviceController.threadDump(
  appPackage: String,
  outputFolder: String,
  timeout: Duration? = null
): Boolean {
  val appProcessIds = pids(appPackage)
  if (appProcessIds.isEmpty()) {
    logger.warning("No $appPackage process is running")
    return false
  }

  logger.info("Capturing a thread dump for $appProcessIds")
  val anrFolder = "/data/anr/"
  makeDirectory(anrFolder)
  val deviceApiLevel = apiLevel()
  if (deviceApiLevel >= 27) {
    deviceShell(listOf("touch", "${anrFolder}trace_00"), timeout)
  } else {
    deviceShell(listOf("touch", "${anrFolder}traces.txt"), timeout)
  }
  var succeeded = false
  appProcessIds.forEach { pid ->
    // Thread dump is not always successful. Retry for at most 3 times
    var retries = 0
    while (retries < 3) {
      // Calls `kill -3` to trigger a thread dump
      deviceShell(listOf("kill", "-3", pid), timeout)
      // Tests whether a non-empty thread dump file was generated
      val (_, output) = deviceShell(listOf("ls", anrFolder), timeout)
      val traceFile = output.find { fileName -> fileName.trim().contains("trace") }
      if (traceFile != null) {
        val (_, anrFileContent) = deviceShell(listOf("cat", "$anrFolder$traceFile"), timeout)
        if (anrFileContent.isNotEmpty() && !anrFileContent[0].isNullOrBlank()) {
          succeeded = true
          break
        }
      }
      retries++
    }
  }

  if (succeeded) {
    pull(
      artifact {
        destinationPath = path { path = anrFolder }
        sourcePath = path { path = outputFolder }
      }
    )
    Paths.get(outputFolder, Constants.ANR_FOLDER).toFile().walk().forEach {
      if (!it.isDirectory() && it.extension.isNullOrEmpty()) {
        it.renameTo(File("${it.getAbsolutePath()}.txt"))
      }
    }
  }
  return succeeded
}

/**
 * Extension function to execute a command on the device, and logs a warning message when the
 * command fails.
 */
fun DeviceController.execAndLogOnFailure(args: List<String>, timeout: Duration? = null) =
  execute(args, timeout = timeout).also { cmdResult ->
    if (cmdResult.statusCode != 0) {
      logger.warning(
        "Failed to execute command ${args.joinToString(" ")}! " +
          "Exited with code: ${cmdResult.statusCode}.\nOutput: ${cmdResult.byteOutput}"
      )
    }
  }

/** Extension function to get the current user. */
fun DeviceController.getCurrentUser() =
  ((getDevice().properties as? AndroidDeviceProperties)?.currentUser
    ?: deviceShellAndLogOnFailure(listOf("am", "get-current-user")).output.firstOrNull())

/**
 * Extension function to return whether the current user is the primary/system user.
 *
 * On API <= 23, getCurrentUser() will return null or the empty string if the current user ID is 0.
 */
fun DeviceController.isRunningUnderSystemUser() =
  when (getCurrentUser()) {
    null -> true
    "" -> true
    SYSTEM_USER -> true
    else -> false
  }

/**
 * Sets up a list of APKs to be installed as system APKs at the next device restart.
 *
 * @param systemApksToInstall apks to be installed as system apk.
 * @param deviceApiLevel api level of the device.
 * @return Last nonzero result from DeviceController.push(), or 0 on success.
 */
fun DeviceController.installSystemApks(
  systemApksToInstall: List<String>,
  deviceApiLevel: Int
): Int {
  if (systemApksToInstall.isNullOrEmpty()) {
    return 0
  }

  var result = 0

  this.remountSystem("rw", deviceApiLevel)
  val systemBase =
    if (deviceApiLevel >= 19) {
      "/system/priv-app"
    } else {
      "/system/app"
    }
  for (apkPath in systemApksToInstall) {
    // Bundletool reuses filenames like "base-ldpi.apk". Since we might be installing multiple
    // bundles this way, add some uniqueness to the filenames.
    val hostPath = Paths.get(apkPath)
    val uniqueFilename =
      hostPath.parent?.fileName?.let { fileName: Path ->
        listOf(fileName.toString(), hostPath.fileName.toString()).joinToString("_")
      } ?: hostPath.fileName.toString()
    val dataPath = Paths.get("/data", uniqueFilename).toString()
    val systemPath = Paths.get(systemBase, uniqueFilename).toString()
    val apkArtifact = artifact {
      destinationPath = path { path = dataPath }
      sourcePath = path { path = apkPath }
      type = TestArtifactProto.ArtifactType.ANDROID_APK
    }
    val pushResult = this.push(apkArtifact)
    if (pushResult != 0) result = pushResult
    this.deviceShell(listOf("ln", "-s", dataPath, systemPath))
  }
  this.remountSystem("ro", deviceApiLevel)

  return result
}

/**
 * Remounts device system partition.
 *
 * @param mode the mode to be remounted with.
 * @param deviceApiLevel api level of the device to be remounted.
 */
private fun DeviceController.remountSystem(mode: String, deviceApiLevel: Int) {
  if (deviceApiLevel >= 33) {
    shellRemountSystem(mode)
    return
  }
  var mountPoint = "/system"
  if (deviceApiLevel >= 28) {
    mountPoint = "/"
  }
  remount(mountPoint, mode)
}

/** Remounts device at given [mountPoint] with [mode]. */
private fun DeviceController.remount(mountPoint: String, mode: String) {
  this.deviceShell(listOf("mount", "-o", "$mode,remount", mountPoint))
}

private fun DeviceController.shellRemountSystem(mode: String) {
  if (mode.equals("rw")) {
    this.deviceShell(listOf("remount"))
  }
}

/** Restarts device with given api level. */
fun DeviceController.restartSystem(deviceApiLevel: Int, timeout: Duration? = null) {
  if (deviceApiLevel >= 23) {
    this.deviceShell(listOf("stop", "fingerprintd"), timeout)
  }

  // Soft restarting the device does not reset these props, so we do that here.
  this.deviceShell(listOf("setprop", "sys.boot_completed", "0"), timeout)
  this.deviceShell(listOf("setprop", "dev.bootcomplete", "0"), timeout)

  if (deviceApiLevel >= 19) {
    // This will fail with a broken pipe, so don't check for errors.
    this.deviceShell(listOf("am", "restart"), timeout)
  } else {
    this.deviceShell(listOf("stop"), timeout)
    this.deviceShell(listOf("start"), timeout)
  }

  if (deviceApiLevel >= 23) {
    this.deviceShell(listOf("start", "fingerprintd"), timeout)
  }
}

/**
 * List all files recursively in [path] on the device.
 *
 * Supplied [path] has to be an absolute path.
 *
 * This method uses `ls -R <path> 2>/dev/null | cat` to list files recursively line by line. The
 * `find` utility on the device is available only on API > 23. `find /sdcard/ -type f -print`
 *
 * Note: On API level < 24
 * * The `ls -1` option is present only API level >= 24.
 * * `ls /sdcard` prints just `/sdcard`
 * * `ls /sdcard/` prints the contents of the folder.
 *
 * @param path absolute path of directory on device to list recursively.
 * @return set of absolute [Path]s.
 */
fun DeviceController.listFilesRecursively(path: String): Set<Path> {
  require(Path(path).isAbsolute) { "Supplied path must be absolute" }
  // For API level < 24, ensure the path ends in /
  val amendedPath = if (path.endsWith("/")) path else "$path/"
  // Omit stderr and pipe to cat to ensure each entry is on a single line.
  val command = listOf("ls", "-R", amendedPath, "2>/dev/null", "|cat")
  val output = this.deviceShell(command).output
  // One failure mode here is output being "adb: device 'emulator-5554' not found".
  var currentDir: Path? = null
  val paths = mutableSetOf<Path>()
  for (line in output) {
    // Ignore if there is a permission issue as the directory can't be read anyway.
    if (line.contains("Permission denied")) continue
    // Directory
    if (line.startsWith("/") && line.endsWith(":")) {
      currentDir = Path(line.substringBefore(":")).toAbsolutePath()
      paths.removeIf { it == currentDir }
      continue
    }
    if (line.isEmpty()) {
      // The current directory is done.
      currentDir = null
    } else {
      // Add file to list.
      if (currentDir == null) continue
      paths.add(currentDir.resolve(line).toAbsolutePath())
    }
  }
  return paths.toSet()
}

/** Android specific constants. */
object Constants {
  val UNLOCK_SCREEN_CMD = "input keyevent 82 && input keyevent 4".split(" ")

  const val PRODUCT_NAME_PROP = "ro.product.name"

  const val PRODUCT_SYSTEM_NAME_PROP = "ro.product.system.name"

  const val WEAR_STEM_PROPERTY = "ro.stem_primary.location.x"

  const val WEAR_PROPERTY_NAME_VALUE = "_gwear_"

  const val ANDROID_TV_PROPERTY_NAME_VALUE = "_atv_"

  const val SYSTEM_USER = "0"

  const val ANR_FOLDER = "anr"
}
