/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.network

/**
 * This class contains all of the valid socket types (as of July 2019) that can be specified in the
 * adb forward or adb reverse commands.
 *
 * Citation for socket docs/descriptions (quotes from the source denoted by †):
 *  Book Title: Embedded Android: Porting, Extending, and Customizing
 *  Author: Karim Yaghmour
 *  Year: 2013
 *  City: Sebastopol, California, USA
 *  Publisher: O'Reilly Media, Inc.
 *  Page: 210, Table 6-10
 */
sealed class AdbNetworkSocket(
  private val target: Any, // as long as it has .toString() it doesn't matter.
  private val signature: String
) {
  private companion object {
    private const val TCP = "tcp"
    private const val LOCAL_RESERVED = "localreserved"
    private const val LOCAL_ABSTRACT = "localabstract"
    private const val LOCAL_FILESYSTEM = "localfilesystem"
    private const val DEV = "dev"
    private const val JDWP = "jdwp"
  }

  /** Converts this [AdbNetworkSocket] to a valid string for use on the command line. */
  override fun toString(): String = "$signature:$target"

  /** "Standard TCP port. This should be a nonnegative integer value."† */
  class TCP(val port: Int) : AdbNetworkSocket(port, TCP) {
    init {
      require(port >= 0) {
        "Valid TCP ports must be >= 0. Note: 0 auto-assigns ports in some contexts."
      }
    }
  }

  /**
   * "Android's "reserved" Unix domain sockets. They're all in /dev/socket, and they have very
   * specific uses... These include dbus, installd, keystore, netd, property_service, rild,
   * rild-debug, vold, and zygote."†
   */
  class LocalReserved(
    val unixDomainSocketName: String
  ) : AdbNetworkSocket(unixDomainSocketName, LOCAL_RESERVED)

  /**
   * "An "abstract" Unix domain socket. This is like a Unix Domain socket, but it's a Linux-specific
   * extension. Have a look at the unix man page for more detail: man 7 unix."†
   */
  class LocalAbstract(
    val unixDomainSocketName: String
  ) : AdbNetworkSocket(unixDomainSocketName, LOCAL_ABSTRACT)

  /** "A regular Unix domain socket. This shows up as an entry in the filesystem."† */
  class LocalFileSystem(
    val unixDomainSocketName: String
  ) : AdbNetworkSocket(unixDomainSocketName, LOCAL_FILESYSTEM)

  /**
   * "Actual devices on the target. You must provide the full path to the device in the
   * filesystem."†
   */
  class Dev(val characterDeviceName: String) : AdbNetworkSocket(characterDeviceName, DEV)

  /**
   * "Used to specify the PID of a Dalvik process for debugging purposes."†
   *
   * This is typically used to attach a debugger by doing the following:
   * ```
   *  # Step 1 - Get a list of all debuggable process PIDs on the device.
   *  adb jdwp
   *  # Step 2 -Select one of the PIDs and choose a socket to forward from the host to that PID.
   *  adb forward SOCKET_TYPE:HOST_SOCKET jdwp:TARGET_PID
   *  # Step 3 - Attach the java debugger.
   *  jdb -attach HOST_SOCKET
   * ```
   */
  class JDWP(val processPid: Int) : AdbNetworkSocket(processPid, JDWP)
}
