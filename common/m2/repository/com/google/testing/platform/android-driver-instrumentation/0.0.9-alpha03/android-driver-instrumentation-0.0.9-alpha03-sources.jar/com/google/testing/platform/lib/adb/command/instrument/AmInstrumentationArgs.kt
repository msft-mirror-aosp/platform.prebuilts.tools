/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.instrument

import com.google.testing.platform.lib.adb.command.ShellSyntax

/**
 * This class represents a collection of arguments for an am instrumentation command.
 *
 * @see https://developer.android.com/studio/test/command-line#AMSyntax
 */
interface AmInstrumentationArgs {
  companion object {

    const val RAW = "-r"
    const val WAIT = "-w"
    const val NO_HIDDEN_API_CHECKS = "--no-hidden-api-checks"
    const val NO_WINDOW_ANIMATION = "--no-window-animation"

    /**
     * Turns a name and value into a key-value pair flag for the am instrument command.
     *
     * Examples output:
     * * With a non-null value: "-e [name] [value]"
     * * With a null value: "-e [name]"
     */
    fun createInstrumentationOption(name: String, value: String? = null) =
      value?.let { listOf("-e", name, ShellSyntax.quote(it)) } ?: listOf("-e", name)
  }

  /** The class of the instrumentation test runner used to run these tests */
  val instrumentationRunnerClass: String

  /**
   * Disables restrictions on the use of hidden APIs.
   *
   * Represents the flag `--no-hidden-api-checks`
   *
   * @see https://developer.android.com/preview/restrictions-non-sdk-interfaces more information on
   *   what hidden APIs are, and how this can affect your app.
   */
  val noHiddenApiChecks: Boolean

  /**
   * Disables window animations.
   *
   * Represents the flag `--no-window-animation`.
   */
  val noWindowAnimation: Boolean

  /**
   * Outputs results in raw format. Use this flag when you want to collect performance measurements,
   * so that they are not formatted as test results. This flag is designed for use with the flag `-e
   * perf true`
   *
   * Represents the flag `-r`
   *
   * @see https://developer.android.com/studio/test/command-line#AMOptionsSyntax
   */
  val rawOutput: Boolean

  /**
   * Forces am instrument to wait until the instrumentation terminates before terminating itself.
   * The net effect is to keep the shell open until the tests have finished. This flag is not
   * required, but if you do not use it, you will not see the results of your tests on the command
   * line.
   *
   * Represents the flag `-w`
   */
  val waitsForInstrumentation: Boolean

  /** Additional arguments to add to `am instrument`. */
  val additionalArgs: List<String>

  /**
   * Extra key-value flags to add to the am instrument command. These can be parsed from the
   * [android.os.Bundle] when the Instrumentation is created. If an option only needs to be present
   * and does not need a value, use `"key" to null`.
   *
   * Example outs:
   * * `"foo" to "bar"`: `-e foo bar`
   * * `"baz" to null`: `-e baz`
   *
   * @see https://developer.android.com/studio/test/command-line#AMSyntax
   */
  val additionalOptions: Map<String, String?>

  /**
   * Converts this object into a list representing an am instrument command.
   *
   * The general syntax of the am instrument command is: `am instrument [flags]
   * <test_package>/<runner_class>`
   *
   * @see https://developer.android.com/studio/test/command-line#AMSyntax
   */
  fun toArgs(): List<String>
}

/** Factory for the default implementation of [AmInstrumentationArgs]. */
@Suppress("FunctionName")
fun AmInstrumentationArgs(
  instrumentationRunnerClass: String,
  noHiddenApiChecks: Boolean = false,
  noWindowAnimation: Boolean = false,
  rawOutput: Boolean = true,
  waitsForInstrumentation: Boolean = true,
  additionalOptions: Map<String, String?> = emptyMap(),
  additionalArgs: List<String> = emptyList(),
): AmInstrumentationArgs =
  DefaultInstrumentationArgs(
    instrumentationRunnerClass = instrumentationRunnerClass,
    noHiddenApiChecks = noHiddenApiChecks,
    noWindowAnimation = noWindowAnimation,
    rawOutput = rawOutput,
    waitsForInstrumentation = waitsForInstrumentation,
    additionalOptions = additionalOptions,
    additionalArgs = additionalArgs,
  )

/**
 * Wraps the current [AmInstrumentationArgs] object with the default arguments for the command.
 *
 * TODO(b/136600432): Consider making this part of the interface itself to allow
 *   [AmInstrumentationArgs] implementations to wrap/decorate each other. One usecase would be:
 *   `AmInstrumentationArgs(decorator = AJURArgs(decorator = MyCustomInstrArgs))`
 */
fun AmInstrumentationArgs.defaultArgs(
  implementationOptions: Map<String, String?> = emptyMap()
): MutableList<String> {
  return DefaultInstrumentationArgs(
      instrumentationRunnerClass = instrumentationRunnerClass,
      noHiddenApiChecks = noHiddenApiChecks,
      noWindowAnimation = noWindowAnimation,
      rawOutput = rawOutput,
      waitsForInstrumentation = waitsForInstrumentation,
      additionalArgs = additionalArgs,
      additionalOptions = additionalOptions + implementationOptions,
    )
    .toArgs()
    .toMutableList()
}
