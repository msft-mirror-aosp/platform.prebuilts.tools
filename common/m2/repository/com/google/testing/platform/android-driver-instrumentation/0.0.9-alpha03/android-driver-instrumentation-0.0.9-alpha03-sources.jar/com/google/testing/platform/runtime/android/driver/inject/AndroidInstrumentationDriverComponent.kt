/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.driver.inject

import com.google.testing.platform.api.config.Config
import com.google.testing.platform.api.device.Device
import com.google.testing.platform.lib.adb.command.io.LogWriter
import com.google.testing.platform.lib.adb.command.timing.TestTimeTracker
import com.google.testing.platform.runtime.android.driver.lib.ListInstrumentationsCommand
import com.google.testing.platform.runtime.android.driver.lib.TestRunnerArgs
import dagger.BindsInstance
import dagger.Component
import javax.inject.Provider

/** Dagger component for AndroidInstrumentationDriver. */
@Component(modules = [AndroidInstrumentationDriverModule::class])
interface AndroidInstrumentationDriverComponent {
  val testRunnerArgs: TestRunnerArgs
  val listInstrumentationsCommand: ListInstrumentationsCommand
  val instrumentationWriter: LogWriter
  val testTimeTrackerFactory: Provider<TestTimeTracker>

  @Component.Builder
  interface Builder {

    @BindsInstance fun device(device: Device): Builder

    @BindsInstance fun config(config: Config): Builder

    fun build(): AndroidInstrumentationDriverComponent

    companion object {
      fun new(): Builder = DaggerAndroidInstrumentationDriverComponent.builder()
    }
  }
}
