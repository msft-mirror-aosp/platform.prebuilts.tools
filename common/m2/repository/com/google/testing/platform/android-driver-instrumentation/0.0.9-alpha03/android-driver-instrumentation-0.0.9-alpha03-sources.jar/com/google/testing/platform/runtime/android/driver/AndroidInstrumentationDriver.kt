/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.driver

import androidx.test.services.storage.TestStorageConstants
import com.google.auto.service.AutoService
import com.google.common.annotations.VisibleForTesting
import com.google.common.math.LongMath.checkedAdd
import com.google.common.math.LongMath.checkedSubtract
import com.google.protobuf.Timestamp
import com.google.protobuf.util.Timestamps
import com.google.testing.platform.api.config.Config
import com.google.testing.platform.api.config.environment
import com.google.testing.platform.api.config.parseConfig
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.context.events
import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.driver.TestDriverConfigImpl
import com.google.testing.platform.api.event.get
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.config.v1.extension.toInstrumentation
import com.google.testing.platform.lib.adb.command.instrument.AmInstrumentationListener
import com.google.testing.platform.lib.adb.command.instrument.AmInstrumentationParser
import com.google.testing.platform.lib.adb.command.instrument.InstrumentationResult
import com.google.testing.platform.lib.adb.command.instrument.TestIdentifier
import com.google.testing.platform.lib.adb.command.instrument.TestResult
import com.google.testing.platform.lib.adb.command.io.LogWriter
import com.google.testing.platform.lib.adb.command.parser.Instrumentation
import com.google.testing.platform.lib.adb.command.timing.TestTimeTracker
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.plugin.android.proto.InstrumentationTestOptionsPluginProto.InstrumentationTestOptionsProvided
import com.google.testing.platform.proto.api.config.AndroidInstrumentationDriverProto.AndroidInstrumentationDriver as AndroidInstrumentationDriverConfig
import com.google.testing.platform.proto.api.config.AndroidInstrumentationDriverProto.AndroidInstrumentationDriver.ShellExecutionOption
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.deviceId
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto
import com.google.testing.platform.proto.api.core.TestCaseProto
import com.google.testing.platform.proto.api.core.TestResultKt.testDetailsEntry
import com.google.testing.platform.proto.api.core.TestResultProto
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.IN_PROGRESS
import com.google.testing.platform.proto.api.core.TestSuiteResultProto
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.artifact
import com.google.testing.platform.proto.api.core.error
import com.google.testing.platform.proto.api.core.label
import com.google.testing.platform.proto.api.core.path
import com.google.testing.platform.proto.api.core.testCase
import com.google.testing.platform.proto.api.core.testResult
import com.google.testing.platform.proto.api.core.testSuiteMetaData
import com.google.testing.platform.runtime.android.controller.ext.asyncShell
import com.google.testing.platform.runtime.android.controller.ext.getExternalStoragePath
import com.google.testing.platform.runtime.android.controller.ext.isTestServiceInstalled
import com.google.testing.platform.runtime.android.driver.inject.AndroidInstrumentationDriverComponent
import com.google.testing.platform.runtime.android.driver.inject.DaggerAndroidInstrumentationDriverComponent
import com.google.testing.platform.runtime.android.driver.lib.TestRunnerArgs
import java.time.Duration
import java.time.Instant
import java.util.concurrent.TimeoutException
import java.util.logging.Level
import javax.inject.Provider

/**
 * [TestDriver] implementation to run android instrumentation tests using direct instrumentation or
 * orchestrator V1.
 *
 * This driver implementation runs the test with the supplied instrumentation. Doesn't do test
 * discovery, sharding or filtering.
 *
 * Note: This test driver does not support plugins which depend on BeforeEacTest and AfterEachTest
 * being called the same number of times. Since this plugin would call BeforeEachTest just once for
 * the entire test suite and AfterEachTest for each test case.
 */
@AutoService(TestDriver::class)
class AndroidInstrumentationDriver
@VisibleForTesting
constructor(
  private val androidInstrumentationDriverComponentBuilder:
    AndroidInstrumentationDriverComponent.Builder
) : TestDriver {
  // No args constructor for autoservice
  constructor() :
    this(
      androidInstrumentationDriverComponentBuilder =
        DaggerAndroidInstrumentationDriverComponent.builder()
    )

  private var amInstrumentTimeout = Duration.ofSeconds(DEFAULT_AM_INSTRUMENT_TIMEOUT_SEC)
  private var isTestServiceInstalled = false
  private var useOrchestrator = false
  private var coverageFilePath: String? = null
  private lateinit var testRunnerArgs: TestRunnerArgs
  private lateinit var instrumentation: Instrumentation
  private lateinit var instrumentationWriter: LogWriter
  private lateinit var testTimeTrackerFactory: Provider<TestTimeTracker>
  private lateinit var config: Config
  private lateinit var context: Context
  private lateinit var androidInstrumentationDriverConfig: AndroidInstrumentationDriverConfig
  private lateinit var instrumentationHandle: CommandHandle
  private lateinit var externalStoragePath: String
  private lateinit var shellExecutionOption: ShellExecutionOption
  private lateinit var testSuiteId: TestSuiteResultProto.TestSuiteMetaData

  override fun configure(context: Context) {
    this.context = context
    this.config = context.config as TestDriverConfigImpl
    androidInstrumentationDriverConfig = config.parseConfig<AndroidInstrumentationDriverConfig>()!!
    logger.info("Configuring Android Instrumentation driver: $androidInstrumentationDriverConfig")

    val runtime = androidInstrumentationDriverConfig.androidInstrumentationRuntime
    instrumentation = runtime.instrumentationInfo.toInstrumentation()
    useOrchestrator = androidInstrumentationDriverConfig.useOrchestrator
    shellExecutionOption =
      if (
        androidInstrumentationDriverConfig.shellExecutionOption ==
          ShellExecutionOption.UNSPECIFIED_SHELL_EXECUTION_OPTION
      )
        ShellExecutionOption.NO_SHELL_EXECUTION
      else androidInstrumentationDriverConfig.shellExecutionOption

    require(instrumentation.isNull() || instrumentation.isValid()) {
      """
      |Please provide a valid instrumentation to run the test.
      |The provided instrumentation is not valid: $instrumentation
      """
        .trimMargin()
    }
  }

  /** Setup driver and its dependencies. */
  private fun setUp(controller: DeviceController) {
    config as TestDriverConfigImpl
    externalStoragePath = controller.getExternalStoragePath()

    // Set timeout from config if present
    androidInstrumentationDriverConfig.amInstrumentTimeout.also {
      if (it > 0L) {
        amInstrumentTimeout = Duration.ofSeconds(it)
      }
    }

    val testDriverComponent =
      androidInstrumentationDriverComponentBuilder
        .config(config)
        .device(controller.getDevice())
        .build()

    testRunnerArgs = testDriverComponent.testRunnerArgs
    instrumentationWriter = testDriverComponent.instrumentationWriter
    testTimeTrackerFactory = testDriverComponent.testTimeTrackerFactory

    if (testRunnerArgs.useTestStorageService) {
      isTestServiceInstalled =
        controller.isTestServiceInstalled().also { installed ->
          if (installed) logger.fine("AndroidX test services are installed on the device.")
        }
    }
    if (testRunnerArgs.enableCoverage) {
      coverageFilePath = onDeviceCoverageFile(instrumentation.testPackage, isTestServiceInstalled)
    }

    if (instrumentation.isNull()) {
      logger.info(
        """
        |No instrumentation was configured.
        |Trying to detect one by listing available instrumentations in the test package.
        """
          .trimMargin()
      )
      instrumentation =
        testDriverComponent.listInstrumentationsCommand.getInstrumentation(controller)
    }
    if (!instrumentation.isValid()) {
      throw AndroidInstrumentationDriverException(
        errorSummary = AndroidInstrumentationDriverErrorSummary.INVALID_INSTRUMENTATION_PROVIDED,
        message =
          """
          |No valid instrumentation is provided or can be detected in the test package.
          |The instrumentation provided/detected is not valid: $instrumentation
          """
            .trimMargin(),
      )
    }
  }

  /**
   * Set up the driver with all its dependencies. Runs the instrumentation using the `am
   * instrumentation` command.
   */
  override fun run(controller: DeviceController, testResultPublisher: TestResultPublisher) {
    logger.info("Running Android Instrumentation driver.")
    setUp(controller)

    val additionalOptions = hashMapOf<String, String>()
    for (event in context.events.get<InstrumentationTestOptionsProvided>()) {
      additionalOptions.putAll(event.testOptionsMap)
    }

    runTestSuite(
      controller,
      buildArgsForTestSuite(
        amInstrumentTimeout,
        coverageFilePath,
        isTestServiceInstalled,
        additionalOptions,
      ),
      testResultPublisher,
      amInstrumentTimeout,
    )
  }

  override fun cancel(aborted: Boolean): Boolean {
    logger.warning("Cancellation triggered in Android Instrumentation Driver.")
    return if (this::instrumentationHandle.isInitialized) {
      instrumentationHandle.stop()
      true
    } else {
      false
    }
  }

  /**
   * Constructs the instrumentation command with parameters for the test suite.
   *
   * @param timeout timeout for the instrumentation test command.
   * @param coverageFilePath the file path that code coverage data should be dumped to. No coverage
   *   data will be generated if null or empty.
   * @param useTestStorageService whether to use the test storage service in running the test.
   */
  private fun buildArgsForTestSuite(
    timeout: Duration,
    coverageFilePath: String?,
    useTestStorageService: Boolean,
    additionalOptions: Map<String, String>,
  ): List<String> {
    return AndroidInstrumentationArgs(
        androidTestPackage = instrumentation.testPackage,
        instrumentationRunnerClass = instrumentation.instrumentationClass,
        enableDebugging = testRunnerArgs.enableDebugging,
        coverageReportPath = coverageFilePath,
        additionalOptions = testRunnerArgs.args + additionalOptions,
        instrumentCommandTimeout = timeout,
        rawOutput = true,
        noHiddenApiChecks = false,
        noWindowAnimation = testRunnerArgs.noWindowAnimation,
        waitsForInstrumentation = true,
        testClasses = listOf(),
        useOrchestrator = useOrchestrator,
        useTestStorageService = useTestStorageService,
        shellExecutionOption = shellExecutionOption,
        useLocalSocket = androidInstrumentationDriverConfig.useLocalSocketShellExecutor,
        additionalArgs =
          androidInstrumentationDriverConfig.androidInstrumentationRuntime.instrumentationArgs
            .additionalArgsList,
      )
      .toArgs()
  }

  /**
   * Executes the instrumentation using [args] and parses the output.
   *
   * [testResultListener] is registered to consume the results.
   */
  private fun runTestSuite(
    deviceController: DeviceController,
    args: List<String>,
    testResultPublisher: TestResultPublisher,
    timeout: Duration,
  ) {
    testSuiteId = testSuiteMetaData { device = (config as TestDriverConfigImpl).deviceId }
    val instrumentationListener = InstrumentationListener(testResultPublisher, testSuiteId.device)
    val instrumentationParser =
      AmInstrumentationParser(setOf(instrumentationListener), testTimeTrackerFactory::get)
    val testIssues = mutableListOf<Issue>()
    var markTestSuiteFailed = false

    instrumentationHandle =
      deviceController.asyncShell(args) { line ->
        instrumentationWriter.write(line)
        instrumentationParser.parse(line)
      }

    try {
      // We're giving the shell command extra time to finish up after am instrument command finishes
      instrumentationHandle.waitFor(timeout.plusSeconds(15))

      val statusCode = instrumentationHandle.exitCode()
      if (statusCode != 0) {
        logger.warning(
          """"Instrumentation command failed with non zero exit code:
          |Instrumentation command: ${args.joinToString(" ")}
          |StatusCode: $statusCode"""
            .trimMargin()
        )
      }
    } catch (ex: TimeoutException) {
      logger.log(
        Level.WARNING,
        "Instrumentation did not complete in the configured test timeout of $timeout",
        ex,
      )
      testIssues.add(
        Issues.INSTRUMENTATION_TIMED_OUT.toIssue(
          "The test did not complete in the configured timeout of $timeout and was aborted."
        )
      )
    }

    instrumentationParser.done()

    val instrumentationResult = instrumentationListener.instrumentationResult
    val instrumentationFailureMessage = instrumentationListener.instrumentationFailureMessage

    if (instrumentationFailureMessage != null) {
      markTestSuiteFailed = true
      testIssues.add(Issues.INSTRUMENTATION_FAILED.toIssue(instrumentationFailureMessage))
    } else if (instrumentationResult == null || !instrumentationResult.success) {
      markTestSuiteFailed = true
      val bundleString =
        instrumentationResult?.bundle?.asIterable()?.joinToString(separator = "\n") {
          "${it.key}: ${it.value}"
        }
      testIssues.add(
        Issues.INSTRUMENTATION_FAILED.toIssue(
          """
            Instrumentation did not complete:
            Instrumentation code: ${instrumentationResult?.code}
            Instrumentation result bundle: $bundleString
          """
            .trimIndent()
        )
      )
    }

    if (instrumentationWriter.logPath.isFile() && instrumentationWriter.logPath.length() > 0) {
      testResultPublisher.addTestSuiteArtifact(
        testSuiteId,
        artifact {
          label = label {
            label = instrumentationWriter.logPath.name
            namespace = AndroidInstrumentationDriver::class.java.name
          }
          sourcePath = path { path = instrumentationWriter.logPath.absolutePath }
          type = TestArtifactProto.ArtifactType.TEST_DATA
          mimeType = "text/plain"
        },
      )
    }

    coverageFilePath?.let {
      val coverageArtifact = artifact {
        sourcePath = path { path = "${config.environment.outputDirectory}/$COVERAGE_FILE_NAME" }
        destinationPath = path {
          path =
            if (isTestServiceInstalled) {
              "$externalStoragePath/${TestStorageConstants.ON_DEVICE_PATH_INTERNAL_USE}$coverageFilePath"
            } else {
              it
            }
        }
      }
      testResultPublisher.addTestSuiteArtifact(testSuiteId, coverageArtifact)
      deviceController.pull(coverageArtifact)
    }

    if (
      markTestSuiteFailed && testResultPublisher.workingDraft(testSuiteId).testStatus == IN_PROGRESS
    ) {
      testResultPublisher.setTestSuiteStatus(testSuiteId, TestStatus.FAILED)
    }

    for (issue in testIssues) {
      testResultPublisher.addTestSuiteIssue(testSuiteId, issue)
    }
  }

  /**
   * Returns the on-device coverage execution data file path.
   *
   * If the test service is installed on the device, returns a relative path under its internal file
   * directory, else returns a file path under the app's data folder.
   */
  private fun onDeviceCoverageFile(testPackage: String, isTestServiceInstalled: Boolean) =
    if (isTestServiceInstalled) {
      "${testPackage}_$COVERAGE_FILE_NAME"
    } else {
      "/data/data/$testPackage/$COVERAGE_FILE_NAME"
    }

  private class InstrumentationListener(
    private val testResultPublisher: TestResultPublisher,
    private val deviceId: DeviceId,
  ) : AmInstrumentationListener {

    var instrumentationFailureMessage: String? = null
    var instrumentationResult: InstrumentationResult? = null
    var testSuiteId: TestSuiteMetaData? = null
    var testCount = -1

    override fun instrumentationStarted(testCount: Int) {
      // The actual test suite name as specified by the JUnit @Suite and @SuiteDisplayName
      // annotations are not available here, so we don't set it at all.
      testResultPublisher.beforeTestSuite(
        testSuiteMetaData {
            scheduledTestCaseCount = testCount
            device = deviceId
          }
          .also { testSuiteId = it }
      )
    }

    override fun testStarted(testIdentifier: TestIdentifier) {
      testResultPublisher.beforeTest(toTestCase(testIdentifier))
    }

    override fun testEnded(testResult: TestResult) {
      testResultPublisher.afterTest(toTestResult(testResult))
    }

    override fun instrumentationFailed(errorMessage: String) {
      guaranteeBeforeTestSuite()
      instrumentationFailureMessage = errorMessage
    }

    override fun instrumentationEnded(instrumentationResult: InstrumentationResult) {
      guaranteeBeforeTestSuite()
      this.instrumentationResult = instrumentationResult
    }

    private fun guaranteeBeforeTestSuite() {
      if (testSuiteId == null) {
        // No tests ran! We don't know the name to put it in the metadata.
        testResultPublisher.beforeTestSuite(
          testSuiteMetaData {
              scheduledTestCaseCount = 0
              device = deviceId
            }
            .also { testSuiteId = it }
        )
      }
    }

    private fun toTestCase(testIdentifier: TestIdentifier): TestCaseProto.TestCase = testCase {
      testClass = testIdentifier.testClass
      testPackage = testIdentifier.testPackage
      testMethod = testIdentifier.testMethod
      device = deviceId
    }

    private fun toTestResult(testResult: TestResult): TestResultProto.TestResult = testResult {
      testStatus = testResult.status
      for ((key, value) in testResult.statusBundle) {
        details += testDetailsEntry {
          this.key = key
          this.value = value
        }
      }
      testCase = testCase {
        testClass = testResult.testIdentifier.testClass
        testPackage = testResult.testIdentifier.testPackage
        testMethod = testResult.testIdentifier.testMethod
        startTime = testResult.startTime.toProtoTimestamp()
        endTime = testResult.endTime.toProtoTimestamp()
        device = deviceId
      }
      testResult.stackTrace?.let {
        error = error {
          errorMessage = it
          errorType = it.substringAfter("Caused by: ").substringBefore(":")
          stackTrace = it
        }
      }
    }
  }

  private enum class Issues(val code: Int, val severity: Issue.Severity) {
    INSTRUMENTATION_FAILED(1, Issue.Severity.SEVERE),
    INSTRUMENTATION_TIMED_OUT(2, Issue.Severity.SEVERE);

    fun toIssue(issueMessage: String): Issue =
      Issue.newBuilder().let {
        it.namespaceBuilder.namespace = AndroidInstrumentationDriver::class.java.name
        it.severity = severity
        it.code = code
        it.name = name
        it.message = issueMessage
        it.build()
      }
  }

  private companion object {
    @JvmStatic private val logger = getLogger()
    private const val DEFAULT_AM_INSTRUMENT_TIMEOUT_SEC = 240L
    private const val COVERAGE_FILE_NAME = "ondevicecoverage.ec"
    private const val NANOS_PER_SECOND = 1000000000

    // fork of protobuf.util.JavaTimeconversions, which is not opensourced
    // TODO(https://github.com/protocolbuffers/protobuf/issues/6641): remove and replace with
    // protobuf.util.JavaTimeconversions
    private fun Instant.toProtoTimestamp(): Timestamp {
      return normalizeTimestamp(epochSecond, nano)
    }

    private fun normalizeTimestamp(seconds: Long, nano: Int): Timestamp {
      var adjustedSeconds = seconds
      var adjustedNanos = nano
      if (adjustedNanos <= -NANOS_PER_SECOND || adjustedNanos >= NANOS_PER_SECOND) {
        adjustedSeconds = checkedAdd(adjustedSeconds, (adjustedNanos.toLong() / NANOS_PER_SECOND))
        adjustedNanos = (adjustedNanos % NANOS_PER_SECOND)
      }
      if (adjustedNanos < 0) {
        adjustedNanos =
          (adjustedNanos +
            NANOS_PER_SECOND) // no overflow since nanos is negative (and we're adding)
        adjustedSeconds = checkedSubtract(adjustedSeconds, 1)
      }
      val timestamp =
        Timestamp.newBuilder().setSeconds(adjustedSeconds).setNanos(adjustedNanos).build()
      return Timestamps.checkValid(timestamp)
    }
  }
}
