/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.io

import com.google.testing.platform.lib.logging.jvm.getLogger
import java.io.File
import java.io.IOException
import java.nio.file.Path
import javax.inject.Inject
import javax.inject.Named

/**
 * Writes logs to files in the configured test outputs directory to be referenced by
 * [com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact]s.
 */
class OutputsLogWriter @Inject constructor(@Named("InstrumentationLog") path: Path) : LogWriter {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  override val logPath: File = path.toFile()

  /**
   * Writes a log to the test outputs directory. Will append to the current log if one exists.
   *
   * @param lines A String of formatted lines to write to a file.
   * @return the written file.
   */
  override fun write(lines: String) {
    try {
      if (logPath.exists()) {
        logPath.appendText(lines + "\n")
      } else {
        if (!logPath.ensureDirectoryExists())
          logger.warning("Failed to ensure directory exists for path: $logPath")
        logPath.writeText(lines + "\n")
      }
    } catch (ioe: IOException) {
      throw LogWriterException("Failed to write to log: $logPath", ioe)
    }
  }
}

private fun File.ensureDirectoryExists() =
  try {
    File(absoluteFile.parent).mkdirs()
    true
  } catch (e: Exception) {
    false
  }
