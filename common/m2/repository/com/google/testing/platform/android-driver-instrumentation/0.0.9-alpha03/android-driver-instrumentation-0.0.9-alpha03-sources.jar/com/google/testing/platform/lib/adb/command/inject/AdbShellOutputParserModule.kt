/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

import com.google.common.eventbus.EventBus
import com.google.testing.platform.lib.adb.command.parser.AaptDumpPackageLineProcessor
import com.google.testing.platform.lib.adb.command.parser.AdbDevicesLineProcessor
import com.google.testing.platform.lib.adb.command.parser.AdbInstrumentationListProcessor
import com.google.testing.platform.lib.adb.command.parser.AndroidPropertyProcessor
import com.google.testing.platform.lib.adb.command.parser.DevicesListParser
import com.google.testing.platform.lib.adb.command.parser.InstrumentationListParser
import com.google.testing.platform.lib.adb.command.parser.InstrumentationTestRunnerProcessor
import com.google.testing.platform.lib.adb.command.parser.RunTestParser
import com.google.testing.platform.lib.adb.command.parser.ShellGetPropParser
import com.google.testing.platform.lib.adb.command.parser.ShellVariableParser
import com.google.testing.platform.lib.adb.command.parser.ShellVariableProcessor
import com.google.testing.platform.lib.adb.command.subprocess.parser.DevicesListLineProcessorParser
import com.google.testing.platform.lib.adb.command.subprocess.parser.InstrumentationListProcessorParser
import com.google.testing.platform.lib.adb.command.subprocess.parser.InstrumentationProcessorRunTestParser
import com.google.testing.platform.lib.adb.command.subprocess.parser.ShellGetPropProcessorParser
import com.google.testing.platform.lib.adb.command.subprocess.parser.ShellVariableProcessorParser
import dagger.Module
import dagger.Provides

/** Dagger module that provides various parsers for different adb commands. */
@Module
class AdbShellOutputParserModule {

  @Provides
  fun eventBus() = EventBus()

  @Provides
  fun instrumentationLineProcessor(eventBus: EventBus) =
    InstrumentationTestRunnerProcessor(eventBus)

  @Provides
  fun adbDevicesLineProcessor() = AdbDevicesLineProcessor()

  @Provides
  fun adbShellVariableLineProcessor() = ShellVariableProcessor()

  @Provides
  fun adbShellPropertyLineProcessor() = AndroidPropertyProcessor()

  @Provides
  fun adbInstrumentationListProcessor() = AdbInstrumentationListProcessor()

  @Provides
  fun devicesListParser(lineProcessor: AdbDevicesLineProcessor): DevicesListParser =
    DevicesListLineProcessorParser(lineProcessor)

  @Provides
  fun shellVariableProcessor(lineProcessor: ShellVariableProcessor): ShellVariableParser =
    ShellVariableProcessorParser(lineProcessor)

  @Provides
  fun devicePropertiesProcessor(lineProcessor: AndroidPropertyProcessor): ShellGetPropParser =
    ShellGetPropProcessorParser(lineProcessor)

  @Provides
  fun testRunnerParser(lineProcessor: InstrumentationTestRunnerProcessor): RunTestParser =
    InstrumentationProcessorRunTestParser(lineProcessor)

  @Provides
  fun instrumentationListParser(lineProcessor: AdbInstrumentationListProcessor):
    InstrumentationListParser = InstrumentationListProcessorParser(lineProcessor)

  @Provides
  fun aaptDumpLineProcessor() = AaptDumpPackageLineProcessor()
}
