/*
 * Copyright (C) 2017 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.lib.adb.command.parser

import com.google.errorprone.annotations.CanIgnoreReturnValue

data class ExecutedTest(
  val id: String? = null,
  val currentTest: String? = null,
  val numTests: String? = null,
  val testClass: String? = null,
  val testMethod: String? = null,
  val status: Status? = null,
  val allLines: String = "",
  val testResult: String = "",
  val stackTrace: String = "",
  val testStatusStream: String = ""
) {
  enum class Status {
    ERROR,
    FAILED,
    PASSED,
    STARTED,
    IGNORED,
    ASSUMPTION_FAILURE
  }

  class Builder(
    var id: String? = null,
    var currentTest: String? = null,
    var numTests: String? = null,
    var testClass: String? = null,
    var testMethod: String? = null,
    var status: Status? = null,
    val allLinesBuilder: StringBuilder = java.lang.StringBuilder(),
    val testResultBuilder: StringBuilder = java.lang.StringBuilder(),
    val stackTraceBuilder: StringBuilder = java.lang.StringBuilder(),
    val testStatusStreamBuilder: StringBuilder = java.lang.StringBuilder()
  ) {

    fun build(): ExecutedTest {
      return ExecutedTest(
        id,
        currentTest,
        numTests,
        testClass,
        testMethod,
        status,
        allLinesBuilder.toString(),
        testResultBuilder.toString(),
        stackTraceBuilder.toString(),
        testStatusStreamBuilder.toString()
      )
    }

    @CanIgnoreReturnValue
    fun appendAllLines(allLines: String): Builder {
      return appendToStringBuilder(testResultBuilder, allLines)
    }

    @CanIgnoreReturnValue
    fun appendResultStream(testResult: String): Builder {
      return appendToStringBuilder(testResultBuilder, testResult)
    }

    @CanIgnoreReturnValue
    fun appendStackTrace(stackTrace: String): Builder {
      return appendToStringBuilder(stackTraceBuilder, stackTrace)
    }

    @CanIgnoreReturnValue
    fun appendStatusStream(testStatusStream: String): Builder {
      return appendToStringBuilder(testStatusStreamBuilder, testStatusStream)
    }

    private fun appendToStringBuilder(sb: StringBuilder, text: String): Builder {
      if (sb.length > 0) {
        sb.append("\n")
      }
      sb.append(text)
      return this
    }
  }

  companion object {
    fun builder(): Builder {
      return Builder()
    }
  }
}
