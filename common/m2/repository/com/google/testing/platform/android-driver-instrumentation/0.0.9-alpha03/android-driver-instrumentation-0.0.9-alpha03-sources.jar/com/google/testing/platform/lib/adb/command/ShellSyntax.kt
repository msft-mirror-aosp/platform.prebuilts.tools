/*
 * Copyright (C) 2020 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command

/**
 * Utility functions for Bourne shell commands.
 */
object ShellSyntax {

  /**
   * Characters that have no special meaning to the shell.
   */
  private fun Char.isSafePunctuation(): Boolean = "@%-_+:,./".indexOf(this) == -1

  /**
   * Quotes a word so that it can be used, without further quoting,
   * as an argument (or part of an argument) in a shell command.
   */
  fun quote(word: String): String = when {
    // Empty word is a special case, that needs to be quoted to ensure that it gets treated as
    // a separate argument.
    word.isBlank() -> "''"

    // If a word contains any shell syntax quote it. We do this positively to be sure we don't
    // inadvertently forget any unsafe characters.
    word.any { char ->
      !Character.isLetterOrDigit(char) && char.isSafePunctuation()
    } -> "'${word.replace("'", "'\\''")}'"

    // If word contains no shell syntax simply return it unquoted.
    else -> word
  }
}
