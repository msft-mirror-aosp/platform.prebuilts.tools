/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.instrument.lib

import com.google.testing.platform.lib.adb.command.parser.Instrumentation
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.InstrumentationProto.InstrumentationFilter
import com.google.testing.platform.proto.api.core.RegexPatternProto

/**
 * Auto-detects test instrumentations installed on a Android device. This class returns the first
 * supported instrumentation found on the device.
 *
 * Multiple instrumentation classes may be installed on the device. Some may not be test runners at
 * all and should be ignored. Some test runners may be preferred over others. Three levels of
 * preference apply when picking one out of multiple available instrumentations:
 * 1. If a specific test runner is requested to be used in the config, use it;
 * 2. If a "preferred" instrumentation class is available, use it;
 * 3. Otherwise return any available instrumentation class.
 *
 * @param availableInstrumentations list of instrumentations available on the device.
 * @param configInstrumentation optional config instrumentation, if specified, this class will
 *   attempt to verify that the instrumentation exists on device and return it for execution.
 * @param instrumentationFilter filter for selecting supported instrumentation instances, when the
 *   [configInstrumentation] is not given.
 */
class InstrumentationFinder
constructor(
  private val availableInstrumentations: Set<Instrumentation>,
  configInstrumentation: Instrumentation?,
  private val instrumentationFilter: InstrumentationFilter
) {
  companion object {
    const val ORCHESTRATOR_V1_INSTR =
      "androidx.test.orchestrator/androidx.test.orchestrator.AndroidTestOrchestrator"
    const val ORCHESTRATOR_V1_SHORT_INSTR = "androidx.test.orchestrator/.AndroidTestOrchestrator"
    const val ORCHESTRATOR_V2_INSTR =
      "com.google.testing.platform.android.core/com.google.testing.platform.android.core.AndroidTestOrchestrator" // ktlint-disable max-line-length
    const val ORCHESTRATOR_V2_SHORT_INSTR =
      "com.google.testing.platform.android.core/.AndroidTestOrchestrator"

    @JvmStatic private val logger = getLogger()

    private val IGNORED_INSTRUMENTATION_PKGS =
      setOf("com.android.smoketest", "com.android.emulator.smoketests")

    private val SUPPORTED_SERVICE_INSTRUMENTATION =
      setOf(
        ORCHESTRATOR_V1_INSTR,
        ORCHESTRATOR_V1_SHORT_INSTR,
        ORCHESTRATOR_V2_INSTR,
        ORCHESTRATOR_V2_SHORT_INSTR
      )
  }

  private val configInstrumentation: Instrumentation?

  init {
    this.configInstrumentation = configInstrumentation?.isValidOrNull()
  }

  /**
   * Returns a list of test service instrumentations.
   *
   * Instrumentations are filtered based on the specified [SupportedTestServiceInstrumentations].
   *
   * @return the list of test service instrumentations installed on a device.
   */
  fun findTestServices(): List<Instrumentation> {
    logger.fine("Requesting test service instrumentations from device.")
    return availableInstrumentations
      .filter {
        // Filter for service instrumentations. An instrumentation installed on the device usually
        // follows this pattern: <testPackage>/<instrumentationClass>
        SUPPORTED_SERVICE_INSTRUMENTATION.contains("${it.testPackage}/${it.instrumentationClass}")
      }
      .also {
        logger.fine("Found the following test service instrumentation(s): " + it.joinToString("\n"))
      }
  }

  /**
   * Returns the [ConfiguredInstrumentation] if specified and valid, otherwise tries to auto-detect
   * [SupportedInstrumentationClasses] instrumentation classes and return the first matching
   * instrumentation installed on the device.
   *
   * Ideally there is always only one target instrumentation installed on the device, that matches
   * the criteria. If multiple instrumentations are found on the device this method will log a
   * warning and return the first instance contained in the set of available instrumentations.
   *
   * @return installed instrumentation to run the test with.
   */
  fun findFirst(): Instrumentation {
    // Try to return the requested/configured instrumentation class if available:
    findConfigInstrumentation(availableInstrumentations)?.let {
      logger.info("Using specified instrumentation: $it")
      return it
    }

    // Find all possible candidate instrumentation classes:
    val found = findAndSortInstrumentations(availableInstrumentations)

    return when (found.size) {
      0 -> {
        val acceptableInstrumentationsString =
          instrumentationFilter.instrumentationClassFiltersList
            .map { "  " + it.expression.replace("\\.", ".") }
            .joinToString("\n")
        val availableInstrumentationsString =
          availableInstrumentations
            .map { "  ${it.appPackage}/${it.instrumentationClass}" }
            .joinToString("\n")
        throw InstrumentationException(
          "The available instrumentations are not supported. Must be one of:\n" +
            "$acceptableInstrumentationsString.\n" +
            "You may need to add an <instrumentation> element to your AndroidManifest file with " +
            "an acceptable instrumentation using the test's package. Example:\n" +
            "<instrumentation\n" +
            "    android:name=\"androidx.test.runner.AndroidJUnitRunner\"\n" +
            "    android:targetPackage=\"PACKAGE_NAME\">\n" +
            "</instrumentation>\n" +
            "Available instrumentations were:\n$availableInstrumentationsString"
        )
      }
      1 -> found.first().also { logger.info("Found instrumentation: $it") }
      else -> found.first().also { logger.warning("Multiple instrumentations found: $found") }
    }
  }

  /**
   * If a instrumentation was specified in the config, check if it's installed on the device.
   *
   * @param availableInstrumentations a list of supported instrumentations available on the device.
   */
  private fun findConfigInstrumentation(
    availableInstrumentations: Set<Instrumentation>
  ): Instrumentation? {
    if (configInstrumentation == null) {
      return null
    }

    // Empty non-null configInstrumentation is a wildcard matching any instrumentation, so it
    // chooses first available instrumentation.
    availableInstrumentations
      .firstOrNull { configInstrumentation.matches(it) }
      ?.let {
        return it
      }

    throw InstrumentationException(
      "Configured instrumentation: ${configInstrumentation.fullName} not found on device! " +
        "Please check logs for more details!"
    )
  }

  /**
   * Filters out ignored or unsupported test instrumentations.
   *
   * @return A list of instrumentation instances sorted by preference with the most preferred being
   *   first.
   */
  private fun findAndSortInstrumentations(
    availableInstrumentations: Set<Instrumentation>
  ): List<Instrumentation> {
    val instrumentationsToCheck =
      availableInstrumentations.filter { it.testPackage !in IGNORED_INSTRUMENTATION_PKGS }

    // Filters out unsupported instrumentations and also adds the instrumentation to the list in
    // non-ascending order of preference.
    // e.g. if the supported list is [a, b, c], and the available instrumentation set is {b, a, d},
    // the returned instrumentation list should be [a, b].
    return instrumentationFilter.instrumentationClassFiltersList
      .flatMap { classFilter ->
        // TODO(b/150524968): remove support for custom runners
        instrumentationsToCheck.filter {
          classFilter.matches(it).also { isSupported ->
            if (!isSupported) logger.fine("Ignoring instrumentation: $it")
          }
        }
      }
      .distinct()
  }

  /** @return Whether the regex matches the given [instrumentation]. */
  private fun RegexPatternProto.RegexPattern.matches(instrumentation: Instrumentation) =
    inverted xor Regex(expression).matches(instrumentation)

  private fun Regex.matches(instrumentation: Instrumentation) =
    matches(instrumentation.fullInstrumentationClass) ||
      matches(instrumentation.instrumentationClass)
}
