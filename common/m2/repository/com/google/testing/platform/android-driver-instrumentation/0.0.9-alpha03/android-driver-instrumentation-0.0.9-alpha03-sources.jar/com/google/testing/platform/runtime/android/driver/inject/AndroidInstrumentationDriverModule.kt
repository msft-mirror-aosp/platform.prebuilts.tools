/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.driver.inject

import com.google.testing.platform.api.config.Config
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.androidSdk
import com.google.testing.platform.api.config.environment
import com.google.testing.platform.api.config.parseConfig
import com.google.testing.platform.api.driver.TestDriverConfigImpl
import com.google.testing.platform.lib.adb.command.inject.AdbConfig
import com.google.testing.platform.lib.adb.command.inject.AdbShellOutputParserModule
import com.google.testing.platform.lib.adb.command.inject.LogWriterModule
import com.google.testing.platform.lib.adb.command.parser.InstrumentationListParser
import com.google.testing.platform.lib.adb.command.timing.TestTimeTracker
import com.google.testing.platform.proto.api.config.AndroidInstrumentationDriverProto.AndroidInstrumentationDriver
import com.google.testing.platform.proto.api.config.RuntimeProto.AndroidInstrumentationRuntime
import com.google.testing.platform.runtime.android.driver.lib.ListInstrumentationsCommand
import com.google.testing.platform.runtime.android.driver.lib.TestRunnerArgs
import dagger.Module
import dagger.Provides
import java.nio.file.Path
import javax.inject.Named
import kotlin.io.path.Path

/** Dagger module for AndroidInstrumentationDriver. */
@Module(includes = [AdbShellOutputParserModule::class, LogWriterModule::class])
class AndroidInstrumentationDriverModule {
  @Provides fun environment(config: Config): Environment = config.environment

  @Provides
  fun testDriverConfigImpl(config: Config): TestDriverConfigImpl = config as TestDriverConfigImpl

  @Provides
  fun androidInstrumentationRuntime(config: TestDriverConfigImpl): AndroidInstrumentationRuntime =
    config.parseConfig<AndroidInstrumentationDriver>()!!.androidInstrumentationRuntime

  @Provides
  fun instrumentationArgs(
    androidInstrumentationRuntime: AndroidInstrumentationRuntime,
    environment: Environment,
  ) =
    with(androidInstrumentationRuntime.instrumentationArgs) {
      TestRunnerArgs(
        enableCoverage = environment.enableCoverage,
        enableDebugging = enableDebug,
        noWindowAnimation = noWindowAnimation,
        useTestStorageService = useTestStorageService,
        args = argsMapMap,
      )
    }

  @Provides
  fun adbConfig(config: Config): AdbConfig =
    AdbConfig(
      adbPath = config.androidSdk.adbPath,
      outputDirectory = config.environment.outputDirectory,
    )

  @Provides
  fun listInstrumentationCommand(
    instrumentationListParser: InstrumentationListParser,
    androidInstrumentationRuntime: AndroidInstrumentationRuntime,
  ): ListInstrumentationsCommand =
    ListInstrumentationsCommand(instrumentationListParser, androidInstrumentationRuntime)

  @Provides fun testTimeTracker(): TestTimeTracker = TestTimeTracker()

  @Provides
  @Named("InstrumentationLog")
  fun instrumentationLogPath(config: Config): Path =
    with(config.environment) { Path(testLogDirectory).resolve(testRunLog) }
}
