/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.adb.command.inject

/** Adb-related configuration values, including global options to pass to the adb command. */
data class AdbConfig(
  /** Output directory where to log adb command stdout output. */
  val outputDirectory: String = ".",

  /** Full path to the adb binary to use. */
  val adbPath: String = "adb",

  /** Name of the adb server host (default=localhost). Passed to the -H global option. */
  val adbServerHost: String? = null,

  /** Port of adb server (default=5037 as hardcoded in adb). Passed to the -P global option. */
  val adbServerPort: Int? = null,

  /**
   * Port number to reach the adb daemon (default=5555 is hardcoded in adb). For information on the
   * port numbers used by ADB, see: https://developer.android.com/studio/command-line/adb
   */
  val adbPort: Int? = null,

  /**
   * Port number for the emulator console (default=5554 is hardcoded in adb). For information on the
   * port numbers used by ADB, see: https://developer.android.com/studio/command-line/adb
   */
  val consolePort: Int? = null,

  /**
   * Use the device with the given deviceSerial (overrides the $ANDROID_SERIAL environment
   * variable). Passed to the -s global option.
   *
   * Note: the deviceSerial is optional for some adb commands like "adb devices" and "adb connect"
   * that don't target a specific device.
   */
  val deviceSerial: String? = null,
) {

  init {
    require(outputDirectory.isNotEmpty()) { "adb output directory cannot be empty" }
    require(adbPath.isNotEmpty()) { "adb path cannot be empty" }
  }
}
