/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.driver

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.device.Device
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase

/** Coordinates multidevice tests. */
@ThreadSafe
interface TestCoordinator {
  /** Callbacks into the TestDriver. */
  interface Runner {
    /**
     * All runners are called if the primary test case fails; the auxiliary's runner will be called
     * if the auxiliary fails.
     */
    suspend fun fail(throwable: Throwable)

    /**
     * All devices are now ready to run tests. Called on the primary TestCoordinator before the
     * first call to run().
     *
     * @param devices All devices.
     */
    suspend fun devicesReady(devices: List<Device>) = Unit

    /**
     * Run a single test case.
     *
     * @param testCase The case to run, or null if there is no test case to be run and the test
     *   driver should simply run beforeEach and afterEach.
     * @param primary The primary test case being run.
     */
    suspend fun run(testCase: TestCase?, primary: TestCase)
  }

  /**
   * Coordinates a list of test cases. May throw an exception if there are test cases on an
   * auxiliary device that do not match the primary device.
   */
  suspend fun coordinate(device: Device, testCases: List<TestCase>, runner: Runner)
}
