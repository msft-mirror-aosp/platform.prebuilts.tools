/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource

/**
 * Base class that provides all the config to plugins / providers / controllers.
 * Any additional config for these entities should be provided by implementing this class.
 */
interface ConfigBase : Config, ProtoConfig {
  /**
   * Host-side "runtime" information, this information describes the environment in which host-side
   * code is running.
   *
   * @see [EnvironmentProto.Environment]
   */
  val environment: Environment

  /**
   * Information on what artifacts to stage on a device, how to stage them, and which artifacts to
   * retrieve from a device after testing.
   *
   * @see [SetupProto.TestSetup]
   */
  val setup: Setup

  /**
   * Information about host-side android executables.
   *
   * TODO(b/138943944)
   *
   * @see [AndroidSdkProto.AndroidSdk]
   */
  val androidSdk: AndroidSdk
}

/**
 * [ConfigBase] factory.
 *
 * @param environmentProto proto to build [Environment] data class.
 * @param testSetupProto proto to build [Setup] data class.
 * @param androidSdkProto proto to build [AndroidSdk] data class.
 */
@Suppress("FunctionName")
fun ConfigBase(
  environmentProto: EnvironmentProto.Environment,
  testSetupProto: SetupProto.TestSetup,
  androidSdkProto: AndroidSdkProto.AndroidSdk,
  configProto: AnyProto? = null,
  configResource: ConfigResource? = null
): ConfigBase {
  return DefaultConfigBase(
    environmentProto = environmentProto,
    testSetupProto = testSetupProto,
    androidSdkProto = androidSdkProto,
    configProto = configProto,
    configResource = configResource
  )
}
