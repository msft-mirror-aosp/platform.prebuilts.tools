/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.testing.platform.api.context.Context

/**
 * Any plugin / provider / controllers will have to implement this interface in order to get
 * 'configuration' such as RunnerConfig, Environment, CustomConfig from Unified Test Platform.
 *
 * The configure method will be called first after creating these objects.
 */
interface Configurable {
  /**
   *
   * Called to 'inject' configuration into the entity which implements this interface.
   *
   * @param context A context object containing general information to be used to configure this
   * [Configurable].
   */
  fun configure(context: Context) = Unit
}
