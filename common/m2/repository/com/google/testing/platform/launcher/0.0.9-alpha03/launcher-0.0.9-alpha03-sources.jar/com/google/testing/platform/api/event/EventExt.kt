/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.event

import com.google.protobuf.Message
import com.google.protobuf.Parser

/**
 * Send a message to the event graph.
 *
 * ```
 * fun configure(context: Context) {
 *   context.events.send(myEvent { this.message = "hello!" })
 *   ...
 * }
 * ```
 */
fun <T : Message> Events.send(message: T) {
  send(message::class.java.name, message.toByteArray())
}

/**
 * Retrieve messages from the event graph.
 * ```
 * fun configure(context: Context) {
 *    val myEvents = context.events.get<SomeProto.MyEvent>()
 *    ...
 * }
 * ```
 */
inline fun <reified T : Message> Events.get(): List<T> {
  val messages = get(T::class.java.name)
  @Suppress("UNCHECKED_CAST")
  val parser = T::class.java.getMethod("parser").invoke(null) as Parser<T>
  return messages.map { parser.parseFrom(it) as T }
}

/** Send an enum value to the event graph */
fun <T : Enum<T>> Events.sendEnum(value: T) =
  // Charsets.UTF_8 is the default. Explicitly stated for clarity between getEnum/sendEnum
  send(value::class.java.name, value.name.toByteArray(Charsets.UTF_8))

/** Retrieve enum values from the event graph */
inline fun <reified T : Enum<T>> Events.getEnum(): List<T> =
  get(T::class.java.name).map {
    T::class
      .java
      .getMethod("valueOf", String::class.java)
      .invoke(null, String(it, Charsets.UTF_8)) as T
  }
