/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.core

/** Scope for recording diagnostic events. */
interface DiagnosticScope {

  /**
   * Records events with a name and custom attributes.
   *
   * @param name Name of the event
   * @param details Map of custom attributes to add to this event
   */
  fun recordEvent(name: String, details: Map<String, Detail<out Any>>? = null)

  fun <T> recordEvent(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: DiagnosticScope.() -> T
  ): EventRecord<T>

  suspend fun <T> recordEventAsync(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: suspend DiagnosticScope.() -> T
  ): EventRecord<T>

  /** Stops all active work and ends this [DiagnosticScope]. */
  fun finish(): Unit
}
