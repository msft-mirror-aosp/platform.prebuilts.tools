/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource
import com.google.testing.platform.proto.api.core.ExtensionProto.Extension

/**
 * [Config] that contains a proto for configuring an [Extension]. Read the documentation on the
 * [Extension] proto for more details on how these different configurations are used. To parse a
 * config for your extension, do not use this class directly. Instead, use the extension functions
 * for [Config] provided in this package.
 *
 * Only one of [configProto] or [configResource] should be set at a time.
 */
interface ProtoConfig : Config {
  /**
   * Proto containing the configuration for this [Extension].
   */
  val configProto: AnyProto?

  /** Information for parsing an [Extension] configuration from a source other than an [AnyProto]. */
  val configResource: ConfigResource?
}
