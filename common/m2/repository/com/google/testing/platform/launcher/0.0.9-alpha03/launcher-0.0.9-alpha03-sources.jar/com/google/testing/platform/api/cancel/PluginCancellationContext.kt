package com.google.testing.platform.api.cancel

import com.google.testing.platform.core.error.UtpException

/**
 * Interface for plugins to request cancellation of a running test.
 *
 * Plugins running asynchronously in the background can use the [cancel] method to report an error
 * and stop the ongoing test.
 */
interface PluginCancellationContext {

  /** Check whether cancellation has already been triggered. */
  fun isCancelling(): Boolean

  /** Check if UTP is aborting, in which case cleanup needs to be as fast as possible. */
  fun isAborting(): Boolean = false

  /**
   * Request UTP core to initiate cancellation of a running test by supplying a [cancelReason].
   *
   * This will result in the final [TestStatus] being `ERROR` in the UTP [TestSuiteResult].
   */
  fun cancel(cancelReason: UtpException)
}
