/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.core.ErrorDetailProto.ErrorDetail
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult

/**
 * Interface for accumulating test results from at least one [TestDriver]. Each TestDriver is
 * presumed to have a different [DeviceId]. It is expected to have a close connection to a
 * [TestResultListener], to which events will be flushed when ready.
 *
 * If a proto contains an empty DeviceId, UUID(0,0) will be used to identify it internally.
 *
 * Important usage notes:
 * 1. Call beforeTestSuite() first, so the publisher knows about the device.
 * 2. Call beforeTest() before a test and afterTest() after a test.
 * 3. Call afterTestSuite() when done.
 *
 * You can call the other functions at any time; errors and exceptions will be accumulated and will
 * be part of the calculation of the final test suite status, which can be overridden by
 * setTestSuiteStatus().
 */
@ThreadSafe
interface TestResultPublisher {

  /**
   * Called when the test suite has started running.
   *
   * @param testSuiteMetaData [TestSuiteMetaData] about the test suite to be executed.
   */
  fun beforeTestSuite(testSuite: TestSuiteMetaData)

  /**
   * Called before each test starts running.
   *
   * @param testCase [TestCase] about to be executed
   */
  fun beforeTest(testCase: TestCase)

  /**
   * Process the [TestResult] received. If the [TestCase] matches an existing TestResult, that
   * TestResult will be updated instead, and no message will be sent to the underlying
   * [TestResultListener].
   *
   * @param testResult the [TestResult] that just finished executing
   */
  fun afterTest(testResult: TestResult)

  /**
   * Adds the [Artifact] to the outputs of the test suite.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   */
  fun addTestSuiteArtifact(testSuite: TestSuiteMetaData, artifact: Artifact)

  /**
   * Registers the [Issue] with the specified test suite.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   * @param issue: the issue to apply.
   */
  fun addTestSuiteIssue(testSuite: TestSuiteMetaData, issue: Issue)

  /**
   * Registers the [ErrorDetail] with the PlatformError of the specified test suite. The presence of
   * a PlatformError will cause the calculated test status to be FAILURE.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   */
  fun failTestSuite(testSuite: TestSuiteMetaData, detail: ErrorDetail)

  /**
   * Called if an exception has terminated a test suite early. This will show up in the
   * PlatformError. The presence of a PlatformError will cause the calculated test status to be
   * FAILURE.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   * @param throwable: the exception that terminated the test suite
   */
  fun failTestSuite(testSuite: TestSuiteMetaData, throwable: Throwable)

  /**
   * Clears the PlatformError from the TestSuiteResult.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   */
  fun clearFailures(testSuite: TestSuiteMetaData)

  /**
   * Sets the status of the test suite, overriding any dynamic calculations based on the accumulated
   * [TestResult]s.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   * @param status: status to set on the TestSuiteResult.
   */
  fun setTestSuiteStatus(testSuite: TestSuiteMetaData, status: TestStatus)

  /**
   * Obtains a draft copy of the TestSuiteResult for the specified suite.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   */
  fun workingDraft(testSuite: TestSuiteMetaData): TestSuiteResult

  /**
   * Called after a test suite is completed.
   *
   * @param testSuite: TestSuiteMetaData containing the device ID of the test suite
   */
  fun afterTestSuite(testSuite: TestSuiteMetaData) = Unit

  /**
   * Called when all test suites have finished executing. This will call afterTestSuite() on each
   * TestResultListener for each test suite, then call afterAllTestSuites() on each
   * TestResultListener.
   *
   * There should be no more interactions with the [TestResultPublisher] after this method is
   * called.
   *
   * @return The published test suites.
   */
  fun publish(): List<TestSuiteResult>
}
