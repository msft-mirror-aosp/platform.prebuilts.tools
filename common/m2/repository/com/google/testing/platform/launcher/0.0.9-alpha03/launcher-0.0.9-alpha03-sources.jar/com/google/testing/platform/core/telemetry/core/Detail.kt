/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.core

/**
 * Data class that holds [Detail]s for a diagnostics event.
 */
data class Detail<T : Any>(

  /** The value of the [Detail] */
  val value: T
) {

  init {
    check(SUPPORTED_TYPES.contains(value::class.java)) {
      """Unsupported value type '${value::class.java.name}'.
        |Only ${SUPPORTED_TYPES.joinToString(", ")} are supported.""".trimMargin()
    }
  }

  private companion object {
    private val SUPPORTED_TYPES = setOf(
      String::class.java,
      Long::class.java,
      Int::class.java,
      Boolean::class.java,
      java.lang.Long::class.java,
      java.lang.Integer::class.java,
      java.lang.Boolean::class.java
    )
  }
}
