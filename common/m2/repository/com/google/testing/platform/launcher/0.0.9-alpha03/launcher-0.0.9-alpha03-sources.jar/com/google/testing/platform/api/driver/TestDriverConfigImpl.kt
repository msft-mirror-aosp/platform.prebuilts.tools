/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.driver

import com.google.protobuf.Any
import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.config.ConfigBase
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.Setup
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.config.ShardingConfigProto.ShardingConfig
import com.google.testing.platform.proto.api.config.TestDiscoveryProto.TestDiscovery
import com.google.testing.platform.proto.api.core.ExtensionProto

/**
 * Provides configuration values to a [TestDriver]. Includes base config and device controller
 * specific config.
 *
 * @param configBaseDelegate the extension base configuration.
 * @param testDiscovery test discovery proto.
 * @param shardingConfig sharding config proto.
 * @param deviceId identifier of the Device associated with this TestDriver.
 */
class TestDriverConfigImpl(
  configBaseDelegate: ConfigBase,
  val testDiscovery: TestDiscovery,
  val shardingConfig: ShardingConfig,
  val deviceId: DeviceId,
  val portPicker: PortPicker? = null
) : ConfigBase by configBaseDelegate {
  companion object {
    /**
     * Factory method to create [TestDriverConfigImpl] from the supplied proto values.
     *
     * @param environmentProto proto to build [Environment] data class.
     * @param testSetupProto proto to build [Setup] data class.
     * @param androidSdkProto proto to build [AndroidSdk] data class.
     * @param testDiscovery test discovery proto.
     * @param shardingConfig sharding config proto.
     * @param deviceId identifier of this particular device.
     * @param configProto The device controller config.
     */
    fun parseFrom(
      environmentProto: EnvironmentProto.Environment,
      testSetupProto: SetupProto.TestSetup,
      androidSdkProto: AndroidSdkProto.AndroidSdk,
      testDiscovery: TestDiscovery,
      shardingConfig: ShardingConfig,
      deviceId: DeviceId = DeviceId.getDefaultInstance(),
      configProto: Any? = null,
      configResource: ExtensionProto.ConfigResource? = null,
      portPicker: PortPicker? = null
    ): TestDriverConfigImpl {
      val configBase =
        ConfigBase(environmentProto, testSetupProto, androidSdkProto, configProto, configResource)
      return TestDriverConfigImpl(
        configBaseDelegate = configBase,
        testDiscovery = testDiscovery,
        shardingConfig = shardingConfig,
        deviceId = deviceId,
        portPicker = portPicker,
      )
    }
  }
}
