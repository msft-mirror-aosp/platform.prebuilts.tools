/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.testing.platform.config.v1.extension.aaptPathOrDefault
import com.google.testing.platform.config.v1.extension.adbPathOrDefault
import com.google.testing.platform.config.v1.extension.dexDumpPathOrDefault
import com.google.testing.platform.config.v1.extension.sdkPathOrDefault
import com.google.testing.platform.proto.api.config.AndroidSdkProto

const val DEFAULT_SDK_PATH = "/Android/Sdk"
/**
 * Get android Sdk values from [AndroidSdkProto]
 */
data class AndroidSdk(

  /**
   * Absolute path to the Android Sdk.
   * Optional if all the specific SDK asset paths below are set.
   */
  val sdkPath: String,

  /** Absolute path to the aapt binary. */
  val aaptPath: String,

  /** Absolute path to the adb binary. */
  val adbPath: String,

  /** Absolute path to the dexdump binary. */
  val dexdumpPath: String
) {
  object Creator {
    fun parseFrom(androidSdk: AndroidSdkProto.AndroidSdk): AndroidSdk {
      // TODO(b/123368812): Need a separate class to handle heuristics of finding AndroidSdk path.
      val defaultSdkPath: String = System.getenv("ANDROID_SDK_HOME") ?: DEFAULT_SDK_PATH

      val defaultAaptPath = "$defaultSdkPath/aapt"
      val defaultDexDumpPath = "$defaultSdkPath/dexdump"
      val defaultAdbPath = "$defaultSdkPath/adb"

      return AndroidSdk(
        sdkPath = androidSdk.sdkPathOrDefault(defaultSdkPath),
        aaptPath = androidSdk.aaptPathOrDefault(defaultAaptPath),
        adbPath = androidSdk.adbPathOrDefault(defaultAdbPath),
        dexdumpPath = androidSdk.dexDumpPathOrDefault(defaultDexDumpPath)
      )
    }
  }
}
