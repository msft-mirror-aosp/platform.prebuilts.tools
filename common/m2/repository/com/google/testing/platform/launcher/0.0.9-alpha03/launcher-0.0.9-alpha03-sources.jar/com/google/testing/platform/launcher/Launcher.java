/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.launcher;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkState;

import com.google.common.base.Splitter;
import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.LogManager;
import java.util.logging.Logger;

/**
 * Launcher for the UTP (UTP) test runner.
 *
 * <p>The UTP launcher establishes a strict class loader hierarchy that allow UTP to dynamically
 * load extensions such as plugins, device controllers and providers and result listeners from their
 * own Jars, sharing definitions of the UTP base Jars (public Api) through its parent classloader.
 *
 * <p>To launch UTP you have to execute the UTP binary (Jar) with a path to UTPs core deploy Jar and
 * additionally provide UTP's base Jars on the runtime class path: {@code java -classpath <UTP base
 * Jars> com.google.testing.platform.launcher.Launcher <UTP core Jars>}
 *
 * <p>Class loader hierarchy overview:
 *
 * <ul>
 *   <li>The core class loader contains all the UTPs internal implementation and is bootstrapped
 *       from the runners core Jar that has to be provided to the launcher as an argument.
 *   <li>UTPs base Jars contains all of UTPs public Api Jars and are not part of the core. Base Jars
 *       have to be provided on the runtime (system) class path, e.g. {@code java -classpath <UTP
 *       base Jars>}. Both core and plugins Jars are required to load public Api classes from the
 *       system class loader and cannot have their own definitions inside their own Jars!
 *   <li>Plugins will be loaded in an isolated class loader which gets the system class loader as a
 *       parent to have access to the public Apis. Plugins may bring their own definitions for other
 *       classes, but cannot contain any public Api as part of their own binaries.
 * </ul>
 *
 * <pre>
 *                                      +-----------------+
 *                                      |                 |
 *                                      |       Boot      |
 *                                      |                 |
 *                                      +-----------------+
 *                                               ^
 *                                               |
 *                               java -classpath <UTP base Jars>
 *                                               |
 *                                      +-----------------+
 *                                      |                 |
 *                                      |     UTP Base    |
 *                                      |  - Config Apis  |
 *                                      |  - Plugin Apis  |
 *                                      |  - Device Apis  |
 *                                      |                 |
 *                                      +-----------------+
 *                                               ^
 *                                               |
 *                      +------------------------|------------------------+
 *                      |                        |                        |
 *                      |                        |                        |
 *             +-----------------+      +-----------------+      +-----------------+
 *             |                 |      |                 |      |                 |
 *             |    UTP Core     |      |    Plugin Foo   |      | Result Listener |
 *             |  - Classes      |      |  - Classes      |      |  - Classes      |
 *             |  - Deps         |      |  - Deps         |      |  - Deps         |
 *             |                 |      |                 |      |                 |
 *             +-----------------+      +-----------------+      +-----------------+
 * </pre>
 */
public final class Launcher {
  static {
    // Must be called before any Logger method is used.
    // Extend the default LogManager to not run reset when JVM shutdown hooks start executing.
    // LogManager#reset is triggered when the JVM is shutting down which resets all the loggers
    // causing them to stop logging.
    System.setProperty("java.util.logging.manager", UtpLogManager.class.getName());
  }

  private static final Logger logger = Logger.getLogger(Launcher.class.getSimpleName());

  private static final String RUNNER_MAIN_CLASS = "com.google.testing.platform.main.MainKt";
  private static final String RUNNER_MAIN_METHOD = "main";

  private Launcher() {
    // no-instance
  }

  /**
   * Launches the UTP test runner from the provided UTP core binary.
   *
   * @param args to launch UTP the first item in the array at position 0 must contain the absolute
   *     path to the UTP core Jar
   * @throws IllegalArgumentException if core Jar is not provided through the args
   * @throws IllegalStateException if the core Jar path does not exist
   */
  public static void main(String[] args) throws Exception {
    // Thread-aware console logs are harder to read. Only display them on request.
    if (System.getenv("UTP_THREAD_AWARE_CONSOLE_HANDLER") != null) {
      ThreadAwareConsoleHandler.swapConsoleHandlers();
    }

    checkArgument(
        args.length > 0,
        "Missing path to UnifiedTestPlatform core Jar. Please run:"
            + "'java -classpath <UTP base Jars> com.google.testing.platform.launcher.Launcher "
            + "<UTP core Jars>");

    String coreJarPath = args[0];
    checkArgument(
        coreJarPath != null && !coreJarPath.isEmpty(),
        "UnifiedTestPlatform core jar arg cannot be null or empty!");

    logger.fine("Launching UnifiedTestPlatform runner from Jar: " + coreJarPath);

    // The runner core jars, that contain all of the runner core implementations.
    ArrayList<URL> coreJarUrls = new ArrayList<>();
    for (String jarPath : Splitter.on(File.pathSeparatorChar).split(coreJarPath)) {
      File runnerCoreJar = new File(jarPath);
      checkState(
          runnerCoreJar.exists(),
          "UnifiedTestPlatform core Jar path: %s does not exist!",
          coreJarPath);

      coreJarUrls.add(runnerCoreJar.toURI().toURL());
    }

    // Main args to pass along to the runners main function.
    String[] mainArgs = Arrays.copyOfRange(args, 1 /* Remove base Jar path */, args.length);

    // Core runner and plugins will have to use all the classes we define in our Jar, but may bring
    // in their own definitions for other classes.
    ClassLoader coreClassloader =
        new URLClassLoader(coreJarUrls.toArray(URL[]::new), Launcher.class.getClassLoader());

    try {
      Class<?> mainClass = Class.forName(RUNNER_MAIN_CLASS, true, coreClassloader);
      Method mainMethod = mainClass.getMethod(RUNNER_MAIN_METHOD, String[].class);
      mainMethod.invoke(
          null /* static method */, new Object[] {mainArgs} /* Prevent varargs spread */);
    } catch (Throwable throwable) {
      throw new RuntimeException(
          "UnifiedTestPlatform encountered an error in: " + RUNNER_MAIN_CLASS, throwable);
    }
  }

  /** Custom Log manager that overrides the reset method to do nothing. */
  public static class UtpLogManager extends LogManager {
    static UtpLogManager manager;

    public UtpLogManager() {
      manager = this;
    }

    @Override
    public void reset() {
      // No-op.
      // This resets all registered loggers within a JVM shutdown hook. Triggering reset will
      // cause them to stop logging. Since shutdown hooks now run explicit cleanup operations,
      // avoid resetting any static logger within the log manager.
      //
      // Shutdown hooks do not guarantee any order of execution, so avoid running reset altogether.
      // Investigate if we can trigger a super.reset() from within the main.
    }
  }
}
