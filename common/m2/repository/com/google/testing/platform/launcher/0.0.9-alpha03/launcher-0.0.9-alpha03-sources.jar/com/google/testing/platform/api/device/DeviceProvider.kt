/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.device

import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.config.Configurable

/**
 * Provides the test runner with a [DeviceController] to execute the tests on.
 *
 * Scenarios to account for when implementing this interface:
 *   *  If [provideDevice] is a long running operation, implementors should [cancel] that operation
 *      if the UTP execution needs to be interrupted.
 *   *  If a device is already allocated, [releaseDevice] should be sufficient.
 */
interface DeviceProvider<T : DeviceController> : Configurable, Cancellable {
  /**
   * Provides the test runner with a [DeviceController] to execute the tests.
   */
  fun provideDevice(): T

  /**
   * Release the previously provided [DeviceController].
   */
  fun releaseDevice()
}
