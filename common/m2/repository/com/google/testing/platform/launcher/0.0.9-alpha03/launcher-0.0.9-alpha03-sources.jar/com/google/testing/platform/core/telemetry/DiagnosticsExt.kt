package com.google.testing.platform.core.telemetry

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.core.telemetry.core.Diagnostics

/**
 * Measure and record information about a given code block.
 *
 * Example usage:
 * ```
 * diagnostics.record("helloWorldEvent") {
 *   run {
 *     println("Hello World")
 *     return@run Unit
 *   }
 * }.getOrThrow()
 * ```
 *
 * @param name A logical name around the block to be executed for later reference.
 * @param init A lambda containing more information about the record, including a <code>run
 *   {}</code> block containing the code to measure.
 * @return An [EventRecord] around the executed code.
 * @throws IllegalStateException if no code block was specified to measure.
 */
@CanIgnoreReturnValue
fun <T> Diagnostics.record(name: String, init: SequentialEventRecordRequest<T>.() -> Unit) =
  SequentialEventRecordRequest<T>(name, this).apply(init).record()

/**
 * Measure and record information about a given code block.
 *
 * Example usage:
 * ```
 * diagnostics.recordAsync("helloWorldEvent") {
 *   runAsync {
 *     someSuspendFunction()
 *   }
 * }.getOrThrow()
 * ```
 *
 * @param name A logical name around the block to be executed for later reference.
 * @param init A lambda containing more information about the record, including a <code>runAsync
 *   {}</code> block containing the code to measure.
 * @return An [EventRecord] around the executed code.
 * @throws IllegalStateException if no code block was specified to measure.
 */
@CanIgnoreReturnValue
suspend fun <T> Diagnostics.recordAsync(name: String, init: AsyncEventRecordRequest<T>.() -> Unit) =
  AsyncEventRecordRequest<T>(name, this).apply(init).recordAsync()
