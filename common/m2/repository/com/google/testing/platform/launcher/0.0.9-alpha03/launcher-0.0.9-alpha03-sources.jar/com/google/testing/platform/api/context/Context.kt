/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.context

import com.google.errorprone.annotations.ThreadSafe

/** Context class with information to be passed along in the UTP ecosystem */
@ThreadSafe
interface Context {

  companion object {
    const val CANCEL_KEY = "cancel"
    const val CLEANUP_JOB_KEY = "cleanup_job"
    const val CONFIG_KEY = "config"
    const val COORDINATOR_KEY = "coordinator"
    const val COROUTINE_CONTEXT_KEY = "coroutine_context"
    const val DEVICE_PREFIX_KEY = "device_prefix"
    const val DIAGNOSTICS_KEY = "diagnostics"
    const val EVENTS_KEY = "events"
    const val PORTPICKER_KEY = "portpicker"
  }

  /**
   * Given a property key, return the corresponding property value, if it exists.
   *
   * @param key The property key
   * @return The property value associated with this key, or null if no value exists
   */
  operator fun get(key: String): Any?
}
