/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.runtime.android.device

import com.google.testing.platform.api.device.Device
import com.google.testing.platform.api.device.Device.DeviceType
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId

/**
 * Data class that holds properties of an Android device provisioned by an [AndroidDeviceProvider].
 *
 * @see <a href="https://developer.android.com/studio/command-line/adb">Android Debug Bridge (adb)
 *   </a>
 */
data class AndroidDevice(
  /**
   * The host machine the device or emulator is running on. Typically it's localhost, but it could
   * also be a remote host.
   *
   * @return the host name or IP address
   */
  val host: String = LOCALHOST,

  /**
   * The serial number string created by adb to uniquely identify the device by its port number.
   *
   * All connections to adb should reference this serial number, because the adb server may be
   * hosting multiple devices.
   *
   * Treat this value as opaque: do not assume that if it doesn't start with emulator-555X that
   * you're not talking to an emulated device.
   *
   * @return the serial number of the device
   */
  override val serial: String,

  /**
   * The type of device, e.g. physical, virtual or simulated.
   *
   * @return the type of this device
   */
  override val type: DeviceType,

  /**
   * The adb port of the device. This is usually an odd-numbered port starting from 5555. Note: Can
   * be {@code null} for locally connected physical devices, as only serial is required to connect.
   *
   * @return the adb port of the device
   */
  override val port: Int? = null,

  /**
   * The environment variables set on the android device. This is obtained by running {@code adb
   * shell printenv}.
   */
  override var properties: AndroidDeviceProperties,

  /**
   * The emulator console port of the device. This is usually an even-numbered port starting
   * from 5554.
   *
   * @return the emulator console port of this device
   */
  val emulatorPort: Int? = null,

  /**
   * The port the adb server is listening on. This is usually port 5037.
   *
   * @return the port of the device
   */
  val serverPort: Int? = null,
  override val id: DeviceId = DeviceId.getDefaultInstance(),
) : Device {
  private companion object {
    const val LOCALHOST = "localhost"
  }

  init {
    require(host.isNotEmpty()) { "host name cannot be empty" }
    require(serial.isNotEmpty()) { "serial cannot be empty" }
    require(port == null || port in 1..65535) {
      "Invalid adb port: $port. Must be in range 1..65535"
    }
    require(serverPort == null || serverPort in 1..65535) {
      "Invalid server port: $serverPort. Must be in range 1..65535"
    }
    require(emulatorPort == null || emulatorPort in 1..65535) {
      "Invalid emulator console port: $emulatorPort. Must be in range 1..65535"
    }
  }
}
