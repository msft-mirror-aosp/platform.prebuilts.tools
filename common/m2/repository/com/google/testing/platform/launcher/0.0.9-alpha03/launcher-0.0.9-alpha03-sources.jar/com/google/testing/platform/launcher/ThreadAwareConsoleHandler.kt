/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.launcher

import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.logging.ConsoleHandler
import java.util.logging.Formatter
import java.util.logging.Level
import java.util.logging.LogManager
import java.util.logging.LogRecord
import java.util.logging.StreamHandler

/** A data class augmenting LogRecord with the name of the thread. */
class LogRecordWithThreadName(record: LogRecord, val threadName: String) :
  LogRecord(record.level, record.message) {
  init {
    setInstant(record.instant)
    setLoggerName(record.loggerName)
    setParameters(record.parameters)
    setResourceBundle(record.resourceBundle)
    setResourceBundleName(record.resourceBundleName)
    setSequenceNumber(record.sequenceNumber)
    setSourceClassName(record.sourceClassName)
    setSourceMethodName(record.sourceMethodName)
    setThreadID(record.threadID)
    setThrown(record.thrown)
  }
}

/**
 * Cribbing from the standard implementation of ConsoleHandler to put in a custom StreamHandler that
 * will emit thread IDs and names, to make it easier for humans to debug problems.
 */
class ThreadAwareConsoleHandler(private val original: StreamHandler) :
  StreamHandler(System.err, LogFormatter()) {
  companion object {
    /**
     * Replace the usual ConsoleHandler with a ThreadAwareConsoleHandler. If there is no
     * ConsoleHandler, someone has overridden the default configuration, so don't mess with them.
     */
    @JvmStatic
    fun swapConsoleHandlers() {
      // The root logger is named "", which is *not* Logger.GLOBAL_LOGGER_NAME?!?
      val rootLogger = LogManager.getLogManager().getLogger("")
      for (handler in rootLogger.handlers) {
        if (handler !is ConsoleHandler) continue
        rootLogger.addHandler(ThreadAwareConsoleHandler(handler))
        rootLogger.removeHandler(handler)
        break
      }
    }
  }

  override fun isLoggable(record: LogRecord?) =
    original.isLoggable(record) || super.isLoggable(record)

  override fun publish(record: LogRecord?) {
    record?.let { super.publish(it) }
    flush()
  }

  override fun close() {
    flush() // do not close System.err!
  }
}

/**
 * Emits the primary log with thread ID and name, to make multithreaded problems easier to debug.
 */
private class LogFormatter() : Formatter() {
  private companion object {
    val dateTimeFormatter = SimpleDateFormat("yyMMdd HH:mm:ss.SSS", Locale.ROOT)
    val LEVEL_CODES =
      mapOf(
        Level.FINEST to 'D',
        Level.FINER to 'D',
        Level.FINE to 'D',
        Level.CONFIG to 'I',
        Level.INFO to 'I',
        Level.WARNING to 'W',
        Level.SEVERE to 'X',
      )
    // Thread names are a hassle to look up, so cache them.
    val threadNames = mutableMapOf<Long, String>()

    // https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
    val HIGHLIGHT_CODES =
      mapOf(
        Level.WARNING to "\u001b[33m", // yellow
        Level.SEVERE to "\u001b[31m", // red
      )
    const val END_HIGHLIGHT = "\u001b[39m" // reset
  }

  val highlighting = System.getenv("UTP_HIGHLIGHT_LOGS")?.isNotEmpty() ?: false

  override fun format(record: LogRecord): String {
    val result = buildString {
      append(dateTimeFormatter.format(record.millis))
      append(':')
      append(LEVEL_CODES.getOrDefault(record.level, 'X'))
      if (record.thrown != null) append('T')
      append(' ')
      append(record.threadID)
      append(" [").append(getThreadName(record)).append(']')
      // If we ever start using Flogger, we can extract the line number here.
      append(" [")
      // Suppress <unknown class> (from Flogger's LogSite.INVALID) so the logger will emit the
      // loggerName instead.
      if (record.sourceClassName != null && record.sourceClassName != "<unknown class>") {
        append(record.sourceClassName)
        if (record.sourceMethodName != null) {
          append('.')
          append(record.sourceMethodName)
        }
      } else {
        append(record.loggerName)
      }
      append("] ")
      if (highlighting) HIGHLIGHT_CODES.get(record.level)?.let { append(it) }
      append(formatMessage(record))
      if (highlighting && HIGHLIGHT_CODES.contains(record.level)) append(END_HIGHLIGHT)
      append('\n')

      if (record.thrown != null) append(record.thrown?.stackTraceAsPrinted() ?: "")
    }

    return result
  }

  /** Emits a stack trace with proper indentation. */
  private fun Throwable.stackTraceAsPrinted(): String {
    val sw = StringWriter()
    val pw = PrintWriter(sw)
    pw.println()
    printStackTrace(pw)
    pw.close()
    return sw.toString()
  }

  /** Gets the name for a thread, or simply writes the thread ID. */
  private fun getThreadName(record: LogRecord): String =
    if (record is LogRecordWithThreadName) {
      record.threadName
    } else {
      threadNames.getOrPut(record.threadID.toLong()) {
        getThread(record.threadID.toLong())?.name ?: "${record.threadID}"
      }
    }

  /** Looks up a thread by ID. */
  private fun getThread(threadID: Long): Thread? {
    val root = getRootThreadGroup()
    val allThreads = Array<Thread?>(root?.activeCount() ?: 0) { null }
    root?.enumerate(allThreads)
    return allThreads.find { it?.id == threadID }
  }

  /** Looks up the root thread group. */
  private fun getRootThreadGroup(): ThreadGroup? {
    var group = Thread.currentThread().threadGroup
    while (group?.parent != null) {
      group = group.parent
    }
    return group
  }
}
