/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult

/** Interface for consuming UTP outputs and generating results. */
@ThreadSafe
interface TestResultListener : Configurable {

  /**
   * Called before the test suite starts running.
   *
   * @param testSuiteMetaData optional [TestSuiteMetaData] about the test suite to be executed.
   */
  fun beforeTestSuite(testSuiteMetaData: TestSuiteMetaData?)

  /**
   * Called before each test starts running.
   *
   * @param testCase optional [TestCase] about to be executed.
   */
  fun beforeTest(testCase: TestCase?)

  /**
   * Process the [TestResult] received.
   *
   * This is a *preliminary* result. The value passed in afterTestSuite() is final.
   *
   * @param testResult the [TestResult] that just finished executing.
   */
  fun afterTest(testResult: TestResult)

  /**
   * Called when the test suite has finished running.
   *
   * This is the final output for a given test suite, and the [TestResult]s within are the canonical
   * result to present to the user.
   *
   * @param testSuiteResult the [TestSuiteResult] consisting of all of the tests that ran
   */
  fun afterTestSuite(testSuiteResult: TestSuiteResult)

  /**
   * Called when all test suites have finished running. You need to implement this if your
   * TestResultListener is going to be used in multidevice testing.
   */
  fun afterAllTestSuites() = Unit
}
