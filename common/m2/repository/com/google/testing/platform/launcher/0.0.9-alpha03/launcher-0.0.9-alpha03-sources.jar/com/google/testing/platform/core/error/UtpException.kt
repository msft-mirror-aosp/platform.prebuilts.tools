/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.error

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.api.error.ErrorSummaryProvider

/**
 * The base class for all UTP core exceptions.
 *
 * If you are writing an extension, use the subclass appropriate to that extension (e.g.
 * [com.google.testing.platform.api.plugin.PluginException],
 * [com.google.testing.platform.core.driver.TestDriverException],
 * [com.google.testing.platform.core.device.DeviceProviderException]).)
 */
open class UtpException(
  /** The summary of the error. */
  override val errorSummary: ErrorSummary,

  /** The error message. */
  message: String? = null,

  /** The underlying cause of this exception */
  throwable: Throwable? = null
) :
  Exception(
    """
      ErrorName: ${errorSummary.errorName}
      NameSpace: ${errorSummary.namespace}
      ErrorCode: ${errorSummary.errorCode}
      ErrorType: ${errorSummary.errorType}
   """
      .trimIndent()
      .plus(message?.let { "\nMessage: $message" } ?: ""),
    throwable
  ),
  ErrorSummaryProvider {

  val errorMessage: String = message ?: ""

  fun copy(appendMsg: String) =
    UtpException(errorSummary, errorMessage + appendMsg, cause).also {
      it.setStackTrace(stackTrace)
    }
}
