/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.core.telemetry.common.noop

import com.google.testing.platform.core.telemetry.core.EventRecord

/** Noop event record, returns the result of the event without any modification */
class NoopEventRecord<T>(
  val result: T?,
  val success: Boolean,
  val exception: Throwable?
) : EventRecord<T> {

  /**
   * Returns the result of the event when the event is a success or throws the exception when the
   * block fails.
   */
  override fun getOrThrow() = if (success) result as T else throw exception!!

  /** Returns true if the block executed without exceptions */
  override fun isSuccess() = success
}
