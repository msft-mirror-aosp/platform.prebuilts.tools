package com.google.testing.platform.api.device

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.UtpException

/** Exception to throw if there is an issue with the device. */
class DeviceException(errorSummary: ErrorSummary, message: String, throwable: Throwable? = null) :
  UtpException(errorSummary, message, throwable)
