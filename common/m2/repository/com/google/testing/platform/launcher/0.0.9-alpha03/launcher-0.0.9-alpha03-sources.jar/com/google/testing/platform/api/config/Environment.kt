/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.testing.platform.config.v1.extension.coverageReportPathOrNull
import com.google.testing.platform.config.v1.extension.logcatOptionsOrDefault
import com.google.testing.platform.config.v1.extension.outputDirOrDefault
import com.google.testing.platform.config.v1.extension.runfilesDirOrDefault
import com.google.testing.platform.config.v1.extension.testLogDirOrDefault
import com.google.testing.platform.config.v1.extension.testRunLogOrDefault
import com.google.testing.platform.config.v1.extension.tmpDirOrDefault
import com.google.testing.platform.proto.api.config.EnvironmentProto
import java.io.File
import java.nio.file.Paths

/** Environment-related configuration values from the [EnvironmentProto] */
data class Environment(
  /** The directory for all test output artifacts including log files. */
  val outputDirectory: String,

  /** The directory for any temporary files needed during test execution. */
  val tempDirectory: String,

  /** The parent directory of local file dependencies for this test run. */
  val runfilesDirectory: String,

  /** The directory for any android instrumentation test log files. */
  val testLogDirectory: String,

  /** The instrumentation test run logs, relative to testLogDirectory. */
  val testRunLog: String,

  /** The path where the Jacoco code coverage report should be stored. (Only for coverage runs.) */
  val coverageReportPath: String?,

  /** Options to pass to logcat when running DeviceController.streamLogs(). */
  val androidLogcatOptions: List<String> = emptyList(),
) {

  private companion object {
    private const val DEFAULT_OUTPUT_DIRECTORY = "."
    // TODO(b/117176495): Don't hardcode OS-specifics
    private const val DEFAULT_TEMP_DIRECTORY = "/tmp"
    private const val DEFAULT_TEST_LOG_DIR = "broker_logs"
    private const val DEFAULT_INSTRUMENTATION_TEST_RUN_LOG = "test-results.log"
    private val DEFAULT_LOGCAT_OPTIONS = emptyList<String>()
  }

  object Creator {

    val default: Environment by lazy {
      Environment(
        DEFAULT_OUTPUT_DIRECTORY,
        DEFAULT_TEMP_DIRECTORY,
        Paths.get("").toAbsolutePath().toString(),
        DEFAULT_TEST_LOG_DIR,
        DEFAULT_INSTRUMENTATION_TEST_RUN_LOG,
        coverageReportPath = null
      )
    }

    fun parseFrom(environmentProto: EnvironmentProto.Environment): Environment {
      val outputDirectory = environmentProto.outputDirOrDefault(DEFAULT_OUTPUT_DIRECTORY)
      val tempDirectory = environmentProto.tmpDirOrDefault(DEFAULT_TEMP_DIRECTORY)
      val runfilesDirectory = environmentProto.runfilesDirOrDefault(default.runfilesDirectory)
      val testLogDir =
        File(outputDirectory, environmentProto.testLogDirOrDefault(DEFAULT_TEST_LOG_DIR))
          .absolutePath
      val testRunLog = environmentProto.testRunLogOrDefault(DEFAULT_INSTRUMENTATION_TEST_RUN_LOG)
      val coverageReportPath = environmentProto.coverageReportPathOrNull()
      val androidLogcatOptions = environmentProto.logcatOptionsOrDefault(DEFAULT_LOGCAT_OPTIONS)
      return Environment(
        outputDirectory,
        tempDirectory,
        runfilesDirectory,
        testLogDir,
        testRunLog,
        coverageReportPath,
        androidLogcatOptions,
      )
    }
  }

  val enableCoverage = !coverageReportPath.isNullOrEmpty()
}
