/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.error

import com.google.testing.platform.api.error.ErrorSummary

const val NAMESPACE = "com.google.testing.platform"

/**
 * All the possible error summaries of UTP core. Each error summary contains a name, type, code and
 * namespace.
 */
enum class UtpCoreErrorSummary(override val errorCode: Int, override val errorType: Enum<*>) :
  ErrorSummary {
  CORE_FAILED(1001, ErrorType.INFRA),
  EXTENSION_CONFIG_PARSING(1002, ErrorType.CONFIG),
  EXTENSION_CLASS_LOADING_FAILURE(1003, ErrorType.CONFIG),
  EXTENSION_CONFIGURATION_FAILED(1004, ErrorType.CONFIG),
  ILLEGAL_TEST_STATUS(1005, ErrorType.TEST),
  ABORTED(1006, ErrorType.INFRA);

  override val errorName = this.name
  override val namespace = NAMESPACE
}
