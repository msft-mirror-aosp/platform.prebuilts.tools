/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.event

/**
 * Low level interface for sending and receiving events in UTP. If you are an Extension author, use
 * the extension methods provided in `EventExt.kt`.
 */
interface Events {
  /** Sends a low level event representation to be processed by other Extensions. */
  fun send(event: String, message: ByteArray)

  /** Retrieves all serialized Events of a specific type that have been sent by other Extensions. */
  fun get(event: String): List<ByteArray>

  /** Performs any needed verification of events sent and received in the given circumstance.
   *
   * @param circumstance A user-friendly name to associate with the code block being verified
   * @param maybeProvides An optional collection of events that might be emitted within the code
   * block, to be treated as optional within the verification
   * @param block The code block to verify
   */
  fun <R> verify(circumstance: String, maybeProvides: Set<String> = emptySet(), block: () -> R): R =
    block()
}
