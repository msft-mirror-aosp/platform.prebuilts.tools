/*
 * Copyright (C) 2018 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config.v1.extension

import com.google.testing.platform.proto.api.config.AndroidSdkProto.AndroidSdk

/**
 * Gets the dexdump path if it exists, otherwise defaults to the sdk path.
 */
val AndroidSdk.dexdumpOrSdkPath: String
  get() = if (hasDexdumpPath()) dexdumpPath.path else sdkPath.path

/** Returns the sdkPath or Default */
fun AndroidSdk.sdkPathOrDefault(default: String?): String {
  if (hasSdkPath() && !sdkPath.path.isNullOrBlank()) return sdkPath.path
  return default!!
}

/** Returns the aaptPath or Default */
fun AndroidSdk.aaptPathOrDefault(default: String?): String {
  if (hasAaptPath() && !aaptPath.path.isNullOrBlank()) return aaptPath.path
  return default!!
}

/** Returns the sdkPath or Default */
fun AndroidSdk.adbPathOrDefault(default: String?): String {
  if (hasAdbPath() && !adbPath.path.isNullOrBlank()) return adbPath.path
  return default!!
}

/** Returns the dexDumpPath or Default */
fun AndroidSdk.dexDumpPathOrDefault(default: String?): String {
  if (hasDexdumpPath() && !dexdumpPath.path.isNullOrBlank()) return dexdumpPath.path
  return default!!
}
