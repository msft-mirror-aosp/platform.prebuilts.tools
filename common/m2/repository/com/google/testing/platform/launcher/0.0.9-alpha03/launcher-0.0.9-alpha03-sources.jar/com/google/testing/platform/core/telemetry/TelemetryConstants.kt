package com.google.testing.platform.core.telemetry

import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase

val PHASE_ATTRIBUTE_KEY = TestPhase::class.java.name
const val DISPLAY_NAME_ATTRIBUTE_KEY = "DisplayName"
