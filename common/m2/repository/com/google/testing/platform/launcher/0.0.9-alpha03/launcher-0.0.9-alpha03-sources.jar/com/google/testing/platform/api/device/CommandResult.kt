/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.device

import java.io.InputStream
import java.nio.charset.Charset
import java.util.Arrays

/**
 * Container for command results.
 *
 * @property statusCode the exit code for the command; 0 signifies success.
 * @property byteOutputStream an [InputStream] to the command output. On command success, contains
 * the raw output result, else contains error details. The caller is responsible for closing the
 * stream.
 */
class CommandResult(val statusCode: Int, val byteOutputStream: InputStream) {

  /**
   * Secondary constructor.
   *
   * @param statusCode the exit code for the command; 0 signifies success.
   * @param byteOutput the output of the command as a [ByteArray].
   */
  constructor(statusCode: Int, byteOutput: ByteArray) : this(statusCode, byteOutput.inputStream())

  /**
   * Secondary constructor.
   *
   * @param statusCode the exit code for the command; 0 signifies success.
   * @param byteOutput the output of the command as a list of [String].
   */
  constructor(
    statusCode: Int,
    output: List<String>
  ) : this(statusCode, output.joinToString("\n").toByteArray(Charsets.UTF_8)) {}

  /**
   * Splits the output to a list of lines delimited by the new line separator.
   *
   * UTF_8 encoding is used. Use [outputLineSequence] if you need a custom encoding or work with
   * large command output.
   */
  val output: List<String>
    get() = outputLines(Charsets.UTF_8)

  /**
   * Encodes the command output using the given [charset], and splits it to a list of lines
   * delimited by the new line separator.
   */
  private fun outputLines(charset: Charset = Charsets.UTF_8) =
    with(String(byteOutput, charset).trim()) {
      if (isEmpty()) {
        emptyList()
      } else {
        lines()
      }
    }

  /**
   * The output as a bulk byte array. It loads all the output bytes into memory.
   *
   * Note: you should read directly from the [byteOutputStream] or use [outputLineSequence] if the
   * output's expected to be large.
   */
  val byteOutput: ByteArray by lazy {
    // We cache the content read from the stream, so it can be accessed for multiple times.
    byteOutputStream.readAllBytes()
  }

  /** Returns the output as a sequence of lines using the specified encoding. */
  fun outputLineSequence(charset: Charset = Charsets.UTF_8) =
    byteOutputStream.bufferedReader(charset).lineSequence()

  /** Destructuring declarations so that `val (statusCode, output) = commandResult` is supported. */
  operator fun component1() = statusCode
  operator fun component2() = output

  override fun equals(other: Any?): Boolean {
    if (this === other) {
      return true
    }
    if (other?.javaClass != javaClass) {
      return false
    }

    other as CommandResult
    return (statusCode == other.statusCode && Arrays.equals(byteOutput, other.byteOutput))
  }

  override fun hashCode() = statusCode + 31 * Arrays.hashCode(byteOutput)
}
