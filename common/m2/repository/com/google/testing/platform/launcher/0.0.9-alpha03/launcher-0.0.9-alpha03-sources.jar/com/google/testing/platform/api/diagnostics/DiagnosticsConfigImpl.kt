/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.diagnostics

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.api.config.ConfigBase
import com.google.testing.platform.proto.api.config.AndroidSdkProto.AndroidSdk
import com.google.testing.platform.proto.api.config.EnvironmentProto.Environment
import com.google.testing.platform.proto.api.config.SetupProto.TestSetup
import com.google.testing.platform.proto.api.core.ExtensionProto

/**
 * Provides configuration values to [Diagnostics].
 *
 * @param environmentProto proto to build [Environment] data class.
 * @param testSetupProto proto to build [TestSetup] data class.
 * @param androidSdkProto proto to build [AndroidSdk] data class.
 * @param configProto The diagnostics config.
 */
class DiagnosticsConfigImpl(
  environmentProto: Environment,
  testSetupProto: TestSetup,
  androidSdkProto: AndroidSdk,
  configProto: AnyProto? = null,
  configResource: ExtensionProto.ConfigResource? = null
) : DiagnosticsConfig,
  ConfigBase by ConfigBase(
    environmentProto,
    testSetupProto,
    androidSdkProto,
    configProto,
    configResource
  )
