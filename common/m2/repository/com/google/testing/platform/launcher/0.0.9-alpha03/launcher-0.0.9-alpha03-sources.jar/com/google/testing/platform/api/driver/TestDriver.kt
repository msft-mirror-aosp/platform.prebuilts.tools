/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.driver

import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.result.TestResultPublisher

/**
 *  Generic interface to run tests.
 *
 *  This is not tied to any test type or platform.
 *
 *  Test driver is responsible for
 *  1. Running tests
 *  2. Propagating the results to TestResultPublisher
 */
interface TestDriver : Configurable, Cancellable {

  /**
   * Run tests on device.
   *
   * @param controller DeviceController that targets the relevant device
   * @param testResultPublisher TestResultPublisher through which results are published
   */
  fun run(controller: DeviceController, testResultPublisher: TestResultPublisher)
}
