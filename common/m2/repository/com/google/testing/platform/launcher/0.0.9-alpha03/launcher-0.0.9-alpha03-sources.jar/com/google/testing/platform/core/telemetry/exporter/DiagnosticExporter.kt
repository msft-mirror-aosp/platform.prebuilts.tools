/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.exporter

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.api.config.Configurable
import io.opencensus.proto.trace.v1.Span

/** Exports [Span]s. All implementations must be non-blocking. */
interface DiagnosticExporter : Configurable {
  /**
   * Exports the given [Span].
   *
   * Any implementations of this method must do so in a non-blocking manner.
   *
   * @return [true] if export is successful
   */
  @CanIgnoreReturnValue fun export(span: Span): Boolean

  /**
   * Exports the given list of [Span]s.
   *
   * Any implementations of this method must do so in a non-blocking manner.
   *
   * @return [true] if export is successful
   */
  @CanIgnoreReturnValue
  fun export(spans: Collection<Span>): Boolean {
    return spans.all { span -> export(span) }
  }
}
