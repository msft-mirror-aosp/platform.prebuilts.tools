/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.runtime.android.device

import com.google.testing.platform.api.device.DeviceProperties

/** Data class that holds properties/Environment variables of an Android device. */
data class AndroidDeviceProperties(
  /** Properties/Environment variable map. */
  val map: Map<String, String> = emptyMap(),
  /** The External Storage Directory in an android device. */
  val externalStorageDir: String = map.getOrDefault(EXTERNAL_STORAGE, DEFAULT_EXTERNAL_STORAGE),
  /** The Android Storage Directory in an android device. */
  val androidStorageDir: String = map.getOrDefault(ANDROID_STORAGE, DEFAULT_ANDROID_STORAGE),
  /** The Android data Directory in an android device. */
  val androidDataDir: String = map.getOrDefault(ANDROID_DATA, DEFAULT_ANDROID_DATA),
  /** The current Api level of an android device. */
  val deviceApiLevel: String = map.getOrDefault(DEVICE_API_LEVEL, DEFAULT_DEVICE_API_LEVEL),
  /**
   * Extra storage directory for Android Auto devices. Usually in the format
   * "/storage/emulated/CURRENT_USER"
   */
  val autoExtraStorageDir: String? = null,
  /** Name of an Android Virtual Device (AVD), null for physical device. */
  val avdName: String? = null,
  /** Additional command line parameters to pass to logcat in streamLogs(). */
  val logcatOptions: List<String> = emptyList(),
  /** Result of am get-current-user */
  val currentUser: String? = null,
) : DeviceProperties {

  companion object {
    const val EXTERNAL_STORAGE = "EXTERNAL_STORAGE"
    const val ANDROID_DATA = "ANDROID_DATA"
    const val ANDROID_STORAGE = "ANDROID_STORAGE"
    const val DEVICE_API_LEVEL = "ro.build.version.sdk"

    // Defaults
    private const val DEFAULT_EXTERNAL_STORAGE = "/sdcard"
    private const val DEFAULT_ANDROID_DATA = "/data"
    private const val DEFAULT_ANDROID_STORAGE = "/storage"
    private const val DEFAULT_DEVICE_API_LEVEL = "-1"
  }
}
