/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.device

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.proto.api.core.LogMessageProto
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import java.time.Duration
import kotlinx.coroutines.flow.Flow

// TODO(b/142562920): Change all commands to return a command result
/** Facade to interface with an Android device */
interface DeviceController {

  /** Returns the [Device] for this controller. */
  fun getDevice(): Device

  /** Sets the [Device] for this controller */
  fun setDevice(device: Device)

  /** Removes the [Device] for this controller */
  fun releaseDevice() = Unit

  /**
   * Installs an executable [Artifact] on a device, e.g. Android Apk
   *
   * @return [CommandResult] with exit code and output of the command.
   */
  fun install(artifact: Artifact): CommandResult

  /**
   * Pushes a file represented by an [Artifact] to a device
   *
   * @return command exit code
   */
  fun push(artifact: Artifact): Int

  /**
   * Pulls a file represented by an [Artifact] from a device
   *
   * @return command exit code
   */
  fun pull(artifact: Artifact): Int

  /**
   * Executes a shell command on the device. TODO(b/165925282): Make this an extension of Async
   * method.
   *
   * @param args executes these args on the device.
   * @param timeout an optional timeout that can be set; this should be set by the implementation if
   *   the caller doesn't set it.
   * @return CommandResult with exit code and output of the command.
   */
  @CanIgnoreReturnValue fun execute(args: List<String>, timeout: Duration? = null): CommandResult

  /**
   * Executes a shell command asynchronously on the device.
   *
   * @param args executes these args on the device.
   * @param processor a lambda that process output lines on the fly.
   * @return [CommandHandle] to interact with the command.
   */
  fun executeAsync(args: List<String>, processor: (String) -> Unit): CommandHandle

  /**
   * Returns a [Flow] of [LogMessageProto.LogMessage] from the device.
   *
   * @return [Flow] upon which consumers can invoke collect and other stream operations like filter,
   *   map etc.
   */
  fun streamLogs(): Flow<LogMessageProto.LogMessage>

  /** Returns a map of extensions. */
  fun extensions(): Map<String, Any> = emptyMap()
}
