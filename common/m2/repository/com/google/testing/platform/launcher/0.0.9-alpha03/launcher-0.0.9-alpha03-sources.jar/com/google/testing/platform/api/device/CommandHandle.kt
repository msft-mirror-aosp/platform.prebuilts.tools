/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.device

import java.time.Duration
import java.util.concurrent.TimeoutException

/** Interface to interact with a async command. */
interface CommandHandle {
  /**
   * Get exit code of the command.
   *
   * If this method is called before the process terminates, an [IllegalStateException] will be
   * thrown.
   */
  @Throws(IllegalStateException::class) fun exitCode(): Int

  /**
   * Stop a command preemptively.
   *
   * Will be a no-op if the process has already stopped.
   */
  fun stop()

  /** Check if the command is still running. */
  fun isRunning(): Boolean

  /**
   * Wait for the command to finish.
   *
   * Will wait indefinitely if the [timeout] is `null`.
   *
   * @params timeout timeout to wait for the command to exit. Default: null
   * @throws TimeoutException if the command doesn't exit within the given timeout
   */
  @Throws(TimeoutException::class) fun waitFor(timeout: Duration? = null)
}
