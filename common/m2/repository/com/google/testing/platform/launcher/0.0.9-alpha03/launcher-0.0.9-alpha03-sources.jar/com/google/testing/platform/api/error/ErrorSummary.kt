/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.error

/* Summary of the error. */
interface ErrorSummary {

  /**
   * The namespace of the component that produced this error.
   * E.g UnifiedTestPlatForm, DataStagingPlugin
   */
  val namespace: String

  /**
   * Name of the Error.
   * E.g PLUGIN_FAILED, NO_TESTS_FOUND
   */
  val errorName: String

  /**
   * The Error code, each extension is in its own namespace and has a unique
   * error code definition.
   */
  val errorCode: Int

  /**
   * The type of the error.
   * Note that each namespace can have its own set of error classification types
   * See [ErrorType] for an example.
   */
  val errorType: Enum<*>
}
