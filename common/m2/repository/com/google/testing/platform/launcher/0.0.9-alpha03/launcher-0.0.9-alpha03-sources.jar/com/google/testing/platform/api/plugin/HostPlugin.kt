/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.plugin

import com.google.testing.platform.api.config.Configurable
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult

/** HostPlugin interface for Unified Test Platform plugins */
interface HostPlugin : Configurable {

  /** Called before test suite execution */
  fun beforeAll(deviceController: DeviceController)

  /** Called before each test */
  fun beforeEach(testCase: TestCase?, deviceController: DeviceController)

  /**
   * Called after each test.
   *
   * If the test is cancelled or aborted in the middle of execution (possibly due to running longer
   * than the test timeout setting), this method will be called with [cancelled] set to [true].
   * Note: long-running operations are not guaranteed to run if the test is cancelled.
   *
   * @param testResult the test result.
   * @param deviceController the handler to interact with the device under test.
   * @param cancelled whether the test is cancelled or aborted in the middle of execution.
   */
  fun afterEach(
    testResult: TestResult,
    deviceController: DeviceController,
    cancelled: Boolean = false
  )

  /**
   * Called after test suite completes.
   *
   * If the test suite is cancelled or aborted in the middle of execution (possibly due to running
   * longer than the timeout setting), this method will be called with [cancelled] set to [true].
   * Note: long-running operations are not guaranteed to run if the test is cancelled.
   *
   * @param testSuiteResult the test suite result.
   * @param deviceController the handler to interact with the device under test.
   * @param cancelled whether the test suite is cancelled or aborted in the middle of execution.
   */
  fun afterAll(
    testSuiteResult: TestSuiteResult,
    deviceController: DeviceController,
    cancelled: Boolean = false
  )

  /** Returns if the plugin should run under the current configuration */
  fun canRun(): Boolean
}
