package com.google.testing.platform.api.plugin

import com.google.protobuf.Parser
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.event.get
import com.google.testing.platform.api.event.getEnum
import com.google.testing.platform.api.event.send
import com.google.testing.platform.api.event.sendEnum
import com.google.testing.platform.proto.api.core.ArtifactKt
import com.google.testing.platform.proto.api.core.ErrorKt
import com.google.testing.platform.proto.api.core.ErrorProto.Error
import com.google.testing.platform.proto.api.core.IssueKt
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestResultKt
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.artifact
import com.google.testing.platform.proto.api.core.error
import com.google.testing.platform.proto.api.core.issue
import com.google.testing.platform.proto.api.core.testResult

/**
 * Adds the given artifacts to the corresponding result. Calling this method from afterEach will
 * update the TestResult, whereas calling this from afterAll will update the TestSuiteResult.
 *
 * @param artifacts The list of artifacts to add
 */
fun Events.sendArtifacts(artifacts: List<Artifact>) = artifacts.forEach { this.send(it) }

/**
 * Adds the given artifact to the corresponding result. Calling this method from afterEach will
 * update the TestResult, whereas calling this from afterAll will update the TestSuiteResult.
 *
 * @param artifact The artifact to add
 */
fun Events.sendArtifact(artifact: Artifact) = this.send(artifact)

/**
 * Creates and adds the given artifact to the corresponding result. Calling this method from
 * afterEach will update the TestResult, whereas calling this from afterAll will update the
 * TestSuiteResult.
 *
 * @param block Statement to execute in the artifact builder
 */
fun Events.sendArtifact(block: ArtifactKt.Dsl.() -> Unit) = this.sendArtifact(artifact(block))

/**
 * Retrieves the list of {@link Artifact}s that have been sent via the event system.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterEach/afterAll; this method cannot be used by a plugin
 * to retrieve an artifact sent by a previous plugin.
 */
fun Events.getArtifacts() = this.get<Artifact>()

/**
 * Adds the given {@link Error} to the corresponding {@link TestResult}. This method is only
 * supported when called from afterEach.
 *
 * @param error The error to add
 */
fun Events.sendError(error: Error) = this.send(error)

/**
 * Creates and adds the given {@link Error} to the corresponding {@link TestResult}. This method is
 * only supported when called from afterEach.
 *
 * @param block Statement to execute in the error builder
 */
fun Events.sendError(block: ErrorKt.Dsl.() -> Unit) = this.sendError(error(block))

/**
 * Retrieves the list of {@link Error}s that have been sent via the event system.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterEach; this method cannot be used by a plugin to
 * retrieve an error sent by a previous plugin.
 */
fun Events.getErrors() = this.get<Error>()

/**
 * Adds the given {@link Issue} to the corresponding TestSuiteResult. This method is only supported
 * when called from afterAll.
 *
 * @param issue The issue to add
 */
fun Events.sendIssue(issue: Issue) = this.send(issue)

/**
 * Creates and adds the given {@link Issue} to the corresponding TestSuiteResult. This method is
 * only supported when called from afterAll.
 *
 * @param block Statement to execute in the issue builder
 */
fun Events.sendIssue(block: IssueKt.Dsl.() -> Unit) = this.sendIssue(issue(block))

/**
 * Retrieves the list of {@link Issue}s that have been sent via the event system.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterAll; this method cannot be used by a plugin to
 * retrieve an issue sent by a previous plugin.
 */
fun Events.getIssues() = this.get<Issue>()

/**
 * Sets the test status of the corresponding result. Calling this method from afterEach will update
 * the TestResult, whereas calling this from afterAll will update the TestSuiteResult.
 *
 * @param status The new status of the result
 */
fun Events.sendStatus(status: TestStatus) = this.sendEnum(status)

/**
 * Retrieves the latest test status that was sent via the event system, or null if no statuses have
 * been sent.
 */
fun Events.getStatus(): TestStatus? {
  val statuses = this.getEnum<TestStatus>()
  return if (statuses.isEmpty()) {
    null
  } else {
    statuses.last()
  }
}

/**
 * Appends the given test result to the corresponding test suite.
 *
 * @param testResult The test result to add
 */
fun Events.sendTestResult(testResult: TestResult) = this.send(testResult)

/**
 * Creates and appends the given test result to the corresponding test suite.
 *
 * @param block Statement to execute in the result builder
 */
fun Events.sendTestResult(block: TestResultKt.Dsl.() -> Unit) =
  this.sendTestResult(testResult(block))

/**
 * Retrieves the list of {@link TestResult}s that have been sent via the event system.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterEach/afterAll; this method cannot be used by a plugin
 * to retrieve a result sent by a previous plugin.
 */
fun Events.getExtraTestResults() = this.get<TestResult>()

/**
 * Updates the result in the test suite with the given {@link TestResult}'s name.
 *
 * Updates to a given test result should ideally be done via other extension functions from
 * afterEach wherever possible. However, this method is available for those cases where relevant
 * information isn't available until afterAll.
 *
 * @param testResult TestResult object containing updates to propagate to the corresponding test in
 *   the suite
 */
fun Events.sendTestResultUpdate(testResult: TestResult) {
  this.send(testResult.eventName, testResult.toByteArray())
}

/**
 * Updates the result in the test suite with the given {@link TestResult}'s name.
 *
 * Updates to a given test result should ideally be done via other extension functions from
 * afterEach wherever possible. However, this method is available for those cases where relevant
 * information isn't available until afterAll.
 *
 * @param block A statement to pass to a result builder to create the TestResult object containing
 *   updates to propagate to the corresponding test in the suite
 */
fun Events.sendTestResultUpdate(block: TestResultKt.Dsl.() -> Unit) =
  this.sendTestResultUpdate(testResult(block))

/**
 * Gets the full list of updates to make to test results in the corresponding suite.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterAll; this method cannot be used by a plugin to
 * retrieve information sent by a previous plugin.
 */
fun Events.getTestResultUpdates(testResult: TestResult): List<TestResult> {
  val messages = this.get(testResult.eventName)
  @Suppress("UNCHECKED_CAST")
  val parser = TestResult::class.java.getMethod("parser").invoke(null) as Parser<TestResult>
  return messages.map { parser.parseFrom(it) }
}

/** Unique identifier for a TestResult. */
val TestResult.eventName: String
  get() =
    String.format(
      "%s;%s.%s#%s",
      TestResult::class.java.name,
      this.testCase.testPackage,
      this.testCase.testClass,
      this.testCase.testMethod
    )
