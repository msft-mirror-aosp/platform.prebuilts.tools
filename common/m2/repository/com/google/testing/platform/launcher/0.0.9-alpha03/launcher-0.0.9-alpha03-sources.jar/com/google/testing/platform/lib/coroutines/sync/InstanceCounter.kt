/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.coroutines.sync

import com.google.errorprone.annotations.ThreadSafe
import java.util.Collections
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.atomicfu.AtomicInt
import kotlinx.atomicfu.AtomicRef
import kotlinx.atomicfu.atomic
import kotlinx.coroutines.sync.Semaphore

/** Contains the context to synchronize multiple instances. */
private class Synchronizer(
  /** The threshold at which the semaphore is released. */
  val threshold: Int,
  /** The number of instances waiting for synchronization to complete. */
  val waiting: AtomicInt = atomic(0),
) {
  /** The semaphore is created with all permits acquired, then releases them all at once. */
  private val semaphore = Semaphore(threshold, threshold)
  private val canceled = atomic<CancellationException?>(null)

  /** Synchronizes all instances. */
  suspend fun synchronize(beforeRelease: () -> Unit) {
    // If this synchronizer has been canceled, throw immediately.
    canceled.value?.let { throw it }

    if (waiting.incrementAndGet() >= threshold) {
      beforeRelease.invoke()
      for (i in 1..threshold) {
        semaphore.release()
      }
    }

    semaphore.acquire()

    canceled.value?.let { throw it }
  }

  /** Cancels any listening instances. */
  suspend fun cancel(exception: CancellationException) {
    canceled.value = exception
    while (waiting.getAndDecrement() > 0) {
      semaphore.release()
    }
  }
}

/** Contains per-class synchronization information. */
private data class Instance(
  /** The total number of instances of counters for a particular class. */
  val total: AtomicInt = atomic(0),
  /** The object used to synchronize multiple instances. */
  var synchronizer: AtomicRef<Synchronizer?> = atomic<Synchronizer?>(null),
)

/** Copying the logic from AtomicReference.updateAndGet, since AtomicFU haven't caught up. */
inline fun <reified T> AtomicRef<T>.updateAndGet(updater: (T) -> T): T {
  var prev = value
  var next: T? = null
  var haveNext = false
  while (true) {
    if (!haveNext) next = updater(prev)
    // If the value is still prev, update it with next and return next.
    if (compareAndSet(prev, next!!)) return next
    // The value was not prev and the update was not performed! Get another snapshot of prev; just
    // in case it is *now* the expected prev, avoid regenerating next unnecessarily.
    val old = prev
    prev = value
    haveNext = (prev == old)
  }
}

/**
 * To use an InstanceCounter, declare one as a class member, e.g.
 *
 * <code> class Foo { private val instance = InstanceCounter.create<Foo>() } </code>
 */
@ThreadSafe
class InstanceCounter constructor(private val clazz: Class<*>) {
  /** The unique index of this counter. */
  val current: Int

  init {
    // getOrPut() is a Kotlin extension, so while instances is thread-safe, we need to synchronize
    // on it when doing anything that isn't an atomic operation in the underlying object.
    current =
      synchronized(instances) { instances.getOrPut(clazz) { Instance() }.total.getAndIncrement() }
  }

  /** The total number of instances of this counter. */
  val total: Int
    get() = instances.get(clazz)!!.total.value

  /** Resets the instance counter for this class. Used in testing. */
  fun reset() {
    instances.get(clazz)!!.apply {
      total.value = 0
      synchronizer.value = null
    }
  }

  /** Cancels any listening instances. */
  suspend fun cancel(
    exception: CancellationException = CancellationException("synchronization canceled")
  ) {
    instances.get(clazz)?.synchronizer?.value?.cancel(exception)
  }

  /** Synchronizes all instances, blocking until they have all called this method. */
  suspend fun synchronize() {
    val instance: Instance = instances.get(clazz)!!
    val synchronizer: Synchronizer =
      instance.synchronizer.updateAndGet { synchronizer: Synchronizer? ->
        synchronizer ?: Synchronizer(instance.total.value)
      }!!
    // Before we start releasing any permits, null out the synchronizer instance so a new
    // synchronization can kick in.
    synchronizer.synchronize { instance.synchronizer.value = null }
  }

  public companion object {
    private val instances = Collections.synchronizedMap(mutableMapOf<Class<*>, Instance>())

    inline fun <reified T> create() = InstanceCounter(T::class.java)
  }
}
