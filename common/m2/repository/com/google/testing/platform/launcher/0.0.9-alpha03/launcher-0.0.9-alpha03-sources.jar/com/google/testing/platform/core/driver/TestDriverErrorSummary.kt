/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.driver

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

const val NAMESPACE = "com.google.testing.platform"

/**
 * Different error summaries for [TestDriver]s. Each error summary contains a name, type, code and
 * namespace.
 */
enum class TestDriverErrorSummary(override val errorCode: Int, override val errorType: Enum<*>) :
  ErrorSummary {

  /** Test driver has been provided with incorrect config. */
  DRIVER_CONFIG_ERROR(4001, ErrorType.CONFIG),

  /** Error during test execution. */
  TEST_EXECUTION_FAILED(4002, ErrorType.TEST),

  /** The test was interrupted. */
  TEST_INTERRUPTED(4003, ErrorType.INFRA),

  /** Could not determine the error type, use this when unsure which error summary to use. */
  UNDETERMINED(4999, ErrorType.UNDETERMINED);

  override val errorName = this.name
  override val namespace = NAMESPACE
}
