/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.device

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

const val NAMESPACE = "com.google.testing.platform"

/**
 * Different error summaries for [DeviceProvider]s. Each error summary contains a name, type, code
 * and namespace.
 */
enum class DeviceProviderErrorSummary(
  override val errorCode: Int,
  override val errorType: Enum<*>
) : ErrorSummary {

  /* Device Provider has been provided with incorrect config. */
  DEVICE_PROVIDER_CONFIG_ERROR(3001, ErrorType.CONFIG),

  /* Error during device provisioning. */
  DEVICE_PROVISION_FAILED(3002, ErrorType.UNDERLYING_TOOL),

  /* Error trying to release device. */
  DEVICE_RELEASE_FAILED(3003, ErrorType.UNDERLYING_TOOL),

  /* Error trying to install the binary on the device. */
  INSTALLATION_ERROR(3004, ErrorType.CONFIG),

  /* Could not determine the error type, use this when unsure which error summary to use. */
  UNDETERMINED(3999, ErrorType.UNDETERMINED);

  override val errorName = this.name
  override val namespace = NAMESPACE
}
