/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.core

/**
 * Contains the return value of a recorded diagnostic event
 */
interface EventRecord<T : Any?> {

  /**
   * Returns the result of the event when the event is a success or throws the exception when the
   * block fails.
   */
  fun getOrThrow(): T

  /** Returns true if the block executed without exceptions */
  fun isSuccess(): Boolean
}
