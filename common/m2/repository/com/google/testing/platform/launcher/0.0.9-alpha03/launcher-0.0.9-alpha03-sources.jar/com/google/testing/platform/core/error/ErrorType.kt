/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.error

/**
 * Classification of general UTP errors. Each Error in UTP core will be mapped to one of these error
 * types.
 */
enum class ErrorType {

  /**
   * There was an issue with the assets provided. E.g. The application or test could not be
   * installed.
   */
  ASSET,

  /** Wrong config entered by the User. E.g. Wrong [RunnerConfig], */
  CONFIG,

  /** Errors caused by Underlying tools/extensions. E.g. Errors caused by [DeviceProvider]s. */
  UNDERLYING_TOOL,

  /**
   * Errors caused by the UTP core infrastructure. E.g. Errors in [Executor], streaming results back
   * from the [Device].
   */
  INFRA,

  /**
   * Error caused during setting-up the test harness and during test execution. E.g. [HostPlugin],
   * [TestDriver] failures.
   */
  TEST,

  /* Errors whose causes are not determined. */
  UNDETERMINED
}
