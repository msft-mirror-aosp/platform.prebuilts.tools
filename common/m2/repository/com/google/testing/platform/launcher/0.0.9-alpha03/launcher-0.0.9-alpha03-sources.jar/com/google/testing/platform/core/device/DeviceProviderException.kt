/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.device

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.UtpException

/**
 * Exception to throw whenever a device cannot be obtained, released or if configured incorrectly.
 * Any other exception emerging from a DeviceProvicder will be wrapped as the cause of a
 * DeviceProviderException.
 */
open class DeviceProviderException(
  message: String,
  errorSummary: ErrorSummary = DeviceProviderErrorSummary.UNDETERMINED,
  throwable: Throwable? = null
) : UtpException(errorSummary, message, throwable)
