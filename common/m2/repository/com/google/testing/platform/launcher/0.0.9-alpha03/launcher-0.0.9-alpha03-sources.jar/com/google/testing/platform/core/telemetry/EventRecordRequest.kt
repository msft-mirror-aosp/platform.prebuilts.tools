package com.google.testing.platform.core.telemetry

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.core.DiagnosticScope
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.core.telemetry.core.EventRecord
import com.google.testing.platform.proto.api.core.PhaseProto

/** Base class of all EventRecord requests. */
abstract class EventRecordRequest<T> internal constructor(internal val name: String) {
  /** A human-readable name for the event (defaults to the record's name). */
  var displayName: String?
    get() = attributes[DISPLAY_NAME_ATTRIBUTE_KEY]?.value.toString()
    set(value) {
      value?.let { attributes.put(DISPLAY_NAME_ATTRIBUTE_KEY, Detail(it)) }
    }

  /** The phase of the testing lifecycle corresponding to this record (default UNSPECIFIED). */
  var phase: PhaseProto.TestPhase
    get() =
      attributes[PHASE_ATTRIBUTE_KEY]?.value as PhaseProto.TestPhase?
        ?: PhaseProto.TestPhase.TEST_PHASE_UNSPECIFIED
    set(phase) {
      attributes[PHASE_ATTRIBUTE_KEY] = Detail(phase.name)
    }

  /** Any additional attributes (i.e. other than [displayName] or [phase]) to add to the event. */
  val attributes = mutableMapOf<String, Detail<out Any>>()

  /**
   * A single lambda which takes in the result of the code block's execution and returns any further
   * additional attributes based on said result.
   */
  var onComplete: (T) -> Map<String, Detail<out Any>> = { emptyMap() }

  /** see [onComplete] */
  fun onComplete(block: (T) -> Map<String, Detail<out Any>>) {
    onComplete = block
  }

  @CanIgnoreReturnValue
  fun addAttribute(key: String, value: Detail<out Any>) = attributes.put(key, value)

  fun addAllAttributes(attributes: Map<String, Detail<out Any>>) =
    this.attributes.putAll(attributes)
}

/**
 * EventRecordRequest type used in most telemetry calls. Users should invoke [record] instead of
 * instantiating this class directly.
 */
class SequentialEventRecordRequest<T>
internal constructor(name: String, private val diagnostics: Diagnostics) :
  EventRecordRequest<T>(name) {
  private lateinit var block: DiagnosticScope.() -> T

  /**
   * Specify the code block to be measured in [createEvent].
   *
   * @param block The code block to be measured
   */
  fun run(block: DiagnosticScope.() -> T) {
    this.block = block
  }

  internal fun record(): EventRecord<T> =
    if (!::block.isInitialized) {
      throw IllegalStateException("Nothing to record!")
    } else {
      diagnostics.scope.recordEvent(name, attributes, onComplete, block)
    }
}

/**
 * EventRecordRequest type used when the code being measured calls suspend functions. Users should
 * invoke [recordAsync] instead of instantiating this class directly.
 */
class AsyncEventRecordRequest<T>
internal constructor(name: String, private val diagnostics: Diagnostics) :
  EventRecordRequest<T>(name) {
  private lateinit var suspendBlock: suspend DiagnosticScope.() -> T

  /**
   * Specify the code block to be measured in [createEventAsync].
   *
   * @param block The code block to be measured
   */
  fun runAsync(block: suspend DiagnosticScope.() -> T) {
    this.suspendBlock = block
  }

  internal suspend fun recordAsync(): EventRecord<T> =
    if (!::suspendBlock.isInitialized) {
      throw IllegalStateException("Nothing to record!")
    } else {
      diagnostics.scope.recordEventAsync(name, attributes, onComplete, suspendBlock)
    }
}
