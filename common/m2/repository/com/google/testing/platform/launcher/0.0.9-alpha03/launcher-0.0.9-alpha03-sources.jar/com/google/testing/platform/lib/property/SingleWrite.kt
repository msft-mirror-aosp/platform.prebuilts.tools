/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.lib.property

import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

private object UNINITIALIZED

private object ErrorMessage {
  fun notInitialized(name: String) =
    "singleWrite property $name has not been initialized"
  fun alreadyInitialized(name: String) =
    "singleWrite property $name has already been initialized"
}

/**
 * Turns var into read-after-write only. No write-after-write allowed.
 * Throws [UninitializedPropertyAccessException] on read-before-write and [IllegalAccessException]
 * on write-after-write.
 */
fun <T> singleWrite(): SingleWrite<T> = SingleWriteImpl()

/**
 * Turns var into read-after-write only. No write-after-write allowed or write-after-read.
 * If not initialized, returns default. Throws [IllegalAccessException] on write-after write or
 * write-after-read.
 */
fun <T> singleWrite(default: T): SingleWrite<T> = SingleWriteWithDefault(default)

/**
 * Turns var into read-after-write only. No write-after-write allowed.
 * Throws [UninitializedPropertyAccessException] on read-before-write and [IllegalAccessException]
 * on write-after-write.
 */
interface SingleWrite<T> : ReadWriteProperty<Any?, T>

/**
 * Turns var into read-after-write only. No write-after-write allowed.
 * Throws [UninitializedPropertyAccessException] on read-before-write and [IllegalAccessException]
 * on write-after-write.
 */
private class SingleWriteImpl<T> : SingleWrite<T> {
  private var value: Any? = UNINITIALIZED

  override fun getValue(thisRef: Any?, property: KProperty<*>): T {
    if (this.value == UNINITIALIZED) {
      throw UninitializedPropertyAccessException(ErrorMessage.notInitialized(property.name))
    }
    @Suppress("UNCHECKED_CAST")
    return value as T
  }

  override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
    if (this.value != UNINITIALIZED) {
      throw IllegalAccessException(ErrorMessage.alreadyInitialized(property.name))
    }

    this.value = value
  }
}

/**
 * Allows var to be written to once. No write-after-write allowed or write-after-read.
 * Returns default on read-before-write. Throws [IllegalAccessException] on write-after write or
 * write-after-read.
 */
private class SingleWriteWithDefault<T>(
  private val default: T
) : SingleWrite<T> {

  private var update: T by singleWrite()

  private val finalValue = lazy {
    try {
      update
    } catch (ex: UninitializedPropertyAccessException) {
      default
    }
  }

  override fun getValue(thisRef: Any?, property: KProperty<*>): T = finalValue.value

  override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
    if (finalValue.isInitialized()) {
      throw IllegalAccessException(ErrorMessage.alreadyInitialized(property.name))
    }

    this.update = value
  }
}
