/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.net

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.config.Configurable

/** Provides network ports. */
@ThreadSafe
interface PortPicker : Configurable {
  /** Provides an unused network port. */
  fun pickUnusedPort(): Int

  /**
   * Announces that the program is done with a port. If that port was assigned by pickUnusedPort,
   * clean it up. If the port number is negative, do nothing.
   */
  fun releasePort(port: Int): Unit
}
