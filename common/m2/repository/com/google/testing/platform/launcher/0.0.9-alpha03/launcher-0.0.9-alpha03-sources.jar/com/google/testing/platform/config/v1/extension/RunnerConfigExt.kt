/*
 * Copyright (C) 2018 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config.v1.extension

import com.google.protobuf.Internal
import com.google.testing.platform.core.telemetry.proto.DiagnosticsProto
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.DeviceProto.Device
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.EnvironmentProto.Environment
import com.google.testing.platform.proto.api.config.ExecutionProto.DeviceExecution
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixture
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig.ExecutorCase
import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.config.ShardingConfigProto
import com.google.testing.platform.proto.api.config.TestDiscoveryProto
import com.google.testing.platform.proto.api.core.ExtensionProto

/**
 * Looks up a [TestFixture] by id.
 *
 * @param testFixtureId the [TestFixtureId] to look up
 * @throws [IllegalStateException] if element cannot be found
 */
fun RunnerConfig.lookupTestFixtureById(testFixtureId: TestFixtureId): TestFixture {
  val fixture = testFixtureList.firstOrNull { it.testFixtureId == testFixtureId }
  check(fixture != null) {
    "Missing configuration value: test_fixture.test_fixture_id with $testFixtureId"
  }
  return fixture
}

/**
 * Looks up a [Device] by id.
 *
 * @param deviceId the [DeviceId] to look up
 * @throws [IllegalStateException] if element cannot be found
 */
fun RunnerConfig.lookupDeviceById(deviceId: DeviceId): Device {
  return deviceList
    .firstOrNull { it.deviceId == deviceId }
    .also { check(it != null) { "Missing configuration value: device.device_id with $deviceId" } }!!
}

/**
 * Finds the [DeviceExecution] element for the configured executor case.
 *
 * @throws [IllegalStateException] if executor isn't configured or not supported yet
 */
val RunnerConfig.deviceExecution: DeviceExecution
  get() =
    when (executorCase) {
      ExecutorCase.SINGLE_DEVICE_EXECUTOR -> this.singleDeviceExecutor.deviceExecution
      ExecutorCase.MULTI_DEVICE_EXECUTOR -> this.multiDeviceExecutor.primaryDeviceExecution
      ExecutorCase.EXECUTOR_NOT_SET -> {
        val options =
          ExecutorCase.values()
            .filterNot { it == ExecutorCase.EXECUTOR_NOT_SET }
            .joinToString { it.fieldName }
        throw IllegalStateException("Missing configuration value - one of: $options")
      }
      else -> throw IllegalStateException("Unsupported device executor: ${executorCase.fieldName}")
    }

/** Finds and returns the [ShardingConfigProto.ShardingConfig] in the single device executor. */
val RunnerConfig.shardingConfig: ShardingConfigProto.ShardingConfig
  get() {
    if (!hasSingleDeviceExecutor() || !singleDeviceExecutor.hasShardingConfig()) {
      // If there is no config, then run with zero shards.
      return ShardingConfigProto.ShardingConfig.newBuilder().build()
    }
    return singleDeviceExecutor.shardingConfig
  }

/**
 * Finds the [TestFixtureId] element for the configured executor's [DeviceExecution].
 *
 * @throws [IllegalStateException] if the device execution's fixture id not found
 */
val RunnerConfig.deviceExecutionTestFixtureId: TestFixtureId
  get() =
    deviceExecution.testFixtureId.also {
      check(!it.id.isBlank()) {
        // TODO(b/117453461): find a way to lookup these proto field names rather than hardcoding
        "Missing configuration value: ${executorCase.fieldName}.device_execution.test_fixture_id.id"
      }
    }

/** Returns the proto field name used depending on the 'oneof' case enum. */
private val Internal.EnumLite.fieldName: String
  get() = toString().lowercase()

/**
 * Returns the command timeout set in the [Device] specified in [DeviceExecution] or
 * [PrimaryDeviceExecution]
 */
fun RunnerConfig.commandTimeoutOrDefault(default: Long): Long {
  return getFirstDeviceWithId(deviceExecution.deviceId).timeoutSecondsOrDefault(default)
}

/**
 * Returns the first [Device] from the deviceList with the given [DeviceId].
 *
 * @param deviceId: [DeviceId] of a [Device] in the deviceList, can be retrieved from a
 *   [DeviceExecution].
 * @return [Device]: A [Device] with the specified [DeviceId].
 */
fun RunnerConfig.getFirstDeviceWithId(deviceId: DeviceId): Device {
  return deviceList
    .first { it.deviceId == deviceId }
    .also { check(it != null) { "Missing RunnerConfig.Device with DeviceId: $deviceId" } }
}

private val EMPTY_ENVIRONMENT: Environment
  get() = Environment.newBuilder().build()

/**
 * Gets the testing environment from the first [TestFixture]. Otherwise, it builds and returns an
 * empty [Environment].
 *
 * @return [Environment]: The first [TestFixture]'s [Environment], or an empty [Environment] if no
 *   [TestFixture]s exist.
 */
val RunnerConfig.firstEnvironmentOrEmpty: Environment
  get() = if (testFixtureCount == 0) EMPTY_ENVIRONMENT else testFixtureList.first().environment

private val emptyTestSetup: SetupProto.TestSetup
  get() = SetupProto.TestSetup.newBuilder().build()

/**
 * Gets the [TestFixture] from [RunnerConfig]. Otherwise, it builds and returns an empty
 * [TestFixture].
 *
 * @return [TestFixture]: The first [TestFixture], or an empty [TestFixture] if no [TestFixture]s
 *   exist.
 */
val RunnerConfig.firstTestSetupOrEmpty: SetupProto.TestSetup
  get() = if (testFixtureCount == 0) emptyTestSetup else testFixtureList.first().setup

private val emptyAndroidSdk: AndroidSdkProto.AndroidSdk
  get() = AndroidSdkProto.AndroidSdk.newBuilder().build()

/**
 * Gets the [AndroidSdkProto] from environment. Otherwise, returns an empty [AndroidSdkProto].
 *
 * @return [AndroidSdkProto]: The first [AndroidSdkProto], or an empty [AndroidSdkProto] if no
 *   [TestFixture] exists.
 */
val Environment.androidSdkOrEmpty: AndroidSdkProto.AndroidSdk
  get() =
    if (hasAndroidEnvironment() && androidEnvironment.hasAndroidSdk()) {
      androidEnvironment.androidSdk
    } else {
      emptyAndroidSdk
    }

/**
 * Gets the [AndroidSdkProto] from the first Environment in the RunnerConfig. Otherwise, returns an
 * empty [AndroidSdkProto].
 *
 * @return [AndroidSdkProto]: The first [AndroidSdkProto], or an empty [AndroidSdkProto] if no
 *   [TestFixture] exists.
 */
val RunnerConfig.androidSdkOrEmpty: AndroidSdkProto.AndroidSdk
  get() = firstEnvironmentOrEmpty.androidSdkOrEmpty

/** Gets the [AndroidSdkProto] from the [TestFixture], or empty if none exists. */
val TestFixture.androidSdkOrEmpty: AndroidSdkProto.AndroidSdk
  get() = environment.androidSdkOrEmpty

/**
 * Gets the [TestDiscoveryProto] from fixture. Otherwise, returns an empty [TestDiscoveryProto].
 *
 * @return [TestDiscoveryProto]: The first [TestDiscoveryProto], or an empty [TestDiscoveryProto] if
 *   no [TestDiscoveryProto] exists.
 */
val RunnerConfig.firstTestDiscoveryOrEmpty: TestDiscoveryProto.TestDiscovery
  get() =
    if (testFixtureCount == 0) {
      TestDiscoveryProto.TestDiscovery.getDefaultInstance()
    } else {
      testFixtureList.first().testDiscovery
    }

/**
 * Gets the Diagnostics from Runner config. Otherwise, returns an empty
 * [DiagnosticsProto.Diagnostics].
 *
 * @return [DiagnosticsProto.Diagnostics]: The associated diagnostics, or an empty [Diagnostics]
 */
val RunnerConfig.diagnosticsOrEmpty: DiagnosticsProto.Diagnostics
  get() =
    if (hasDiagnostics()) {
      this.diagnostics
    } else {
      DiagnosticsProto.Diagnostics.getDefaultInstance()
    }

/**
 * Looks up a [TestDriver] by id.
 *
 * @param testFixtureId the [TestFixtureId] to look up
 * @throws [IllegalStateException] if element cannot be found
 */
fun RunnerConfig.lookupTestDriverById(testFixtureId: TestFixtureId): ExtensionProto.Extension {
  val fixture = testFixtureList.firstOrNull { it.testFixtureId == testFixtureId }
  check(fixture != null) {
    "Missing configuration value: test_fixture.test_fixture_id with $testFixtureId"
  }
  return fixture.testDriver
}
