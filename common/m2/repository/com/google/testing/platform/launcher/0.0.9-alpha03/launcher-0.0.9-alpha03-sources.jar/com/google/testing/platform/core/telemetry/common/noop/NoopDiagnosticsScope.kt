/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.core.telemetry.common.noop

import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.core.DiagnosticScope
import com.google.testing.platform.core.telemetry.core.EventRecord

/** Noop Diagnostics Scope which just runs function blocks and returns results */
class NoopDiagnosticsScope : DiagnosticScope {

  /* No op implementation of record event which does nothing */
  override fun recordEvent(name: String, details: Map<String, Detail<out Any>>?) = Unit

  override fun <T> recordEvent(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: DiagnosticScope.() -> T
  ): EventRecord<T> {
    // Execute the block
    val result = runCatching { block() }
    return NoopEventRecord(result.getOrNull(), result.isSuccess, result.exceptionOrNull())
  }

  override suspend fun <T> recordEventAsync(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: suspend DiagnosticScope.() -> T
  ): EventRecord<T> {
    // Execute the block
    val result = runCatching { block() }
    return NoopEventRecord(result.getOrNull(), result.isSuccess, result.exceptionOrNull())
  }

  override fun finish() = Unit
}
