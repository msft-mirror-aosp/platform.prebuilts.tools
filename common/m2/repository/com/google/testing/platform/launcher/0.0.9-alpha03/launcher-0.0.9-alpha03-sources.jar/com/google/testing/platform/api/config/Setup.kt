/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact

/**
 * Test Setup related values from the [SetupProto].
 */
data class Setup(

  /** Any artifacts that need to be installed on a device */
  val installables: Set<Artifact>,

  /**
   * Test data artifacts.
   * Optional, data artifacts that need to be staged on a device, by default nothing is staged.
   */
  val dataDeps: Set<Artifact>,

  /**
   * Fixture scripts to setup the test harness
   * Shell scripts that are executed on a device, using the system shell as the target apps user.
   */
  val fixtureScripts: Set<Artifact>,

  /**
   * Additional device directories from which to pull artifacts. Artifacts are stored in the
   * specified output directory.
   */
  val directoriesToPull: Set<String>
) {
  object Creator {
    /**
     * Creates a [Setup] from the [SetupProto.TestSetup] proto. This converts the [Artifact] lists
     * into [LinkedHashSet]s to retain ordering.
     */
    fun parseFrom(testSetup: SetupProto.TestSetup): Setup {
      return Setup(
        installables = linkedSetOf(*testSetup.installableList.toTypedArray()),
        dataDeps = linkedSetOf(*testSetup.dataDepList.toTypedArray()),
        fixtureScripts = linkedSetOf(*testSetup.fixtureScriptList.toTypedArray()),
        directoriesToPull = linkedSetOf(
          *testSetup.directoryToPullList.map { it.path }.toTypedArray()
        )
      )
    }
  }
}
