/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.protobuf.Message
import com.google.protobuf.Parser
import com.google.protobuf.TextFormat
import com.google.protobuf.util.JsonFormat
import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource.Encoding
import java.io.BufferedReader
import java.io.File
import java.io.StringReader
import java.lang.IllegalArgumentException

/**
 * Return [Environment] data class. Will be obtained from ConfigBase (hence the cast)
 * which parses the [Environment] proto.
 */
val Config.environment: Environment
  get() {
    this as ConfigBase
    return environment
  }

/**
 * Return [Setup] data class. Will be obtained from ConfigBase (hence the cast)
 * which parses the [Setup] proto
 */
val Config.setup: Setup
  get() {
    this as ConfigBase
    return setup
  }

/**
 * Return [AndroidSdk] data class. Will be obtained from ConfigBase (hence the cast)
 * which parses the [AndroidSdk] proto.
 */
val Config.androidSdk: AndroidSdk
  get() {
    this as ConfigBase
    return androidSdk
  }

/** Correctly parses the proto used to configure an extension. */
inline fun <reified T : Message> Config.parseConfig(): T? {
  return this.parseConfig(T::class.java)
}

/** Java-friendly config parsing extension function. */
fun <T : Message> Config.parseConfig(clazz: Class<T>): T? {
  this as ProtoConfig
  try {
    if (configProto == null && configResource == null) return null
    val parsed = this.configProto?.unpack(clazz)
    if (parsed != null) return parsed
    return when (this.configResource!!.encoding) {
      Encoding.TEXT -> this.configResource!!.parseTextProto(clazz)
      Encoding.BINARY -> this.configResource!!.parseBinary(clazz)
      Encoding.JSON -> this.configResource!!.parseJsonProto(clazz)
      else ->
        throw IllegalArgumentException(
          """Unexpected Encoding type found:
        | Found: ${this.configResource!!.encoding.name}
        | Expected: ${Encoding.TEXT.name}, ${Encoding.BINARY.name}, or ${Encoding.JSON.name}
        |""".trimMargin()
        )
      }
  } catch (e: Throwable) {
    val messageForError = (this.configProto ?: this.configResource) as Message
    throw UtpException(
      errorSummary = UtpCoreErrorSummary.EXTENSION_CONFIG_PARSING,
      message =
        """Could not parse the following Extension config:
        |${TextFormat.printer().printToString(messageForError)}
        |Error: $e""".trimMargin()
    )
  }
}

/** Parses a binary proto from a [File] or raw bytes. */
@Suppress("UNCHECKED_CAST")
private fun <T : Message> ConfigResource.parseBinary(clazz: Class<T>): T {
  // serialized
  var parseableBytes = this.rawBytes.toByteArray()
  if (this.hasPath()) parseableBytes = File(this.path.path).readBytes()
  return clazz.getParser().parseFrom(parseableBytes) as T
}

/** Parses a text proto from a [File] or a [String]. */
@Suppress("UNCHECKED_CAST")
private fun <T : Message> ConfigResource.parseTextProto(clazz: Class<T>): T {
  (
    if (this.hasPath()) {
      File(path.path).bufferedReader()
    } else {
      BufferedReader(StringReader(this.raw))
    }
  ).use { reader ->
    val builder = clazz.newBuilder()
    TextFormat.getParser().merge(reader, builder)
    return builder.build() as T
  }
}

/** Parses a JSON proto from a [File] or a [String]. */
@Suppress("UNCHECKED_CAST")
private fun <T : Message> ConfigResource.parseJsonProto(clazz: Class<T>): T {
  (
    if (this.hasPath()) {
      File(path.path).bufferedReader()
    } else {
      BufferedReader(StringReader(this.raw))
    }
  ).use { reader ->
    val builder = clazz.newBuilder()
    JsonFormat.parser().merge(reader, builder)
    return builder.build() as T
  }
}

/** Uses reflection to get a [Message]'s [Parser] from the class. */
@Suppress("UNCHECKED_CAST")
private fun <T : Message> Class<T>.getParser(): Parser<T> {
  return getMethod("parser").invoke(null) as Parser<T>
}

/** Uses reflection to get a [Message]'s [Message.Builder] from the class. */
@Suppress("UNCHECKED_CAST")
private fun <T : Message> Class<T>.newBuilder(): Message.Builder {
  return getMethod("newBuilder").invoke(null) as Message.Builder
}
