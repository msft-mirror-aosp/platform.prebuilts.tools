/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.plugins

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.api.config.AndroidSdk
import com.google.testing.platform.api.config.ConfigBase
import com.google.testing.platform.api.config.Environment
import com.google.testing.platform.api.config.Setup
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.core.ExtensionProto

/**
 * Provides configuration values to a [HostPlugin]. Includes base config and plugin-specific config.
 *
 * @param environmentProto proto to build [Environment] data class.
 * @param testSetupProto proto to build [Setup] data class.
 * @param androidSdkProto proto to build [AndroidSdk] data class.
 * @param configProto The plugin-specific config.
 * @param configResource Information on where to find and parse the config for this
 *  [ExtensionProto.Extension] from.
 */
class PluginConfigImpl(
  environmentProto: EnvironmentProto.Environment,
  testSetupProto: SetupProto.TestSetup,
  androidSdkProto: AndroidSdkProto.AndroidSdk,
  configProto: AnyProto? = null,
  configResource: ExtensionProto.ConfigResource? = null
) : ConfigBase by ConfigBase(
    environmentProto,
    testSetupProto,
    androidSdkProto,
    configProto,
    configResource
  )
