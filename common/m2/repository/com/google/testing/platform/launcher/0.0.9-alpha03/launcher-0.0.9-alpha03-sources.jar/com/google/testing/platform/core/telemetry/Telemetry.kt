/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.core.telemetry

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.core.telemetry.common.noop.NoopDiagnostics
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.core.telemetry.core.EventRecord
import com.google.testing.platform.lib.property.singleWrite

/**
 * Object to be imported if you want to use [Telemetry] to record events. This is set for the entire
 * process.
 */
object Telemetry {
  /** Default [Diagnostics] used for the whole Unified Test Platform process. */
  private val defaultTelemetry: Diagnostics = NoopDiagnostics()

  /**
   * The process wide [Diagnostics] for Unified Test Platform. Can be set a single time before this
   * scope is used.Cannot be re-configured for the rest of the process's lifetime.
   */
  var diagnostics: Diagnostics by singleWrite(defaultTelemetry)
}

/**
 * Measure and record information about a given code block.
 *
 * Example usage:
 * ```
 * Telemetry.createEvent("helloWorldEvent") {
 *   run {
 *     println("Hello World")
 *     return@run Unit
 *   }
 * }.getOrThrow()
 * ```
 *
 * @param name A logical name around the block to be executed for later reference.
 * @param init A lambda containing more information about the record, including a <code>run
 *   {}</code> block containing the code to measure.
 * @return An [EventRecord] around the executed code.
 * @throws IllegalStateException if no code block was specified to measure.
 */
@CanIgnoreReturnValue
fun <T> Telemetry.createEvent(name: String, init: SequentialEventRecordRequest<T>.() -> Unit) =
  diagnostics.record(name, init)

/**
 * Measure and record information about a given code block.
 *
 * Example usage:
 * ```
 * Telemetry.createEventAsync("helloWorldEvent") {
 *   runAsync {
 *     someSuspendFunction()
 *   }
 * }.getOrThrow()
 * ```
 *
 * @param name A logical name around the block to be executed for later reference.
 * @param init A lambda containing more information about the record, including a <code>runAsync
 *   {}</code> block containing the code to measure.
 * @return An [EventRecord] around the executed code.
 * @throws IllegalStateException if no code block was specified to measure.
 */
@CanIgnoreReturnValue
suspend fun <T> Telemetry.createEventAsync(
  name: String,
  init: AsyncEventRecordRequest<T>.() -> Unit
) = diagnostics.recordAsync(name, init)
