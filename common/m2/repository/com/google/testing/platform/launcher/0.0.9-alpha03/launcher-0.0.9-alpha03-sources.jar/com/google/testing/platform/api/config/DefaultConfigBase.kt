/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.api.config

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.SetupProto
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource

/**
 * [Config] that contains a proto for configuring an [Extension]. Read the documentation on the
 * [Extension] proto for more details on how these different configurations are used. To parse a
 * config for your extension, do not use this class directly. Instead, use the extension functions
 * for [Config] provided in this package.
 *
 * @param environmentProto proto to build [Environment] data class.
 * @param testSetupProto proto to build [Setup] data class.
 * @param androidSdkProto proto to build [AndroidSdk] data class.
 * @param configProto proto to build the extension
 * @param configResource resource to use to read the proto to build the extension
 *
 * Only one of [configProto] or [configResource] should be set at a time.
 */
internal class DefaultConfigBase(
  environmentProto: EnvironmentProto.Environment,
  testSetupProto: SetupProto.TestSetup,
  androidSdkProto: AndroidSdkProto.AndroidSdk,
  override val configProto: AnyProto? = null,
  override val configResource: ConfigResource? = null
) : ConfigBase, ProtoConfig {

  override val environment: Environment by lazy { Environment.Creator.parseFrom(environmentProto) }

  override val setup: Setup by lazy { Setup.Creator.parseFrom(testSetupProto) }

  override val androidSdk: AndroidSdk by lazy { AndroidSdk.Creator.parseFrom(androidSdkProto) }
}
