/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config.v1.extension

import com.google.testing.platform.proto.api.config.EnvironmentProto.Environment

fun Environment.outputDirOrDefault(default: String) =
  if (hasOutputDir()) outputDir.path else default

fun Environment.tmpDirOrDefault(default: String) = if (hasTmpDir()) tmpDir.path else default

fun Environment.runfilesDirOrDefault(default: String) =
  if (hasRunfilesDir()) runfilesDir.path else default

fun Environment.testLogDirOrDefault(default: String) =
  if (hasAndroidEnvironment()) androidEnvironment.testLogDir.path else default

fun Environment.testRunLogOrDefault(default: String) =
  if (hasAndroidEnvironment()) androidEnvironment.testRunLog.path else default

fun Environment.coverageReportPathOrNull() = androidEnvironment.coverageReportPath.path

fun Environment.logcatOptionsOrDefault(default: List<String> = emptyList()) =
  if (hasAndroidEnvironment()) androidEnvironment.logcatOptionsList else default
