/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor.inject

import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.executor.Executor
import com.google.testing.platform.executor.SingleDeviceExecutor
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.plugin.PluginLifecycle
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import dagger.Lazy
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope

/** Dagger module to create the [Executor] and its device controller dependency. */
@Module(includes = [ExecutorRequisitesModule::class, PluginsModule::class])
class SingleDeviceExecutorModule {

  @Provides
  fun singleDeviceExecutor(
    runnerConfig: RunnerConfig,
    deviceProviders: Map<DeviceId, @JvmSuppressWildcards Lazy<DeviceProvider<DeviceController>>>,
    testDrivers: Map<TestFixtureId, @JvmSuppressWildcards Lazy<TestDriver>>,
    pluginLifecycles: Map<TestFixtureId, PluginLifecycle>,
    rootCoroutineScope: CoroutineScope,
    cancellationContext: ProcessCancellationContext,
    errorUpdater: ErrorUpdater,
    events: Events,
    portPicker: PortPicker?,
  ): SingleDeviceExecutor =
    SingleDeviceExecutor(
      deviceProviders[runnerConfig.singleDeviceExecutor.deviceExecution.deviceId]
        ?: throw IllegalStateException(
          "Device ${runnerConfig.singleDeviceExecutor.deviceExecution.deviceId} not found"
        ),
      testDrivers[runnerConfig.singleDeviceExecutor.deviceExecution.testFixtureId]
        ?: throw IllegalStateException(
          "Test fixture ${runnerConfig.singleDeviceExecutor.deviceExecution.testFixtureId} not found"
        ),
      pluginLifecycles[runnerConfig.singleDeviceExecutor.deviceExecution.testFixtureId]
        ?: throw IllegalStateException(
          "Plugins for ${runnerConfig.singleDeviceExecutor.deviceExecution.testFixtureId} not found"
        ),
      rootCoroutineScope,
      cancellationContext,
      errorUpdater,
      events,
      portPicker,
    )
}
