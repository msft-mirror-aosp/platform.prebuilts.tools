/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.io.File

/** Writes the test results to a log file. */
interface ProtoLogWriter {
  /** The file path where the log file will be written to. */
  val logPath: File

  /**
   * Writes the given [TestSuiteResult] to the configured file. Creates the file if it does not
   * exist, otherwise overwrites the content of the file.
   */
  fun write(testSuiteResult: TestSuiteResult)
}
