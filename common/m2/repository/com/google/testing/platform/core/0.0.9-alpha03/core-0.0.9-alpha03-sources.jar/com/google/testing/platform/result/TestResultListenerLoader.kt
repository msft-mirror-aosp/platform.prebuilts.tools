/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.config.v1.extension.androidSdkOrEmpty
import com.google.testing.platform.config.v1.extension.firstEnvironmentOrEmpty
import com.google.testing.platform.config.v1.extension.firstTestSetupOrEmpty
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.extension.isExtensionValid
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.extension.loadAndConfigure
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import java.lang.IllegalStateException
import javax.inject.Inject
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.newCoroutineContext

/** Class loads [TestResultListener] specified in the [RunnerConfig]. */
class TestResultListenerLoader
@Inject
constructor(private val runnerConfig: RunnerConfig, private val events: Events) {

  companion object {
    fun loadAndConfigureListenersInConfig(
      config: RunnerConfig,
      events: Events,
      coroutineScope: CoroutineScope,
    ): List<TestResultListener> {
      val testResultListeners = config.testResultListenerList
      check(testResultListeners.all { it.isExtensionValid() }) {
        "Found invalid test result listener configuration."
      }

      return testResultListeners.map { testResultListener ->
        loadAndConfigure<TestResultListener>(
            testResultListener.label.label,
            testResultListener.className,
            listOf(
              extensionSourceFrom(
                testResultListener.label.label,
                testResultListener.jarList.map { it.path },
                testResultListener.useSingleClassLoader,
              )
            ),
          )
          .let {
            it
              ?: throw IllegalStateException(
                "Cannot load test result listener: ${testResultListener.label.label}!"
              )
          }
          .also {
            val listenerConfig =
              TestResultListenerConfigImpl(
                config.firstEnvironmentOrEmpty,
                config.firstTestSetupOrEmpty,
                config.androidSdkOrEmpty,
                testResultListener.config,
                testResultListener.resource,
              )
            it.configure(
              ExtensionContextImpl(
                contextMap =
                  mutableMapOf(
                    Context.CONFIG_KEY to listenerConfig,
                    Context.COROUTINE_CONTEXT_KEY to
                      coroutineScope.newCoroutineContext(CoroutineName("TestResultListenerLoader")),
                    Context.EVENTS_KEY to events,
                  )
              )
            )
          }
      }
    }
  }

  /**
   * Class loads [TestResultListener] specified in the [RunnerConfig]. Throws if invalid proto is
   * found or fails to class load.
   */
  fun loadAndConfigureListeners(coroutineScope: CoroutineScope): List<TestResultListener> =
    loadAndConfigureListenersInConfig(runnerConfig, events, coroutineScope)
}
