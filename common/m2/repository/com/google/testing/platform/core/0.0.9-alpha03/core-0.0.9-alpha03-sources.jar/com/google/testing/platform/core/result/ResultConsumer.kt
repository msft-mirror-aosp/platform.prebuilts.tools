/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.result

import com.google.testing.platform.api.result.TestResultPublisher

/**
 * Responsible for consuming the output of an [Executor]'s test results and emitting them back
 * to any registered [TestResultPublisher]s as [TestResult] and [TestSuiteResult] protos.
 */
interface ResultConsumer {
  /**
   * Registers a [TestResultPublisher] to receive updates.
   *
   * @param testResultPublisher the [TestResultPublisher] to register to the internal EventBus
   */
  fun register(testResultPublisher: TestResultPublisher)

  /**
   * Unregisters a [TestResultPublisher] from receiving updates from this [ResultConsumer].
   *
   * @param testResultPublisher the [TestResultPublisher] to unregister
   */
  fun unregister(testResultPublisher: TestResultPublisher)
}
