/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.error.config

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.ErrorConfigProto.ErrorConfig
import kotlin.jvm.JvmStatic

/**
 * A class that takes Throwables from UTP/plugins and appends help text to its message, based on the
 * error configuration mapping defined in the error_message_updater proto.
 */
@ThreadSafe
class ErrorMessageUpdater(private val errorConfig: ErrorConfig) : ErrorUpdater {

  companion object {
    @JvmStatic val logger = getLogger()
  }

  /**
   * Updates the [throwable] according to the error configuration mapping.
   *
   * If any entry in the error map matches the [throwable], it will append additional error message
   * configured to [throwable] and returns. For throwables which have causes or nested causes, if
   * there are multiple matches, the deepest cause wins (as we believe it's closest to the root
   * cause).
   */
  override fun updateInfo(throwable: Throwable): Throwable {
    if (throwable !is UtpException) {
      return throwable
    }

    val deepestHelpText = findDeepestMatchingErrorConfigText(throwable)
    if (deepestHelpText == null) {
      return throwable
    }

    return throwable.copy(deepestHelpText)
  }

  private fun findDeepestMatchingErrorConfigText(throwable: Throwable?): String? {
    if (throwable == null) {
      return null
    }

    var deepestHelpText = findDeepestMatchingErrorConfigText(throwable.cause)
    if (deepestHelpText != null) {
      return deepestHelpText
    }

    if (throwable !is UtpException) {
      return null
    }

    return buildString {
      for (mapping in errorConfig.errorMessageUpdaterConfig.errorSummaryMappingList) {
        if (
          throwable.errorSummary.errorCode == mapping.errorCode &&
            throwable.errorSummary.namespace == mapping.errorNamespace
        ) {
          appendLine(mapping.additionalErrorMessage)
        }
      }
    }
  }
}
