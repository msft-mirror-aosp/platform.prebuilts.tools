/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.context

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.context.Context
import java.util.Collections

@ThreadSafe
class GlobalContextImpl(contextMap: Map<String, Any?> = mapOf()) : Context {
  val contextMap: MutableMap<String, Any?> = Collections.synchronizedMap(contextMap.toMutableMap())

  override fun get(key: String): Any? = contextMap[key]
}
