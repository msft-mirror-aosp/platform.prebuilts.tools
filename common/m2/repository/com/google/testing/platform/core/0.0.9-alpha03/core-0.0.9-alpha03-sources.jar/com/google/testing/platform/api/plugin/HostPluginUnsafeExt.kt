package com.google.testing.platform.api.plugin

import com.google.testing.platform.api.event.Events

const val CLEAR_PLATFORM_ERRORS_EVENT = "ClearPlatformErrorsEvent"

/**
 * Special event that can be sent by a plugin to indicate that all previous {@link PlatformError}s
 * raised by the platform are to be ignored.
 *
 * Use with extreme caution.
 */
fun Events.sendClearPlatformErrorsEvent() =
  this.send(CLEAR_PLATFORM_ERRORS_EVENT, "marker".toByteArray())

/**
 * Returns a list of the requests sent by a plugin to clear the current list of errors raised by the
 * platform.
 *
 * Note that when a plugin is actively in use during the testing lifecycle, this list is cleared by
 * the platform after every invocation of afterAll; this method cannot be used by a plugin to
 * retrieve errors thrown in a previous plugin.
 */
fun Events.getClearPlatformErrorsEvent() = this.get(CLEAR_PLATFORM_ERRORS_EVENT)
