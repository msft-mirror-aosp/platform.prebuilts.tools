package com.google.testing.platform.config;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata("com.google.testing.platform.config.inject.RawArgs")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class CommandLineArgs_Factory implements Factory<CommandLineArgs> {
  private final Provider<String[]> rawArgsProvider;

  public CommandLineArgs_Factory(Provider<String[]> rawArgsProvider) {
    this.rawArgsProvider = rawArgsProvider;
  }

  @Override
  public CommandLineArgs get() {
    return newInstance(rawArgsProvider.get());
  }

  public static CommandLineArgs_Factory create(Provider<String[]> rawArgsProvider) {
    return new CommandLineArgs_Factory(rawArgsProvider);
  }

  public static CommandLineArgs newInstance(String[] rawArgs) {
    return new CommandLineArgs(rawArgs);
  }
}
