/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.service.inject

import com.google.testing.platform.inject.DaggerRunnerComponent
import com.google.testing.platform.inject.RunnerComponent
import com.google.testing.platform.service.RunnerManager
import com.google.testing.platform.service.manager.RunnerManagerImpl
import dagger.Module
import dagger.Provides
import kotlinx.coroutines.CoroutineScope

@Module
class RunnerServiceModule {
  @Provides
  fun provideRunnerManager(rootCoroutineScope: CoroutineScope): RunnerManager =
    RunnerManagerImpl(parentScope = rootCoroutineScope)

  @Provides
  fun provideRunnerComponentBuilder(): RunnerComponent.Builder = DaggerRunnerComponent.builder()
}
