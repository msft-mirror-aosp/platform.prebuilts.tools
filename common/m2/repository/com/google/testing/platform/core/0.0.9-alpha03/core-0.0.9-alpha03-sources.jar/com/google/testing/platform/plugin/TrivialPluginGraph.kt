/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.testing.platform.api.cancel.PluginCancellationContext
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.events
import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.core.context.ExtensionContextImpl

/** A trivial graph that simply flattens a set. */
class TrivialPluginGraph(pluginSet: Set<HostPlugin>) : PluginGraph {
  val plugins = pluginSet.toList()

  companion object {
    private val reversed = listOf("afterEach", "afterAll")
  }

  override fun order(context: Context, method: String): Sequence<HostPlugin> {
    if (reversed.contains(method)) {
      return plugins.reversed().asSequence()
    } else {
      return plugins.asSequence()
    }
  }

  override fun customContext(
    parentContext: Context,
    configuration: Any,
    pluginCancellationContext: PluginCancellationContext,
    hostPlugin: HostPlugin
  ) =
    ExtensionContextImpl(
      parentContext = parentContext,
      contextMap =
        mutableMapOf(
          Context.CANCEL_KEY to pluginCancellationContext,
          Context.CONFIG_KEY to configuration,
          Context.EVENTS_KEY to parentContext.events,
        ),
    )
}
