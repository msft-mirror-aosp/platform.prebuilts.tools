/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform

import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.core.error.ErrorType.ASSET
import com.google.testing.platform.core.error.ErrorType.CONFIG
import com.google.testing.platform.core.error.ErrorType.INFRA
import com.google.testing.platform.core.error.ErrorType.TEST
import com.google.testing.platform.core.error.ErrorType.UNDERLYING_TOOL
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.executor.Executor
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.config.deviceId
import com.google.testing.platform.proto.api.core.PlatformErrorProto.PlatformError
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.ERROR
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.FAILED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.IGNORED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.PASSED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.SKIPPED
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import com.google.testing.platform.proto.api.core.testSuiteMetaData
import java.util.logging.Level
import javax.inject.Inject

/**
 * The RunnerImpl wraps the executor with all its dependencies. It performs the main high-level flow
 * that is common to all environments.
 */
class RunnerImpl
@Inject
constructor(
  private val config: RunnerConfig,
  private val executor: Executor,
  private val testResultPublisher: TestResultPublisher,
  private val errorUpdater: ErrorUpdater,
) : Runner {
  companion object {
    private const val PASSED_EXIT_CODE = 0
    private const val TEST_FAILED_EXIT_CODE = 1
    private const val UTP_FAILURE_EXIT_CODE = 2

    // Don't make this private: it is used by main.
    @JvmStatic val logger = getLogger()

    /**
     * Generates the UTP exit code based on the [TestSuiteResult]s produced.
     *
     * UTP_FAILURE takes precedence; otherwise, it returns the first nonzero exit code.
     */
    private fun generateExitCode(results: List<TestSuiteResult>): Int {
      var exitCode = 0
      for (suite in results) {
        if (suite.isPlatformError()) return UTP_FAILURE_EXIT_CODE
        if (exitCode == 0) exitCode = suite.getTestExitCode()
      }
      return exitCode
    }

    private val PLATFORM_FAILURES = setOf(INFRA.name, UNDERLYING_TOOL.name)
    private val USER_FAILURES = setOf(TEST.name, CONFIG.name, ASSET.name)

    private fun TestSuiteResult.isPlatformError(): Boolean {
      if (!this.hasPlatformError()) return false
      return this.platformError.errorsList.any {
        it.summary.errorClassification in PLATFORM_FAILURES
      }
    }

    private fun PlatformError.areAllTestErrorType(): Boolean =
      if (this.errorsList.isEmpty()) {
        false
      } else {
        this.errorsList.all { it.summary.errorClassification in USER_FAILURES }
      }

    /** Utility function to map [TestStatus] to an exit code. */
    private fun TestSuiteResult.getTestExitCode() =
      when (this.testStatus) {
        PASSED,
        SKIPPED,
        IGNORED -> PASSED_EXIT_CODE
        FAILED -> TEST_FAILED_EXIT_CODE
        ERROR ->
          if (this.platformError.areAllTestErrorType()) TEST_FAILED_EXIT_CODE
          else UTP_FAILURE_EXIT_CODE
        else -> UTP_FAILURE_EXIT_CODE
      }

    /** Utility function to print a user friendly [TestResult] message. */
    private fun summarizeAndLogTestResult(result: TestResult) {
      val pkg = result.testCase.testPackage
      val clazz = result.testCase.testClass
      val method = result.testCase.testMethod
      val status = result.testStatus.toString()
      val message =
        """
      |Execute $pkg.$clazz.$method: $status
      |${if (result.hasError()) "${result.error.errorType}: ${result.error.errorMessage}" else ""}
      |${result.error.stackTrace}
      """
          .trimMargin()
          .trimEnd()
      if (result.testStatus in setOf(PASSED, IGNORED, SKIPPED)) {
        logger.info(message)
      } else {
        logger.severe(message)
      }
    }
  }

  override fun run(): Int {
    check(config.deviceList.isNotEmpty()) { "UTP cannot run without devices" }
    return try {
      executor.configure(config)
      val testSuiteResults = executor.execute(testResultPublisher)
      for (suite in testSuiteResults) {
        // If this is a multi-device test, separate each test suite in the summaries.
        if (testSuiteResults.size > 1) {
          logger.info("=== ${suite.deviceName()}: ${suite.testSuiteMetaData.testSuiteName} ===")
        }
        for (result in suite.testResultList) {
          summarizeAndLogTestResult(result)
        }
      }
      generateExitCode(testSuiteResults)
    } catch (throwable: Throwable) {
      val updatedThrowable = errorUpdater.updateInfo(throwable)
      logger.log(Level.SEVERE, "Test execution failed with fatal error!", updatedThrowable)
      // Test suite status is the responsibility of the TestResultPublisher.
      val testSuiteId = testSuiteMetaData { device = config.deviceList.first().deviceId }
      testResultPublisher.failTestSuite(testSuiteId, updatedThrowable)
      testResultPublisher.afterTestSuite(testSuiteId)
      generateExitCode(testResultPublisher.publish())
    }
  }

  override fun cancel(aborted: Boolean) = executor.cancel(aborted)
}

private fun TestSuiteResult.deviceName(): String {
  if (testSuiteMetaData.device.friendlyName.isNullOrEmpty()) return testSuiteMetaData.device.id
  return testSuiteMetaData.device.friendlyName
}
