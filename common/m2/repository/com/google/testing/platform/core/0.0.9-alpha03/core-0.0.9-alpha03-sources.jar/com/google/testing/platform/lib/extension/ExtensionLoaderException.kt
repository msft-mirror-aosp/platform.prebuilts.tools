/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.extension

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.UtpException

/** Exception representing any problems that occurred during extension loading. */
class ExtensionLoaderException(
  override val errorSummary: ErrorSummary,
  override val message: String,
  override val cause: Throwable? = null
) : UtpException(errorSummary, message, cause)
