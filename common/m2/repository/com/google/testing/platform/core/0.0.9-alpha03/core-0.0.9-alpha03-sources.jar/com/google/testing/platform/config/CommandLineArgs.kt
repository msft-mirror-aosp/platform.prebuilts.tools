/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.testing.platform.config.inject.RawArgs
import javax.inject.Inject

/**
 * Parses the command-line flags and returns them as a list of Arg objects.
 *
 * Syntax examples:
 * --flag=value
 * --namespace.flag=value
 * --namespace.flag_snake_case=value
 *
 * A flag can optionally also specify a namespace for the flag name. This
 * allows different components/plugins to segregate their flags to avoid
 * global flag name collision.
 *
 * If the flag name contains '.' and/or '_':
 * 1. The '.' character is used to optionally provide a namespace prefix before the flag name
 * 2. The '_' character is just removed and the name is converted to camelCase, for example:
 * the flag "--main.log_level=1" will provide Config value for namespace "main"
 * and property name "logLevel".
 */
class CommandLineArgs @Inject constructor(@RawArgs rawArgs: Array<String>) {

  val args: List<Arg> = rawArgs
    .filter { it.startsWith("-") && it.contains('=') }
    .map { Arg.from(it) }

  /**
   * Returns the value specified on the command-line for the given config setting.
   *
   * @param key The config setting name
   * @param namespace The config settings namespace that groups a related set of settings together
   * @return String or null
   */
  fun getOrNull(key: String, namespace: String = ""): String? {
    val allMatches = args.filter {
      it.key == key && (it.namespace.isEmpty() || it.namespace == namespace)
    }
    if (allMatches.isEmpty()) {
      return null
    }
    val exactMatches = allMatches.filter { it.namespace == namespace }
    if (exactMatches.isNotEmpty()) {
      return exactMatches.first().value
    }
    return allMatches.first().value
  }

  data class Arg(val key: String, val value: String, val namespace: String = "") {
    companion object {
      fun from(arg: String): Arg {
        val re = Regex("--?(\\w+(?=[.]))?([^=]+)=(.*)")
        val matchResult = re.find(arg)
        val (namespace, flagName, value) = matchResult!!.destructured
        val name = toCamelCase(flagName)
        return Arg(name, value, namespace)
      }

      private fun toCamelCase(snakeCase: String) =
        snakeCase
          .split('_', '.')
          .filter { it.isNotEmpty() }
          .mapIndexed { index, it ->
            when {
              index == 0 -> it
              it.length == 1 -> it.toUpperCase()
              else -> it[0].toUpperCase() + it.substring(1)
            }
          }
          .joinToString("")
    }
  }
}
