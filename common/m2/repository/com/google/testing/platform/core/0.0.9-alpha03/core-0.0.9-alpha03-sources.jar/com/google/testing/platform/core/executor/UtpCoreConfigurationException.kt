/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.executor

import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.UtpException

/** Exception to throw whenever [Executor] runs into an error. */
class UtpCoreConfigurationException(message: String, throwable: Throwable?) :
  UtpException(UtpCoreErrorSummary.EXTENSION_CONFIGURATION_FAILED, message, throwable)

/**
 * Invokes the block with `this` as a receiver, catches all configuration exceptions wraps them in a
 * [UtpCoreConfigurationException]
 *
 * @param block lambda function that performs configuration work
 * @throws UtpCoreConfigurationException if an error occurred during block invocation
 */
inline fun <reified T> T.configureOrThrow(block: T.() -> Unit) {
  try {
    block(this)
  } catch (throwable: Throwable) {
    if (throwable !is UtpException) {
      throw UtpCoreConfigurationException(
        "Error during configuration phase for: ${T::class.java.simpleName}",
        throwable
      )
    } else {
      throw throwable
    }
  }
}
