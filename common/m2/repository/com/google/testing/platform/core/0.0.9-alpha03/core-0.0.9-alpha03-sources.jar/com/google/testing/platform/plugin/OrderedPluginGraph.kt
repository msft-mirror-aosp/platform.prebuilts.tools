/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.testing.platform.api.cancel.PluginCancellationContext
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.events
import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.event.ExtensionEventsProxy
import com.google.testing.platform.core.event.PhaseRequirements
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.plugin.annotations.OrderExpects
import com.google.testing.platform.plugin.annotations.OrderProvides
import com.google.testing.platform.proto.api.core.ErrorProto
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.plugin.OrderProto
import kotlin.random.Random
import kotlin.reflect.KAnnotatedElement
import kotlin.reflect.KClass
import kotlin.reflect.KProperty
import kotlin.reflect.full.memberFunctions
import kotlin.reflect.full.memberProperties

// Since HostPlugins may not come from the same class loader, we track protobuf classes by
// full name rather than KClass.

/**
 * A node in the graph of HostPlugins.
 *
 * Arguments:
 *
 * @param plugin: The HostPlugin.
 * @param needs: Full names of proto messages required by the plugin.
 * @param wants: Full names of optional proto messages for the plugin.
 * @param provides: Full names of proto messages provided by the plugin, and if it is strictly
 *   required there be a consumer for that message.
 */
private data class GraphNode(
  val plugin: HostPlugin,
  val needs: Set<String>,
  val wants: Set<String>,
  val provides: Map<String, Boolean>,
) {
  fun kind() = plugin::class.java.name!!
}

// TODO(https://youtrack.jetbrains.com/issue/KT-39369): once the bug is fixed, mark the
// annotation library as "neverlink = 1" and get rid of this.

/** Get a property from an Annotation. */
inline fun <reified R : Any> Annotation.get(name: String): R {
  val candidate: KProperty<*> = this::class.memberProperties.filter { it.name == name }.first()
  @Suppress("UNCHECKED_CAST") val property = candidate as KProperty<R>
  val result = property.getter.call(this)
  // When R == KClass<*>, result can be Class<*>!
  if (R::class == KClass::class && result is Class<*>) {
    return result.kotlin as R
  }
  return result
}

/** Work around the annotation class coming from a different class loader. */
fun KAnnotatedElement.findOrderExpects(): List<OrderExpects> =
  this.annotations
    .filter { it.annotationClass.java.name.equals(OrderExpects::class.java.name) }
    .map { anno -> OrderExpects(message = anno.get("message"), required = anno.get("required")) }

private val IMPLICIT_PROVIDES =
  setOf(
    Artifact::class,
    ErrorProto.Error::class,
    Issue::class,
    TestResult::class,
    TestStatus::class,
  )

/** Work around the annotation class coming from a different class loader. */
fun KAnnotatedElement.findOrderProvides(): List<OrderProvides> =
  this.annotations
    .filter { it.annotationClass.java.name.equals(OrderProvides::class.java.name) }
    .map { anno -> OrderProvides(message = anno.get("message"), strict = anno.get("strict")) }
    .onEach { provides ->
      if (IMPLICIT_PROVIDES.contains(provides.message)) {
        throw IllegalArgumentException(
          """
          Events of type ${provides.message} are implicitly assumed to be potentially sent by every
          | plugin in the corresponding phase and thus should not be specified via @OrderProvides to
          | avoid confusing them with other events.
          """
            .trimMargin()
        )
      }
    }

/** Reads the annotations from a set of HostPlugins and assembles them in a graph. */
class OrderedPluginGraph(plugins: Set<HostPlugin>, randomSeed: Long) : PluginGraph {
  companion object {
    @JvmStatic private val logger = getLogger()

    // These annotations only exist to fine-tune ordering of execution; the events are not
    // sent or received, and do not need to be verified.
    private val DO_NOT_VERIFY =
      setOf(OrderProto.Early::class.java.name, OrderProto.Tardy::class.java.name)
  }

  private val nodesByMethod: Map<String, Set<GraphNode>>
  private val random: Random

  init {
    random = Random(randomSeed)

    logger.info(
      "Creating plugin graph for ${plugins.map { it::class.java.name }.joinToString(", ")}"
    )

    val validMethods = HostPlugin::class.memberFunctions.map { it.name }.toSet()
    val nodesByMethodBuilder = mutableMapOf<String, MutableSet<GraphNode>>()
    plugins.forEach { plugin ->
      // Check each HostPlugin-descended method for OrderExpects and OrderProvides
      // annotations.
      plugin::class
        .memberFunctions
        .filter { validMethods.contains(it.name) }
        .forEach { function ->
          val needs = mutableSetOf<String>()
          val wants = mutableSetOf<String>()
          val provides = mutableMapOf<String, Boolean>()
          function.findOrderExpects().forEach { anno ->
            if (anno.required) {
              needs.add(anno.message.java.name!!)
            } else {
              wants.add(anno.message.java.name!!)
            }
          }
          function.findOrderProvides().forEach { anno ->
            provides[anno.message.java.name!!] = anno.strict
          }
          nodesByMethodBuilder
            .getOrPut(function.name) { mutableSetOf<GraphNode>() }
            .add(GraphNode(plugin, needs, wants, provides))
        }
    }

    nodesByMethod = nodesByMethodBuilder.toMap()
  }

  /** Processes a set of GraphNodes using a variation of Kahn's algorithm. */
  private inner class PhaseBuilder(val context: Context, configuredNodes: Set<GraphNode>) {
    // Set of nodes that should dwindle to zero as they find their place in the execution order.
    var nodes = configuredNodes.toMutableSet()
    // Qualified names of proto messages provided by the time we reach the latest phase.
    val messages = mutableSetOf<String>()
    // Sequence of phases.
    val phases = mutableListOf<Set<HostPlugin>>()
    // Qualified names of all proto messages that will ever be consumed by these HostPlugins.
    val allConsumers: Set<String>
    // Qualified names of all proto messages that will ever be provided by these HostPlugins.
    val allProviders: Set<String>
    // Qualified names of all proto messages in allConsumers that are already available as
    // events.
    val alreadyProvided: Set<String>

    init {
      allConsumers = nodes.map { it.needs union it.wants }.flatten().toSet()
      allProviders = nodes.map { it.provides.keys }.flatten().toSet()
      alreadyProvided = allConsumers.filter { context.events.get(it).isNotEmpty() }.toSet()

      nodes.forEach { node ->
        node.provides.forEach {
          if (it.value && !allConsumers.contains(it.key)) {
            throw IllegalArgumentException(
              "Unable to construct HostPlugin graph: ${node.kind()} requires a consumer for ${it.key}"
            )
          }
        }
      }

      messages.addAll(alreadyProvided)
    }

    /** Returns the canonical ordered list of plugins for this method. */
    fun ordered(): Sequence<HostPlugin> {
      val result = mutableListOf<HostPlugin>()
      phases.forEach { result.addAll(it.shuffled(random)) }
      return result.asSequence()
    }

    /** True if the algorithm has run to completion. */
    fun isComplete() = nodes.isEmpty()

    /** Names of nodes not yet processed. */
    fun remaining() = nodes.map { it.kind() }

    /** Determines if a node is ready to be added to the current phase. */
    fun ready(node: GraphNode): Boolean {
      // Nodes with no needs are picked up by the seeding phase. Don't pick them up early.
      if (node.needs.isEmpty() && node.wants.isEmpty()) return false

      // If a required message is not available, the node is not ready.
      if (!messages.containsAll(node.needs)) return false

      // All needs are met.

      // Excluding messages that are not provided by this graph, have all the wants of this
      // plugin been met?
      if (messages.containsAll(node.wants intersect (allProviders union alreadyProvided)))
        return true

      return false
    }

    /** Essentially "removeAll, but it returns the removed elements". */
    fun <T> MutableSet<T>.extractAll(predicate: (T) -> Boolean): MutableSet<T> {
      val result = mutableSetOf<T>()
      val iterator = this.iterator()
      while (iterator.hasNext()) {
        val e = iterator.next()
        if (predicate(e)) {
          result.add(e)
          iterator.remove()
        }
      }
      return result
    }

    /** Process all nodes that match the seeds. */
    fun processNodes(seed: List<KClass<*>>, method: String) {
      val seedNames = seed.map { it.java.name!! }.toSet()
      logger.fine("$method: processing nodes for ${seedNames.joinToString(", ")}")
      messages.addAll(seedNames)

      val availableInPhase = messages union allProviders

      // Process all nodes that want or need the seed inputs, excluding the wants that cannot be
      // fulfilled.
      var phase =
        nodes.extractAll {
          val inputs = (it.needs union (it.wants intersect availableInPhase))
          when {
            // If no expectations are expressed, put it in the middle of the pack.
            inputs.isEmpty() && seed.isEmpty() -> true
            // When expectations are expressed, meet them.
            inputs.isNotEmpty() && messages.containsAll(inputs) -> true
            else -> false
          }
        }
      if (phase.isNotEmpty()) {
        logger.fine("initial phase is ${phase.map { it.kind() }.joinToString(", ")}")
        messages.addAll(phase.map { it.provides.keys }.flatten())
        phases.add(phase.map { it.plugin }.toSet())
      }

      // Iterate until no nodes are ready.
      while (!phase.isEmpty()) {
        phase = nodes.extractAll { ready(it) }
        if (phase.isNotEmpty()) {
          logger.fine("increment: ${phase.map { it.kind() }.joinToString(", ")}")
          messages.addAll(phase.map { it.provides.keys }.flatten())
          phases.add(phase.map { it.plugin }.toSet())
        }
      }
    }
  }

  override fun order(context: Context, method: String): Sequence<HostPlugin> {
    if (nodesByMethod.isEmpty()) return emptySequence()
    if (!nodesByMethod.contains(method)) {
      throw IllegalArgumentException("$method is not a HostPlugin method")
    }
    val builder = PhaseBuilder(context, nodesByMethod[method]!!)

    builder.processNodes(listOf(OrderProto.Early::class), method)
    builder.processNodes(listOf<KClass<*>>(), method)
    builder.processNodes(listOf(OrderProto.Tardy::class), method)

    if (!builder.isComplete()) {
      // TODO(b/207008438): Explain the problem to the user.
      throw IllegalArgumentException(
        "Unable to construct HostPlugin graph for $method: " +
          "${builder.remaining().joinToString(", ")} requirements could not be met"
      )
    }
    return builder.ordered()
  }

  override fun customContext(
    parentContext: Context,
    configuration: Any,
    pluginCancellationContext: PluginCancellationContext,
    hostPlugin: HostPlugin,
  ): Context {
    val phaseRequirements = mutableMapOf<String, PhaseRequirements>()
    nodesByMethod.forEach { entry ->
      val phase = entry.key
      entry.value.forEach { graphNode ->
        if (graphNode.plugin == hostPlugin) {
          phaseRequirements[phase] =
            PhaseRequirements(
              graphNode.needs.minus(DO_NOT_VERIFY),
              graphNode.wants.minus(DO_NOT_VERIFY),
              graphNode.provides.keys,
            )
        }
      }
    }
    val proxy =
      ExtensionEventsProxy(hostPlugin.javaClass.name, phaseRequirements, parentContext.events)
    return ExtensionContextImpl(
      parentContext = parentContext,
      contextMap =
        mutableMapOf(
          Context.CANCEL_KEY to pluginCancellationContext,
          Context.CONFIG_KEY to configuration,
          Context.EVENTS_KEY to proxy,
        ),
    )
  }
}
