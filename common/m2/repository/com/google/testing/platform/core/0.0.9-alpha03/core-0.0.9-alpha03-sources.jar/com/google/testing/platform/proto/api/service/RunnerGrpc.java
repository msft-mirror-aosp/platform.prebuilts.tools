package com.google.testing.platform.proto.api.service;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: proto/api/service/runner_service.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class RunnerGrpc {

  private RunnerGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.testing.platform.runner.service.proto.Runner";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest,
      com.google.rpc.Status> getRunMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Run",
      requestType = com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest.class,
      responseType = com.google.rpc.Status.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest,
      com.google.rpc.Status> getRunMethod() {
    io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest, com.google.rpc.Status> getRunMethod;
    if ((getRunMethod = RunnerGrpc.getRunMethod) == null) {
      synchronized (RunnerGrpc.class) {
        if ((getRunMethod = RunnerGrpc.getRunMethod) == null) {
          RunnerGrpc.getRunMethod = getRunMethod =
              io.grpc.MethodDescriptor.<com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest, com.google.rpc.Status>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Run"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.rpc.Status.getDefaultInstance()))
              .setSchemaDescriptor(new RunnerMethodDescriptorSupplier("Run"))
              .build();
        }
      }
    }
    return getRunMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest,
      com.google.rpc.Status> getCancelMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "Cancel",
      requestType = com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest.class,
      responseType = com.google.rpc.Status.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest,
      com.google.rpc.Status> getCancelMethod() {
    io.grpc.MethodDescriptor<com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest, com.google.rpc.Status> getCancelMethod;
    if ((getCancelMethod = RunnerGrpc.getCancelMethod) == null) {
      synchronized (RunnerGrpc.class) {
        if ((getCancelMethod = RunnerGrpc.getCancelMethod) == null) {
          RunnerGrpc.getCancelMethod = getCancelMethod =
              io.grpc.MethodDescriptor.<com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest, com.google.rpc.Status>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "Cancel"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.rpc.Status.getDefaultInstance()))
              .setSchemaDescriptor(new RunnerMethodDescriptorSupplier("Cancel"))
              .build();
        }
      }
    }
    return getCancelMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static RunnerStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<RunnerStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<RunnerStub>() {
        @java.lang.Override
        public RunnerStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new RunnerStub(channel, callOptions);
        }
      };
    return RunnerStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static RunnerBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<RunnerBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<RunnerBlockingStub>() {
        @java.lang.Override
        public RunnerBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new RunnerBlockingStub(channel, callOptions);
        }
      };
    return RunnerBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static RunnerFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<RunnerFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<RunnerFutureStub>() {
        @java.lang.Override
        public RunnerFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new RunnerFutureStub(channel, callOptions);
        }
      };
    return RunnerFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     */
    default void run(com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest request,
        io.grpc.stub.StreamObserver<com.google.rpc.Status> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getRunMethod(), responseObserver);
    }

    /**
     */
    default void cancel(com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest request,
        io.grpc.stub.StreamObserver<com.google.rpc.Status> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCancelMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service Runner.
   */
  public static abstract class RunnerImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return RunnerGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service Runner.
   */
  public static final class RunnerStub
      extends io.grpc.stub.AbstractAsyncStub<RunnerStub> {
    private RunnerStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected RunnerStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new RunnerStub(channel, callOptions);
    }

    /**
     */
    public void run(com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest request,
        io.grpc.stub.StreamObserver<com.google.rpc.Status> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getRunMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void cancel(com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest request,
        io.grpc.stub.StreamObserver<com.google.rpc.Status> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCancelMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service Runner.
   */
  public static final class RunnerBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<RunnerBlockingStub> {
    private RunnerBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected RunnerBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new RunnerBlockingStub(channel, callOptions);
    }

    /**
     */
    public com.google.rpc.Status run(com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getRunMethod(), getCallOptions(), request);
    }

    /**
     */
    public com.google.rpc.Status cancel(com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCancelMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service Runner.
   */
  public static final class RunnerFutureStub
      extends io.grpc.stub.AbstractFutureStub<RunnerFutureStub> {
    private RunnerFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected RunnerFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new RunnerFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.rpc.Status> run(
        com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getRunMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.rpc.Status> cancel(
        com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCancelMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_RUN = 0;
  private static final int METHODID_CANCEL = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_RUN:
          serviceImpl.run((com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest) request,
              (io.grpc.stub.StreamObserver<com.google.rpc.Status>) responseObserver);
          break;
        case METHODID_CANCEL:
          serviceImpl.cancel((com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest) request,
              (io.grpc.stub.StreamObserver<com.google.rpc.Status>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getRunMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest,
              com.google.rpc.Status>(
                service, METHODID_RUN)))
        .addMethod(
          getCancelMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest,
              com.google.rpc.Status>(
                service, METHODID_CANCEL)))
        .build();
  }

  private static abstract class RunnerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    RunnerBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.testing.platform.proto.api.service.RunnerServiceProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Runner");
    }
  }

  private static final class RunnerFileDescriptorSupplier
      extends RunnerBaseDescriptorSupplier {
    RunnerFileDescriptorSupplier() {}
  }

  private static final class RunnerMethodDescriptorSupplier
      extends RunnerBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    RunnerMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (RunnerGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new RunnerFileDescriptorSupplier())
              .addMethod(getRunMethod())
              .addMethod(getCancelMethod())
              .build();
        }
      }
    }
    return result;
  }
}
