/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.protobuf.Message
import com.google.testing.platform.config.inject.BaseMessageProvider
import javax.inject.Inject
import javax.inject.Provider

/**
 * Provides the [T] : [Message] from a set of [ConfigProvider]s.
 *
 * If more than one configuration are provided, this class will attempt to merge the
 * configurations together according to the proto spec defined here <a
 *     href="https://developers.google.com/protocol-buffers/docs/reference/java/com/google/protobuf/Message.Builder#mergeFrom-com.google.protobuf.Message-">
 *
 * If no configs provided or all configs are filtered out this class will throw an
 * [IllegalArgumentException]
 */
class ProtoConfigProvider<T : Message> @Inject constructor(
  private val configProviders: Set<@JvmSuppressWildcards ConfigProvider<T>>,
  @BaseMessageProvider val baseMessageProvider: Provider<T>
) : ConfigProvider<T> {

  override fun getConfig(): T {
    require(configProviders.isNotEmpty()) { "No config providers found." }
    val messageBuilder = baseMessageProvider.get().toBuilder()
    configProviders
      .filter { provider -> provider.hasConfig() }
      .apply {
        require(!isEmpty()) {
          "No configurations found in config providers. Please check file paths."
        }
      }
      .forEach { provider -> messageBuilder.mergeFrom(provider.getConfig()) }

    @Suppress("UNCHECKED_CAST")
    return messageBuilder.build() as T
  }

  override fun hasConfig(): Boolean = configProviders.any { provider -> provider.hasConfig() }
}
