/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.event

import com.google.testing.platform.api.event.EventException
import com.google.testing.platform.api.event.Events

data class PhaseRequirements(
  val needs: Set<String>,
  val wants: Set<String>,
  val provides: Set<String>,
) {
  fun checkForMissedProvides(provided: Set<String>): List<String> {
    return provides.filterNot { it in provided }
  }

  fun checkForMissedReads(reads: Set<String>): List<String> {
    return needs.filterNot { it in reads }
  }
}

class ExtensionEventsProxy(
  private val extensionName: String,
  private val phaseRequirements: Map<String, PhaseRequirements>, // key is phase name
  private val globalEvents: Events
) : MutableEvents {

  private val provided = mutableSetOf<String>()
  private val reads = mutableSetOf<String>()
  // The "current" variables are set during verification.
  private var currentPhase: PhaseRequirements? = null
  private var currentMaybeProvides = emptySet<String>()
  private var currentPhaseName = "(none)"

  override fun send(event: String, message: ByteArray) {
    val current = currentPhase // reassure the compiler this won't change
    if (current == null) throw AssertionError("Events must be sent within a verify() block")
    if (event !in current.provides.union(this.currentMaybeProvides)) {
      throw EventException(
        message =
          """Event error in $extensionName.$currentPhaseName
        |$extensionName is attempting to send the event: "$event" but does not declare this as an
        |event it can provide.
        |This can be resolved by doing one of the following:
        | 1. Add `@OrderProvides(message = $event::class)` to $extensionName.$currentPhaseName
        | 2. Do not send $event in $extensionName.$currentPhaseName""".trimMargin(),
        errorSummary = EventErrorSummary.PROVIDING_UNDECLARED_EVENT
      )
    }

    globalEvents.send(event, message)
    provided.add(event) // only mark an event as provided if it was successful
  }

  override fun get(event: String): List<ByteArray> {
    val current = currentPhase // reassure the compiler this won't change
    if (current == null) throw AssertionError("Events must be read within a verify() block")
    if (event !in current.needs && event !in current.wants) {
      throw EventException(
        message =
          """Event error in $extensionName.$currentPhaseName
        |$extensionName is attempting to read the event: "$event" but does not declare this as an
        |event it can read.
        |This can be resolved by doing one of the following:
        | 1. Add `@OrderExpects(message = $event::class)` to $extensionName.$currentPhaseName
        | 2. Do not read $event in $extensionName.$currentPhaseName""".trimMargin(),
        errorSummary = EventErrorSummary.READING_UNDECLARED_EVENT
      )
    }

    val ret = globalEvents.get(event)
    reads.add(event)
    return ret
  }

  /**
   * Verifies all events were sent/received based on this extension's contract.
   * @throws com.google.testing.platform.api.EventException if the contract was violated.
   */
  override fun <R> verify(circumstance: String, maybeProvides: Set<String>, block: () -> R): R {
    val current: PhaseRequirements? // reassure the compiler this won't change
    val result: R
    try {
      this.currentPhaseName = circumstance
      this.currentPhase = phaseRequirements[currentPhaseName]
      current = this.currentPhase
      this.currentMaybeProvides = maybeProvides
      result = block()
    } finally {
      this.currentMaybeProvides = emptySet()
      this.currentPhase = null
      this.currentPhaseName = "(none)"
    }
    if (current == null) return result
    val provideMisses =
      current.checkForMissedProvides(provided).filter { !maybeProvides.contains(it) }
    val needMisses = current.checkForMissedReads(reads)
    val errors = mutableListOf<EventException>()
    provideMisses.forEach {
      errors.add(
        EventException(
          message =
            """Error during: $extensionName.$circumstance
        |Event $it was not provided but was declared to be provided on method annotations.
        |Remove this annotation or guarantee that this even will be provided.""".trimMargin(),
          errorSummary = EventErrorSummary.NOT_PROVIDING_DECLARED_EVENTS
        )
      )
    }
    needMisses.forEach {
      errors.add(
        EventException(
          message =
            """Error during: $extensionName.$circumstance
        |Event $it is declared as a requirement but is not read.
        |Remove the event altogether, remove the strict requirement, or ensure this event is read.
        |""".trimMargin(),
          errorSummary = EventErrorSummary.FAILURE_TO_READ_EVENT
        )
      )
    }
    when {
      errors.size == 1 -> throw errors.first()
      errors.size > 1 -> {
        // build up an error containing all the other errors
        val first = errors.first()
        errors.forEachIndexed { i, err ->
          if (i != 0) {
            first.addSuppressed(err)
          }
        }
        throw first
      }
    }
    return result
  }

  override fun consume(event: String): List<ByteArray> {
    return if (this.globalEvents is MutableEvents) {
      this.globalEvents.consume(event)
    } else {
      emptyList()
    }
  }
}
