package com.google.testing.platform.main.inject;

import com.google.testing.platform.api.event.Events;
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext;
import com.google.testing.platform.proto.api.config.RunnerConfigProto;
import com.google.testing.platform.proto.api.service.ServerConfigProto;
import com.google.testing.platform.server.ServerStrategy;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata
@QualifierMetadata("com.google.testing.platform.core.event.inject.PrimaryEvents")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class MainModule_ProvidesServerStrategyFactory implements Factory<ServerStrategy> {
  private final MainModule module;

  private final Provider<ServerConfigProto.ServerConfig> serverConfigProvider;

  private final Provider<RunnerConfigProto.RunnerConfig> runnerConfigProvider;

  private final Provider<CoroutineScope> rootCoroutineScopeProvider;

  private final Provider<ProcessCancellationContext> cancellationContextProvider;

  private final Provider<Events> eventsProvider;

  public MainModule_ProvidesServerStrategyFactory(MainModule module,
      Provider<ServerConfigProto.ServerConfig> serverConfigProvider,
      Provider<RunnerConfigProto.RunnerConfig> runnerConfigProvider,
      Provider<CoroutineScope> rootCoroutineScopeProvider,
      Provider<ProcessCancellationContext> cancellationContextProvider,
      Provider<Events> eventsProvider) {
    this.module = module;
    this.serverConfigProvider = serverConfigProvider;
    this.runnerConfigProvider = runnerConfigProvider;
    this.rootCoroutineScopeProvider = rootCoroutineScopeProvider;
    this.cancellationContextProvider = cancellationContextProvider;
    this.eventsProvider = eventsProvider;
  }

  @Override
  public ServerStrategy get() {
    return providesServerStrategy(module, serverConfigProvider.get(), runnerConfigProvider.get(), rootCoroutineScopeProvider.get(), cancellationContextProvider.get(), eventsProvider.get());
  }

  public static MainModule_ProvidesServerStrategyFactory create(MainModule module,
      Provider<ServerConfigProto.ServerConfig> serverConfigProvider,
      Provider<RunnerConfigProto.RunnerConfig> runnerConfigProvider,
      Provider<CoroutineScope> rootCoroutineScopeProvider,
      Provider<ProcessCancellationContext> cancellationContextProvider,
      Provider<Events> eventsProvider) {
    return new MainModule_ProvidesServerStrategyFactory(module, serverConfigProvider, runnerConfigProvider, rootCoroutineScopeProvider, cancellationContextProvider, eventsProvider);
  }

  public static ServerStrategy providesServerStrategy(MainModule instance,
      ServerConfigProto.ServerConfig serverConfig, RunnerConfigProto.RunnerConfig runnerConfig,
      CoroutineScope rootCoroutineScope, ProcessCancellationContext cancellationContext,
      Events events) {
    return Preconditions.checkNotNullFromProvides(instance.providesServerStrategy(serverConfig, runnerConfig, rootCoroutineScope, cancellationContext, events));
  }
}
