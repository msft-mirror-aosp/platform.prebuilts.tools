/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.core.result.TestSuiteCreator
import com.google.testing.platform.core.result.TestSuiteCreatorFactory
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.ErrorDetailProto.ErrorDetail
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.util.Collections
import java.util.UUID
import javax.inject.Inject

/** Publishes test results to a [TestResultListener]. */
@ThreadSafe
class GlobalTestResultPublisher
@Inject
constructor(
  private val listener: TestResultListener,
  private val testSuiteCreatorFactory: TestSuiteCreatorFactory,
) : TestResultPublisher {
  /** [TestSuiteResult]s built from the published [TestResult]s. */
  private val workingDrafts = Collections.synchronizedMap(mutableMapOf<String, TestSuiteCreator>())
  private val finalDrafts = Collections.synchronizedMap(mutableMapOf<String, TestSuiteResult>())

  private fun guaranteeCreator(deviceId: String): TestSuiteCreator =
    synchronized(workingDrafts) {
      workingDrafts.getOrPut(deviceId) { testSuiteCreatorFactory.create() }
    }

  private fun getCreator(deviceId: String): TestSuiteCreator =
    workingDrafts.getOrElse(deviceId) {
      throw IllegalStateException(
        "You must call beforeTestSuite to initialize the TestResultPublisher"
      )
    }

  override fun beforeTestSuite(testSuite: TestSuiteMetaData) {
    // If a host plugin stalls in beforeAll, an interrupt can come in before the test driver has a
    // chance to call beforeTestSuite, so the test suite metadata can get added in failTestSuite!
    guaranteeCreator(testSuite.deviceId).addTestSuiteMetadata(testSuite)
    listener.beforeTestSuite(testSuite)
  }

  override fun beforeTest(testCase: TestCase) {
    listener.beforeTest(testCase)
  }

  override fun afterTest(testResult: TestResult) {
    if (getCreator(testResult.deviceId).addTestResult(testResult)) {
      // Only notify the listeners the first time a test result is set.
      listener.afterTest(testResult)
    }
  }

  override fun addTestSuiteArtifact(testSuite: TestSuiteMetaData, artifact: Artifact) {
    getCreator(testSuite.deviceId).addArtifact(artifact)
  }

  override fun addTestSuiteIssue(testSuite: TestSuiteMetaData, issue: Issue) {
    with(guaranteeCreator(testSuite.deviceId)) {
      addTestSuiteMetadata(testSuite)
      addIssue(issue)
    }
  }

  override fun failTestSuite(testSuite: TestSuiteMetaData, detail: ErrorDetail) {
    with(guaranteeCreator(testSuite.deviceId)) {
      addTestSuiteMetadata(testSuite)
      addError(detail)
    }
  }

  override fun failTestSuite(testSuite: TestSuiteMetaData, throwable: Throwable) {
    with(guaranteeCreator(testSuite.deviceId)) {
      addTestSuiteMetadata(testSuite)
      addError(throwable)
    }
  }

  override fun clearFailures(testSuite: TestSuiteMetaData) {
    getCreator(testSuite.deviceId).clearError()
  }

  override fun setTestSuiteStatus(testSuite: TestSuiteMetaData, status: TestStatus) {
    getCreator(testSuite.deviceId).setStatus(status)
  }

  override fun workingDraft(testSuite: TestSuiteMetaData): TestSuiteResult {
    return guaranteeCreator(testSuite.deviceId).buildTestSuiteResult(inProgress = true)
  }

  override fun afterTestSuite(testSuite: TestSuiteMetaData) {
    if (testSuite.deviceId in finalDrafts) {
      logger.warning("Replacing final draft of TestSuiteResult for ${testSuite.deviceId}!")
    }
    listener.afterTestSuite(
      getCreator(testSuite.deviceId).buildTestSuiteResult().also {
        finalDrafts[testSuite.deviceId] = it
      }
    )
  }

  override fun publish(): List<TestSuiteResult> {
    listener.afterAllTestSuites()
    return synchronized(finalDrafts) { finalDrafts.values.toList() }
  }

  companion object {
    val logger = getLogger()

    val MISSING_DEVICE_ID = UUID(0L, 0L).toString()

    private val TestResult.deviceId: String
      get() {
        if (hasTestCase() && testCase.hasDevice()) return testCase.device.id
        return MISSING_DEVICE_ID
      }

    private val TestSuiteMetaData.deviceId: String
      get() {
        if (hasDevice()) return device.id
        return MISSING_DEVICE_ID
      }
  }
}
