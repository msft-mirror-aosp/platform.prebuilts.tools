/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.testing.platform.config.v1.extension.firstEnvironmentOrEmpty
import com.google.testing.platform.config.v1.extension.outputDirOrDefault
import com.google.testing.platform.config.v1.extension.tmpDirOrDefault
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import java.io.File
import java.nio.file.FileAlreadyExistsException
import java.nio.file.Files
import java.nio.file.Paths
import javax.inject.Inject

/**
 * Environment-related configuration values from the [RunnerConfigProto].
 *
 * Proto: [com.google.testing.platform.proto.api.config.EnvironmentProto]
 */
data class Environment @Inject constructor(
  /** The directory for all test output artifacts including log files. */
  val outputDirectory: File,

  /** The directory for any temporary files needed during test execution. */
  val tempDirectory: File
) {

  private companion object {
    private const val DEFAULT_OUTPUT_DIRECTORY = "."
    // TODO(b/117176495): Don't hardcode OS-specifics
    private const val DEFAULT_TEMP_DIRECTORY = "/tmp"
  }

  object Creator {

    val default = Environment(
      createDirectories(DEFAULT_OUTPUT_DIRECTORY),
      createDirectories(DEFAULT_TEMP_DIRECTORY)
    )

    fun parseFrom(environmentProto: EnvironmentProto.Environment): Environment {
      val outputDirectory = environmentProto.outputDirOrDefault(DEFAULT_OUTPUT_DIRECTORY)
      val tempDirectory = environmentProto.tmpDirOrDefault(DEFAULT_TEMP_DIRECTORY)
      return Environment(createDirectories(outputDirectory), createDirectories(tempDirectory))
    }

    fun parseFrom(runnerConfig: RunnerConfig): Environment {
      return parseFrom(runnerConfig.firstEnvironmentOrEmpty)
    }

    private fun createDirectories(path: String): File {
      try {
        return Files.createDirectories(Paths.get(path)).toFile()
      } catch (e: FileAlreadyExistsException) { // Continue if directory already exists
        return Paths.get(path).toFile()
      } catch (e: Exception) {
        throw ConfigurationException("Cannot generate directories for path: $path", e)
      }
    }
  }
}
