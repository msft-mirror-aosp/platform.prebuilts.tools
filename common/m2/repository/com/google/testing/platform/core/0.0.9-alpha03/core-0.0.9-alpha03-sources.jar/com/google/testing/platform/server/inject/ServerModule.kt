/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server.inject

import com.google.testing.platform.proto.api.service.ServerConfigProto.ServerConfig
import com.google.testing.platform.server.ServerBuilderFactory
import dagger.Module
import dagger.Provides
import io.grpc.BindableService
import io.grpc.Server
import io.grpc.ServerBuilder

/**
 * Provides server and server registry.
 */
@Module
class ServerModule {
  @Provides
  fun provideServerBuilder(
    config: ServerConfig?,
    services: Set<@JvmSuppressWildcards BindableService>
  ): ServerBuilder<*>? = config?.let {
    ServerBuilderFactory.create(it, services)
  }

  @Provides
  fun provideServer(builder: ServerBuilder<*>?): Server? = builder?.build()
}
