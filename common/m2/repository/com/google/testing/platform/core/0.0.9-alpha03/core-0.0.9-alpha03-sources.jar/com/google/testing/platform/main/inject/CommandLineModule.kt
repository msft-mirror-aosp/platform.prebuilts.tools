/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.main.inject

import com.google.protobuf.Parser
import com.google.testing.platform.config.BinaryProtoConfigProvider
import com.google.testing.platform.config.CommandLineArgs
import com.google.testing.platform.config.ConfigProvider
import com.google.testing.platform.config.TextProtoConfigProvider
import com.google.testing.platform.config.inject.BaseMessageProvider
import com.google.testing.platform.config.inject.ConfigModule as RunnerConfigModule
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.service.ServerConfigProto.ServerConfig
import com.google.testing.platform.server.inject.ConfigModule as ServerConfigModule
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoSet
import javax.inject.Provider

/**
 * Module that specifies and parses [CommandLineArgs]. Contains all object creation logic based on
 * flags. Attach to root scope so all other modules have access.
 */
@Module(includes = [ServerConfigModule::class, RunnerConfigModule::class])
class CommandLineModule {
  companion object {
    const val DEFAULT_SERVER_PORT = 6060
    const val SET_DEFAULT = 0

    const val RUNNER_BINARY_PROTO = "protoConfig"
    const val RUNNER_TEXT_PROTO = "textProtoConfig"
    const val SERVER_BINARY_PROTO = "protoServerConfig"
    const val SERVER_TEXT_PROTO = "textProtoServerConfig"
    const val SERVER_PORT = "port"
  }

  @Provides
  @IntoSet
  fun providesBinaryProvider(
    args: CommandLineArgs,
    parser: Parser<RunnerConfig>
  ): ConfigProvider<RunnerConfig> = BinaryProtoConfigProvider(
    args.getOrNull(RUNNER_BINARY_PROTO) ?: "",
    parser
  )

  @Provides
  @IntoSet
  fun providesTextProvider(
    args: CommandLineArgs,
    @BaseMessageProvider provider: Provider<RunnerConfig>
  ): ConfigProvider<RunnerConfig> = TextProtoConfigProvider(
    args.getOrNull(RUNNER_TEXT_PROTO) ?: "",
    provider
  )

  @Provides
  @IntoSet
  fun providesServerTextProtoProvider(
    args: CommandLineArgs,
    @BaseMessageProvider provider: Provider<ServerConfig>
  ): ConfigProvider<ServerConfig> = TextProtoConfigProvider(
    args.getOrNull(SERVER_TEXT_PROTO) ?: "",
    provider
  )

  @Provides
  @IntoSet
  fun providesServerBinaryProtoProvider(
    args: CommandLineArgs,
    parser: Parser<ServerConfig>
  ): ConfigProvider<ServerConfig> = BinaryProtoConfigProvider(
    args.getOrNull(SERVER_BINARY_PROTO) ?: "",
    parser
  )

  /**
   * Provides server config. If the --port flag is present, that port overrides the config file.
   * If the config file does not specify a port [DEFAULT_SERVER_PORT] is used. Localhost is always
   * used.
   */
  @Provides
  fun providesOverrideServerConfig(
    args: CommandLineArgs,
    configBuilder: ServerConfig.Builder?
  ): ServerConfig? =
    with(configBuilder ?: ServerConfig.newBuilder()) {
      val flagPort = args.getOrNull(SERVER_PORT)?.toInt()
      val configPort = address.split(":").lastOrNull { it.isNotEmpty() }?.toInt()
      val port =
        (flagPort ?: configPort)?.let { if (it == SET_DEFAULT) DEFAULT_SERVER_PORT else it }
          ?: return null

      address = "localhost:$port"
      build()
    }
}
