/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server.strategy

import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.server.ServerStrategy
import com.google.testing.platform.server.extension.shutdownGracefully
import io.grpc.Server
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * Runs the server for an undetermined lifetime. The server is terminated by calling stop.
 *
 * TODO(b/205322585): Remove this class. It's not in use at all.
 */
class InteractiveServerStrategy @Inject constructor(private val server: Server) : ServerStrategy {

  companion object {
    @JvmStatic private val logger = getLogger()
    private const val SUCCESSFUL_TERMINATION = 0
    private const val UNEXPECTED_TERMINATION = 1
  }

  /**
   * Launches server and waits until the server is shut down. The server will shut down either after
   * catching an [Exception] or when the stop method is called. If this function's [CoroutineScope]
   * is cancelled or an exception bubbles up, then a non-zero number is returned.
   *
   * @return [Int] 1 if [Exception] is thrown else 0 if stop is called.
   */
  override suspend fun run(): Int =
    try {
      server.start()
      logger.info("Started server on port ${server.port}.")
      server.awaitTermination()
      SUCCESSFUL_TERMINATION
    } catch (ex: Exception) {
      logger.severe("Server terminating due to: $ex")
      UNEXPECTED_TERMINATION
    } finally {
      stop()
    }

  override fun cancel(aborted: Boolean): Boolean {
    stop()
    return true
  }

  private fun stop() {
    server.shutdownGracefully(5, TimeUnit.SECONDS)
  }
}
