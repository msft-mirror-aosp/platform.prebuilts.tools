/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.net.inject

import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.net.PortPickerLoader
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

/** Dagger module to provide a port picker to be used if ports are left unspecified. */
@Module
object PortPickerModule {
  @Provides @Singleton
  fun providePortPicker(portPickerLoader: PortPickerLoader): PortPicker? =
    portPickerLoader.loadAndConfigurePortPicker()
}
