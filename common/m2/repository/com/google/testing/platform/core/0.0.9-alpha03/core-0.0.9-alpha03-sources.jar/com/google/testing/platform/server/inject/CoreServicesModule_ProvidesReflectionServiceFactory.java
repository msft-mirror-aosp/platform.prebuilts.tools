package com.google.testing.platform.server.inject;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import io.grpc.BindableService;
import javax.annotation.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class CoreServicesModule_ProvidesReflectionServiceFactory implements Factory<BindableService> {
  private final CoreServicesModule module;

  public CoreServicesModule_ProvidesReflectionServiceFactory(CoreServicesModule module) {
    this.module = module;
  }

  @Override
  public BindableService get() {
    return providesReflectionService(module);
  }

  public static CoreServicesModule_ProvidesReflectionServiceFactory create(
      CoreServicesModule module) {
    return new CoreServicesModule_ProvidesReflectionServiceFactory(module);
  }

  public static BindableService providesReflectionService(CoreServicesModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.providesReflectionService());
  }
}
