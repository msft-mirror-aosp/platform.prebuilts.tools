/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.opencensus

import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.diagnostics.DiagnosticsConfigImpl
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.telemetry.core.DiagnosticScope
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.core.telemetry.exporter.DiagnosticExporter
import com.google.testing.platform.core.telemetry.opencensus.exporter.OpencensusSpanExporter
import com.google.testing.platform.core.telemetry.proto.DiagnosticsProto
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.extension.loadAndConfigure
import com.google.testing.platform.proto.api.config.AndroidSdkProto
import com.google.testing.platform.proto.api.config.EnvironmentProto
import com.google.testing.platform.proto.api.config.SetupProto
import io.opencensus.trace.Tracing
import io.opencensus.trace.samplers.Samplers
import javax.inject.Inject

/** Provides OpenCensus diagnostics. */
class OpencensusDiagnostics
@Inject
constructor(
  private val diagnosticsConfig: DiagnosticsProto.Diagnostics,
  private val environment: EnvironmentProto.Environment,
  private val testSetup: SetupProto.TestSetup,
  private val androidSdk: AndroidSdkProto.AndroidSdk,
  private val events: Events,
) : Diagnostics {

  private lateinit var diagnosticExporters: List<DiagnosticExporter>

  /** Root scope. */
  override val scope: DiagnosticScope = OpencensusDiagnosticScope()

  override fun initialize() {
    diagnosticExporters =
      diagnosticsConfig.diagnosticExportersList.map { exporterConfig ->
        val exporter =
          loadAndConfigure<DiagnosticExporter>(
            exporterConfig.label.label,
            exporterConfig.className,
            listOf(
              extensionSourceFrom(
                exporterConfig.label.label,
                exporterConfig.jarList.map { it.path },
                exporterConfig.useSingleClassLoader,
              )
            ),
          )
            ?: throw IllegalStateException(
              "Cannot load diagnostic exporter: ${exporterConfig.label.label}!"
            )
        val diagnosticsConfig =
          DiagnosticsConfigImpl(
            environmentProto = environment,
            testSetupProto = testSetup,
            androidSdkProto = androidSdk,
            configProto = if (exporterConfig.hasConfig()) exporterConfig.config else null,
            configResource = if (exporterConfig.hasResource()) exporterConfig.resource else null,
          )
        exporter.configure(
          ExtensionContextImpl(
            contextMap =
              mutableMapOf(Context.CONFIG_KEY to diagnosticsConfig, Context.EVENTS_KEY to events)
          )
        )
        return@map exporter
      }

    val traceConfig = Tracing.getTraceConfig()
    val activeTraceParams = traceConfig.activeTraceParams
    traceConfig.updateActiveTraceParams(
      activeTraceParams.toBuilder().setSampler(Samplers.alwaysSample()).build()
    )
    // Registers all the exporters with Opencensus
    diagnosticExporters.forEach {
      Tracing.getExportComponent()
        .spanExporter
        .registerHandler(it::class.java.name, OpencensusSpanExporter(it))
    }
  }

  override fun finish() {
    scope.finish()
    Tracing.getExportComponent().shutdown()
  }
}
