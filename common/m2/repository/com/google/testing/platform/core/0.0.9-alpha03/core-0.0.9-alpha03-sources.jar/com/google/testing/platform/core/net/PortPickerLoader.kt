/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.net

import com.google.protobuf.Any as AnyProto
import com.google.testing.platform.api.config.ProtoConfig
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.extension.isExtensionValid
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.extension.loadAndConfigure
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.core.ExtensionProto.ConfigResource
import javax.inject.Inject

/** Loads the [PortPicker] specified in the [RunnerConfig]. */
class PortPickerLoader @Inject constructor(private val runnerConfig: RunnerConfig?) {

  /**
   * Classloads [PortPicker] specified in the [RunnerConfig].
   *
   * @return PortPicker, or null if none is specified.
   * @throws IllegalArgumentException if the configuration proto is invalid or the extension fails
   *   to classload.
   */
  fun loadAndConfigurePortPicker(): PortPicker? = loadAndConfigurePortPickerInConfig(runnerConfig)

  companion object {
    fun loadAndConfigurePortPickerInConfig(runnerConfig: RunnerConfig?): PortPicker? {
      if (
        runnerConfig == null ||
          !runnerConfig.hasServices() ||
          !runnerConfig.services.hasPortPicker()
      ) {
        return null
      }

      val extension = runnerConfig.services.portPicker
      require(extension.isExtensionValid()) { "Found invalid port picker configuration." }

      // TODO(b/230134028): this code is currently following the pattern in
      // TestResultListenerLoader until we decide on the long-term cleanup for the extension
      // loader code.
      return loadAndConfigure<PortPicker>(
          extension.label.label,
          extension.className,
          listOf(
            extensionSourceFrom(
              extension.label.label,
              extension.jarList.map { it.path },
              extension.useSingleClassLoader,
            )
          ),
        )
        .also { portPicker ->
          requireNotNull(portPicker) { "Cannot load port picker: ${extension.label.label}!" }

          val config =
            object : ProtoConfig {
              override val configProto: AnyProto? = extension.config
              override val configResource: ConfigResource? = extension.resource
            }
          portPicker.configure(
            ExtensionContextImpl(contextMap = mutableMapOf(Context.CONFIG_KEY to config))
          )
        }
    }
  }
}
