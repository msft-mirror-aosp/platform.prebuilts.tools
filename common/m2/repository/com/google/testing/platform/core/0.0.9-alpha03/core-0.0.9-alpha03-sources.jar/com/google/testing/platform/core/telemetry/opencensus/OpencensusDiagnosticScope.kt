package com.google.testing.platform.core.telemetry.opencensus

import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.core.DiagnosticScope
import com.google.testing.platform.core.telemetry.core.EventRecord
import com.google.testing.platform.core.telemetry.core.ext.toAttributeValueMap
import com.google.testing.platform.lib.logging.jvm.getLogger
import io.opencensus.trace.Span
import io.opencensus.trace.Tracing
import java.util.Collections

class OpencensusDiagnosticScope : DiagnosticScope {

  private val activeSpans: MutableMap<String, Span> = Collections.synchronizedMap(mutableMapOf())

  /**
   * Records events with a name and custom attributes.
   *
   * @param name Name of the event
   * @param details Map of custom attributes to add to this event
   */
  override fun recordEvent(name: String, details: Map<String, Detail<out Any>>?) {
    Tracing.getTracer().currentSpan.addAnnotation(name, details?.toAttributeValueMap())
  }

  override fun <T> recordEvent(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: DiagnosticScope.() -> T
  ): EventRecord<T> {
    Tracing.getTracer().spanBuilder("UTP.$name").startScopedSpan().use {
      val currentSpan = Tracing.getTracer().currentSpan
      activeSpans[name] = currentSpan
      // Add attributes
      currentSpan.putAttributes(attributes.toAttributeValueMap())
      // Execute the block
      // See https://youtrack.jetbrains.com/issue/KT-28497 for why we can't just put "block()" in
      // the lambda
      val result = it.runCatching { this@OpencensusDiagnosticScope.block() }

      // Add details
      currentSpan.putAttributes(details(result.getOrThrow()).toAttributeValueMap())
      return OpencensusEventRecord(result.getOrNull(), result.isSuccess, result.exceptionOrNull())
        .also { activeSpans.remove(name) }
    }
  }

  override suspend fun <T> recordEventAsync(
    name: String,
    attributes: Map<String, Detail<out Any>>,
    details: (T) -> Map<String, Detail<out Any>>,
    block: suspend DiagnosticScope.() -> T
  ): EventRecord<T> {
    Tracing.getTracer().spanBuilder("UTP.$name").startScopedSpan().use {
      val currentSpan = Tracing.getTracer().currentSpan
      activeSpans[name] = currentSpan
      // Add attributes
      currentSpan.putAttributes(attributes.toAttributeValueMap())
      // Execute the block
      // See https://youtrack.jetbrains.com/issue/KT-28497 for why we can't just put "block()" in
      // the lambda
      val result = it.runCatching { this@OpencensusDiagnosticScope.block() }

      // Add details
      currentSpan.putAttributes(details(result.getOrThrow()).toAttributeValueMap())
      return OpencensusEventRecord(result.getOrNull(), result.isSuccess, result.exceptionOrNull())
        .also { activeSpans.remove(name) }
    }
  }

  override fun finish() {
    synchronized(activeSpans) {
      activeSpans.entries.forEach { (name, span) ->
        logger.warning(
          "Ending span '$name' early. This usually happens if the test invocation is being terminated by something else."
        )
        span.end()
      }
    }
  }

  private companion object {
    @JvmStatic val logger = getLogger()
  }
}
