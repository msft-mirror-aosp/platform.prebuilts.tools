/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server.extension

import com.google.testing.platform.lib.logging.jvm.getLogger
import io.grpc.Server
import java.util.concurrent.TimeUnit

private val logger by lazy { getLogger<Server>() }
/**
 * If server is not shutdown, attempts shutdown and await. If server fails normal shutdown,
 * attempts shutdownNow with half the timeout.
 *
 * @return [Boolean] [true] if server is known to be shutdown by any means, else [false]
 */
fun Server.shutdownGracefully(timeout: Long, unit: TimeUnit): Boolean {
  // avoids throwing error if already shutdown (not thread safe)
  if (isShutdown)
    return true

  // not chained with awaitTermination because shutdown() can return null
  shutdown()
  return if (!awaitTermination(timeout, unit)) {
    shutdownNow().awaitTermination(Math.max(timeout / 2, 1), unit).also {
      logger.warning(
        "Server did not shutdown within $timeout $unit. Abruptly shutting down."
      )
    }
  } else true
}
