/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.plugin

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

/**
 * All the possible error summaries of errors that could occur when running plugins.
 * Each error summary contains a name, type, code and namespace.
 */
enum class PluginErrorSummary(
  override val errorCode: Int,
  override val errorType: Enum<*>
) : ErrorSummary {

  PLUGIN_CONFIG_ERROR(2001, ErrorType.CONFIG),
  PLUGIN_ERROR(2002, ErrorType.TEST),
  UNDETERMINED(2999, ErrorType.UNDETERMINED);

  override val errorName = this.name
  override val namespace = "com.google.testing.platform"
}
