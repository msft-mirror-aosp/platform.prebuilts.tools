package com.google.testing.platform.core.telemetry.opencensus

import com.google.testing.platform.core.telemetry.core.EventRecord

class OpencensusEventRecord<T>(
  val result: T?,
  val success: Boolean,
  val exception: Throwable?
) : EventRecord<T> {

  /**
   * Returns the result of the event when the event is a success or throws the exception when the
   * block fails.
   */
  override fun getOrThrow() = if (success) result as T else throw exception!!

  /** Returns true if the block executed without exceptions */
  override fun isSuccess() = success
}
