/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.errorprone.annotations.ThreadSafe
import com.google.errorprone.annotations.concurrent.GuardedBy
import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.driver.TestCoordinator
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.config.v1.extension.lookupTestFixtureById
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.context.GlobalContextImpl
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.executor.Executor
import com.google.testing.platform.core.executor.configureOrThrow
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.driver.TestCoordinators.AuxiliaryTestCoordinator
import com.google.testing.platform.driver.TestCoordinators.PrimaryTestCoordinator
import com.google.testing.platform.executor.ExecutorExt.cancelAndCatch
import com.google.testing.platform.executor.ExecutorExt.joinOrCancelOnTimeout
import com.google.testing.platform.executor.ExecutorExt.reportCancellation
import com.google.testing.platform.executor.ExecutorExt.reportEvents
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.coroutines.Dispatchers.cachedThreadDispatcher
import com.google.testing.platform.lib.coroutines.job.findName
import com.google.testing.platform.lib.coroutines.job.verboseJoin
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.plugin.PluginLifecycle
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import com.google.testing.platform.proto.api.core.testSuiteMetaData
import com.google.testing.platform.result.DeviceTestResultPublisher
import dagger.Lazy
import java.util.Collections
import java.util.logging.Level
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.newCoroutineContext
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout

/** All the information for one DeviceExecution. */
@ThreadSafe
data class Execution(
  val deviceId: DeviceId,
  val testFixtureId: TestFixtureId,
  val deviceProvider: Lazy<DeviceProvider<DeviceController>>,
  val testDriver: Lazy<TestDriver>,
  var pluginLifecycle: PluginLifecycle,
  var events: Events,
  var dispatcher: CoroutineDispatcher? = null,
  var context: ExtensionContextImpl? = null,
  var cancellable: MutableList<Cancellable> =
    Collections.synchronizedList(mutableListOf<Cancellable>()),
)

/** Executor that wrangles multiple devices running in parallel. */
@ThreadSafe
class MultiDeviceExecutor
@Inject
constructor(
  executions: List<Execution>,
  private val rootCoroutineScope: CoroutineScope,
  private val cancellationContext: ProcessCancellationContext,
  private val errorMessageUpdater: ErrorUpdater,
  private val portPicker: PortPicker?,
) : Executor {
  private val executions: List<Execution> = executions.toList()
  private val mutex = Mutex()
  @GuardedBy("mutex") private lateinit var runnerConfig: RunnerConfig
  // A job to manage the lifespans of all the coroutines launched beneath this Executor. Once it
  // joins, we know it's reasonable to publish test results.
  private val supervisorJob = SupervisorJob(rootCoroutineScope.coroutineContext[Job])
  // If the supervisorJob is cancelled, this is provided for host plugins that do cleanup after
  // the cancellation unstuck things.
  private val cleanupJob = SupervisorJob(rootCoroutineScope.coroutineContext[Job])
  @GuardedBy("mutex") private var cancelling: Deferred<Boolean>? = null

  override fun configure(config: RunnerConfig) {
    configureOrThrow {
      check(config.hasMultiDeviceExecutor())

      val globalContext =
        GlobalContextImpl(
          contextMap =
            mutableMapOf(
              Context.DIAGNOSTICS_KEY to Telemetry.diagnostics,
              Context.PORTPICKER_KEY to portPicker,
            )
        )

      runBlocking(
        rootCoroutineScope.coroutineContext + CoroutineName("MultiDeviceExecutor.configure")
      ) {
        mutex.withLock { runnerConfig = config }
        val exceptions = Collections.synchronizedList(mutableListOf<Throwable>())
        val handler = CoroutineExceptionHandler { _, t: Throwable -> exceptions.add(t) }
        // Configure each device in parallel, on the dispatcher associated with the device. This
        // cuts down on startup time and ensures that the log messages have helpful thread names.
        val configureJob = SupervisorJob(supervisorJob)

        val primaryCoordinator = PrimaryTestCoordinator()
        for ((index, execution) in executions.withIndex()) {
          val coordinator: TestCoordinator =
            if (index == 0) {
              primaryCoordinator
            } else {
              AuxiliaryTestCoordinator(execution.deviceId.friendlyName).also {
                primaryCoordinator.add(it)
              }
            }
          // Each device gets its own thread pool. This makes it much easier to read the debug logs.
          val dispatcher = cachedThreadDispatcher(execution.deviceId.friendlyName)
          execution.dispatcher = dispatcher
          // We have a configureJob just for configure, but the executionContext uses the overall
          // supervisorJob because extensions might start CoroutineScopes from the context in their
          // configure methods.
          val configureContext =
            newCoroutineContext(
              dispatcher +
                configureJob +
                handler +
                CoroutineName("configure ${execution.deviceId.friendlyName}")
            )
          val executionContext =
            newCoroutineContext(
              dispatcher +
                supervisorJob +
                handler +
                CoroutineName("execute ${execution.deviceId.friendlyName}")
            )
          launch(configureContext) {
            // TODO(b/310270813): add any information needed to support span attributes
            try {
              execution.context =
                ExtensionContextImpl(
                  globalContext,
                  mutableMapOf(
                    Context.CLEANUP_JOB_KEY to cleanupJob,
                    Context.CONFIG_KEY to
                      ProxyConfig(config, execution.deviceId, execution.testFixtureId),
                    Context.COORDINATOR_KEY to coordinator,
                    Context.COROUTINE_CONTEXT_KEY to executionContext,
                    Context.DEVICE_PREFIX_KEY to
                      "${execution.deviceId.friendlyName.replace(Regex(" "), "_")}_",
                    Context.EVENTS_KEY to execution.events,
                  ),
                )
              execution.cancellable.add(execution.deviceProvider.get())
              execution.deviceProvider.get().configure(execution.context!!)
              execution.cancellable.add(execution.testDriver.get())
              execution.testDriver.get().configure(execution.context!!)
              execution.pluginLifecycle.onConfigure(
                config.lookupTestFixtureById(execution.testFixtureId),
                execution.context!!,
              )
            } catch (t: Throwable) {
              @Suppress("UnsafeCoroutineCrossing") // the list is synchronized!
              exceptions.add(t)
              // job.completeExceptionally() will not cancel jobs spawned in the various extensions.
              configureJob.cancel(
                CancellationException("configure of ${execution.deviceId.friendlyName} failed", t)
              )
            }
          }
        }

        configureJob.complete()
        logger.fine("Waiting for all configures to join")
        configureJob.join()
        logger.fine("All configures have joined")
        synchronized(exceptions) {
          if (exceptions.isNotEmpty()) {
            val first: Throwable = exceptions.first()
            exceptions.drop(1).forEach { first.addSuppressed(it) }
            throw first
          }
        }
      }
    }
  }

  override fun execute(testResultPublisher: TestResultPublisher): List<TestSuiteResult> {
    runBlocking(
      rootCoroutineScope.coroutineContext + CoroutineName("MultiDeviceExecutor.execute")
    ) {
      // Use a SupervisorJob to keep track of the separate executions. Any jobs launched
      // from their CoroutineContexts will belong to the Executor-level supervisorJob
      // rather than the executionsJob here.
      val executionsJob = SupervisorJob(supervisorJob)
      for (execution in executions) {
        val executionContext =
          executionsJob +
            execution.dispatcher!! +
            CoroutineName("execute ${execution.deviceId.friendlyName}")
        // Each test run is a grandchild of the supervisorJob, but in the thread pool belonging
        // to the execution, to make it easier to read the logs.
        launch(executionContext) { execute(execution, testResultPublisher) }
      }
      // Wait for the separate devices to join.
      executionsJob.complete()
      logger.fine("Waiting for all executions to join")
      try {
        executionsJob.join()
      } catch (t: Throwable) {
        logger.log(Level.WARNING, "executions job joined with error", t)
      }
      // Now complete the Executor-level SupervisorJob and any children it has accumulated.
      supervisorJob.complete()
      logger.finest(
        "waiting for supervisor job to join: ${supervisorJob.children.count()} children"
      )
      for (child in supervisorJob.children) {
        logger.finest("child: ${child.findName()}")
        (child as? CompletableJob)?.complete()
      }
      logger.fine("Waiting for all Executor-descended coroutines to join")
      try {
        supervisorJob.verboseJoin(logger)
      } catch (t: Throwable) {
        logger.log(Level.WARNING, "supervisor job joined with error", t)
      }
      logger.fine("All executions have joined")
    }

    return testResultPublisher.publish().also { cleanupJob.complete() }
  }

  private suspend fun execute(execution: Execution, testResultPublisher: TestResultPublisher) {
    val testSuiteId = testSuiteMetaData { device = execution.deviceId }
    val deviceTestResultPublisher =
      DeviceTestResultPublisher(testResultPublisher, execution.deviceId)

    var controller: DeviceController? = null
    try {
      controller =
        cancellationContext.runUnlessCancelled { execution.deviceProvider.get().provideDevice() }
      controller?.let {
        cancellationContext.runUnlessCancelled<Unit> {
          execution.pluginLifecycle.onBeforeAll(controller)
        }
        if (cancellationContext.isCancelling) {
          testResultPublisher.beforeTestSuite(testSuiteId)
          testResultPublisher.setTestSuiteStatus(testSuiteId, TestStatus.CANCELLED)
        }

        cancellationContext.runUnlessCancelled<Unit> {
          execution.testDriver
            .get()
            .run(
              controller,
              execution.pluginLifecycle.hookPublisher(deviceTestResultPublisher, controller),
            )
        }
      }
    } catch (t: Throwable) {
      var updatedThrowable = errorMessageUpdater.updateInfo(t)
      logger.log(Level.SEVERE, "Test execution failed with fatal error!", updatedThrowable)
      deviceTestResultPublisher.failTestSuite(testSuiteId, updatedThrowable)
      val unused = cancel()
    } finally {
      controller?.let {
        try {
          execution.pluginLifecycle.onAfterAll(testSuiteId, deviceTestResultPublisher, controller)
        } catch (t: Throwable) {
          logger.log(Level.WARNING, "Plugin afterAll failed", t)
        }
        if (cancellationContext.isCancelling) {
          cancellationContext.reportCancellation(testSuiteId, deviceTestResultPublisher)
        }
        try {
          execution.deviceProvider.get().releaseDevice()
        } catch (t: Throwable) {
          logger.log(Level.WARNING, "Failed to release device", t)
        }
      }
      execution.events.reportEvents(testSuiteId, deviceTestResultPublisher)
      deviceTestResultPublisher.afterTestSuite(testSuiteId)
    }
  }

  override fun cancel(aborted: Boolean): Boolean {
    if (runBlocking<Boolean> { supervisorJob.isCancelled }) return true
    if (runBlocking<Boolean> { supervisorJob.isCompleted }) return false

    // Scenarios we need to handle:
    // 1. cancel(false) comes in because a plugin canceled.
    // 2. cancel(true) comes in because UTP timed out.
    // 3. cancel(false) comes in, takes too long, and then cancel(true) comes in.

    // Distinguish coroutine names
    val aborting = if (aborted) " (aborting)" else ""

    // If we're already cancelling, let that proceed.
    runBlocking { mutex.withLock { cancelling } }
      ?.let {
        if (aborted) {
          // It is possible that a plugin cancels the test using cancel(false), then the cleanup
          // takes so long that cancel(true) comes in when the test times out. In this case, we
          // cancel the coroutine that is doing the lackadasical canceling so we can start one that
          // tells everyone to abort.
          it.cancel()
        } else {
          // Don't do anything on multiple cancel(false)
          return true
        }
      }

    // Use a separate thread pool for canceling so it's obvious what's going on when we read the
    // logs.
    val deferredCancelling =
      rootCoroutineScope.async<Boolean>(
        cachedThreadDispatcher("cancel") + CoroutineName("MultiDeviceExecutor cancel$aborting")
      ) {
        val cancels = mutableListOf<Deferred<Boolean>>()
        // First, send out cancels for each device, in the reverse order in which they were added,
        // giving them a chance to play nice. Send out all the cancellations in parallel.
        for (execution in executions) {
          cancels.add(
            async<Boolean>(
              supervisorJob +
                CoroutineName("cancelling ${execution.deviceId.friendlyName}$aborting")
            ) {
              execution.cancellable.reversed().map { it.cancelAndCatch(aborted) }.any { it }
            }
          )
        }

        if (aborted) {
          // Give the top-level supervisorJob time to join. If it fails to do so within the grace
          // period, cancel it. The cancels are all children of the supervisorJob, so they'll all
          // join or get canceled with the supervisorJob.
          supervisorJob.joinOrCancelOnTimeout(runnerConfig.cancellationConfig) ||
            cancels.any { it.await() }
        } else {
          cancels.any { it.await() }
        }
      }

    runBlocking { mutex.withLock { cancelling = deferredCancelling } }

    // Cancellation should be very fast. If it all happens in 100ms, get the actual result from
    // the coroutine. Otherwise, return true, since cancel is clearly doing work, and let the
    // job run. (Experiment with the unit test shows that 10ms is *too* short for the fast path
    // to reliably avoid timeout.)
    return runBlocking(
      rootCoroutineScope.newCoroutineContext(CoroutineName("MultiDeviceExecutor.cancel Wait"))
    ) {
      try {
        withTimeout(100.milliseconds) { deferredCancelling.await() }
      } catch (t: Throwable) {
        true
      }
    }
  }

  private companion object {
    val logger = getLogger()
  }
}
