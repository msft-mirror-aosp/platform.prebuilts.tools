/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.core.ErrorDetailProto.ErrorDetail
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.util.concurrent.atomic.AtomicBoolean

/** Adds a device ID to any protobuf that fails to specify one. */
@ThreadSafe
class DeviceTestResultPublisher(
  private val testResultPublisher: TestResultPublisher,
  private val deviceId: DeviceId,
) : TestResultPublisher {
  private val beforeTestSuiteRan = AtomicBoolean(false)

  private fun TestSuiteMetaData.guaranteeDeviceId(): TestSuiteMetaData {
    if (hasDevice()) return this
    return toBuilder().apply { device = deviceId }.build()
  }

  private fun TestCase.guaranteeDeviceId(): TestCase {
    if (hasDevice()) return this
    return toBuilder().apply { device = deviceId }.build()
  }

  private fun TestResult.guaranteeDeviceId(): TestResult {
    if (hasTestCase() && testCase.hasDevice()) return this
    return toBuilder().apply { testCaseBuilder.device = deviceId }.build()
  }

  override fun beforeTestSuite(testSuite: TestSuiteMetaData) {
    beforeTestSuiteRan.set(true)
    testResultPublisher.beforeTestSuite(testSuite.guaranteeDeviceId())
  }

  override fun beforeTest(testCase: TestCase) =
    testResultPublisher.beforeTest(testCase.guaranteeDeviceId())

  override fun afterTest(testResult: TestResult) =
    testResultPublisher.afterTest(testResult.guaranteeDeviceId())

  override fun addTestSuiteArtifact(testSuite: TestSuiteMetaData, artifact: Artifact) =
    testResultPublisher.addTestSuiteArtifact(testSuite.guaranteeDeviceId(), artifact)

  override fun addTestSuiteIssue(testSuite: TestSuiteMetaData, issue: Issue) =
    testResultPublisher.addTestSuiteIssue(testSuite.guaranteeDeviceId(), issue)

  override fun failTestSuite(testSuite: TestSuiteMetaData, detail: ErrorDetail) =
    testResultPublisher.failTestSuite(testSuite.guaranteeDeviceId(), detail)

  override fun failTestSuite(testSuite: TestSuiteMetaData, throwable: Throwable) =
    testResultPublisher.failTestSuite(testSuite.guaranteeDeviceId(), throwable)

  override fun clearFailures(testSuite: TestSuiteMetaData) =
    testResultPublisher.clearFailures(testSuite.guaranteeDeviceId())

  override fun setTestSuiteStatus(testSuite: TestSuiteMetaData, status: TestStatus) =
    testResultPublisher.setTestSuiteStatus(testSuite.guaranteeDeviceId(), status)

  override fun workingDraft(testSuite: TestSuiteMetaData) =
    testResultPublisher.workingDraft(testSuite.guaranteeDeviceId())

  override fun afterTestSuite(testSuite: TestSuiteMetaData) {
    // beforeTestSuite needs to be called in the test driver, after it has figured out the details
    // of the test suite. afterTestSuite gets called in the executor after handling any possible
    // exceptions coming from the test driver. If an error occurs before the test driver has the
    // details of the test suite, call beforeTestSuite so there's always a matching before to the
    // after.
    if (!beforeTestSuiteRan.get()) beforeTestSuite(testSuite.guaranteeDeviceId())
    testResultPublisher.afterTestSuite(testSuite.guaranteeDeviceId())
  }

  override fun publish(): List<TestSuiteResult> = testResultPublisher.publish()
}
