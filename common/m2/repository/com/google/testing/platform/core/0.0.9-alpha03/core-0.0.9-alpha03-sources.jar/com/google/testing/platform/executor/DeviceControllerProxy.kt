/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.testing.platform.api.device.CommandHandle
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.api.device.Device
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.proto.api.core.LogMessageProto
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import java.io.File
import java.nio.file.Files
import java.time.Duration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.shareIn

class DeviceControllerProxy
constructor(
  private val delegateController: DeviceController,
  val logsCoroutineScope: CoroutineScope,
) : DeviceController by delegateController {

  private val logsFlow: Flow<LogMessageProto.LogMessage> by lazy {
    delegateController
      .streamLogs()
      // shareIn converts the Flow to a SharedFlow that broadcasts events, in this case log lines
      // to all consumers.
      // See:
      // https://kotlin.github.io/kotlinx.coroutines/kotlinx-coroutines-core/kotlinx.coroutines.flow/share-in.html
      // Note that the underlying flow does not start on the invocation of streamLogs() but when
      // the first consumer of this flow invokes collect(). The Flow will stay alive till the last
      // consumer is subscribed to it.
      .shareIn(scope = logsCoroutineScope, started = SharingStarted.WhileSubscribed())
  }
  private var deviceIsActive = true // the controller provided in the constructor is active

  private companion object {
    private const val CONTROLLER_INSTALL_EVENT_NAME = "DeviceController.Install"
    private const val CONTROLLER_PUSH_EVENT_NAME = "DeviceController.Push"
    private const val CONTROLLER_PULL_EVENT_NAME = "DeviceController.Pull"
    private const val CONTROLLER_EXECUTE_EVENT_NAME = "DeviceController.Execute"
    private const val CONTROLLER_EXECUTE_ASYNC_EVENT_NAME = "DeviceController.ExecuteAsync"
    private const val ARTIFACT_NAME = "ArtifactName"
    private const val SIZE = "Size"
    private const val ARGS = "Args"
    private const val STATUS = "Status"
  }

  private fun Artifact.toAttributeMap(): Map<String, Detail<*>> =
    if (File(this.sourcePath.path).exists()) {
      mutableMapOf(
        ARTIFACT_NAME to Detail(this.sourcePath.path.split("/").last()),
        SIZE to Detail("${Files.size(File(this.sourcePath.path).toPath())}"),
      )
    } else {
      mutableMapOf()
    }

  private fun Int.toDetailMap(): Map<String, Detail<*>> = mutableMapOf(STATUS to Detail("$this"))

  private fun List<String>.toAttributeMap(): Map<String, Detail<*>> =
    mutableMapOf(ARGS to Detail(this.joinToString(" ")))

  private fun CommandResult.toDetailMap(): Map<String, Detail<*>> = this.statusCode.toDetailMap()

  override fun setDevice(device: Device) {
    // It is unlikely that this will ever be called, since the Proxy is wrapping an existing
    // DeviceController, but if someone ever does reuse a DeviceControllerProxy, it will do the
    // right thing.
    deviceIsActive = true
    delegateController.setDevice(device)
  }

  override fun releaseDevice() {
    deviceIsActive = false
    delegateController.releaseDevice()
  }

  override fun install(artifact: Artifact): CommandResult {
    check(deviceIsActive) { "Device must be active" }
    var which: String =
      artifact.label.label.split(Regex("[/:]")).lastOrNull()
        ?: artifact.sourcePath.path.split("/").lastOrNull()
        ?: "${artifact.label.namespace}:${artifact.label.label}"
    return Telemetry.createEvent(CONTROLLER_INSTALL_EVENT_NAME) {
        displayName = "InstallArtifact $which"
        addAllAttributes(artifact.toAttributeMap())
        onComplete { result: CommandResult -> result.statusCode.toDetailMap() }
        run { delegateController.install(artifact) }
      }
      .getOrThrow()
  }

  override fun push(artifact: Artifact): Int {
    check(deviceIsActive) { "Device must be active" }
    val artifactPath = artifact.sourcePath.path
    val shortPath = artifactPath.substring(artifactPath.lastIndexOf('/') + 1)
    return Telemetry.createEvent(CONTROLLER_PUSH_EVENT_NAME) {
        displayName = "PushArtifact $shortPath"
        addAllAttributes(artifact.toAttributeMap())
        onComplete { exitCode: Int -> exitCode.toDetailMap() }
        run { delegateController.push(artifact) }
      }
      .getOrThrow()
  }

  override fun pull(artifact: Artifact): Int {
    check(deviceIsActive) { "Device must be active" }
    val artifactPath = artifact.destinationPath.path
    val shortPath = artifactPath.substring(artifactPath.lastIndexOf('/') + 1)
    return Telemetry.createEvent(CONTROLLER_PULL_EVENT_NAME) {
        displayName = "PullArtifact $shortPath"
        addAllAttributes(artifact.toAttributeMap())
        onComplete({ exitCode: Int -> exitCode.toDetailMap() })
        run { delegateController.pull(artifact) }
      }
      .getOrThrow()
  }

  override fun execute(args: List<String>, timeout: Duration?): CommandResult {
    check(deviceIsActive) { "Device must be active" }
    return Telemetry.createEvent(CONTROLLER_EXECUTE_EVENT_NAME) {
        displayName = "ExecuteCommand \"${args.joinToString(" ")}\""
        addAllAttributes(args.toAttributeMap())
        onComplete({ result: CommandResult -> result.toDetailMap() })
        run { delegateController.execute(args, timeout) }
      }
      .getOrThrow()
  }

  override fun executeAsync(args: List<String>, processor: (String) -> Unit): CommandHandle {
    check(deviceIsActive) { "Device must be active" }
    return Telemetry.createEvent(CONTROLLER_EXECUTE_ASYNC_EVENT_NAME) {
        displayName = "ExecuteCommandAsync \"${args.joinToString(" ")}\""
        addAllAttributes(args.toAttributeMap())
        run { delegateController.executeAsync(args, processor) }
      }
      .getOrThrow()
  }

  override fun streamLogs(): Flow<LogMessageProto.LogMessage> {
    check(deviceIsActive) { "Device must be active" }
    return logsFlow
  }

  override fun extensions() = delegateController.extensions()
}
