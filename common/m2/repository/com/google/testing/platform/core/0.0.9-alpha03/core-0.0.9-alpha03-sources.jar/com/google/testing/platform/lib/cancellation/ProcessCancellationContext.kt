/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.lib.cancellation

import com.google.errorprone.annotations.ThreadSafe
import java.time.Duration
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

/**
 * The process cancellation context singleton, shared across threads running in this process.
 * Functions in this object are thread-safe. This class coordinates cancellation operations by:
 * 1. maintaining state that indicates whether cancellation has occurred
 * 2. ensuring all cancellation threads join the main thread
 * 3. exposing functions that can be used to run logic cooperatively by checking cancellation state
 */
@ThreadSafe
class ProcessCancellationContext(
  val gracePeriod: Duration? = null,
  val dispatcher: CoroutineDispatcher = Dispatchers.Default,
) {
  private val orderedCancelReasons: MutableSet<Throwable> =
    Collections.synchronizedSet(linkedSetOf())
  private val cancelling = AtomicBoolean(false)
  private val aborting = AtomicBoolean(false)
  private val latch = CountDownLatch(1)
  // Top-level Coroutine job & scope to execute tasks during cancellation
  private val coroutineJob = Job()
  private val coroutineScope =
    CoroutineScope(dispatcher + coroutineJob + CoroutineName("ProcessCancellationContext"))

  /**
   * Whether this process is in the process of cancelling.
   *
   * Ideally, cancellation shutdown should be cooperative - this state should be checked before
   * doing any heavy lifting work on the main/working thread.
   */
  val isCancelling
    get() = cancelling.get()

  /**
   * Whether this process is in the process of aborting.
   *
   * This is cancellation with a harsh deadline, on the order of ten seconds. If UTP is canceling
   * but not aborting, it is worthwhile to retrieve all possible state to aid in debugging. If UTP
   * is aborting, any lenghty operations should be curtailed in favor of a swift exit.
   */
  val isAborting
    get() = aborting.get()

  val cancelReasons: Set<Throwable>
    get() = synchronized(orderedCancelReasons) { orderedCancelReasons.toSet() }

  /**
   * Starts the cancellation and returns immediately.
   *
   * Use [cancelAndJoinMain] to wait until the main thread to exit.
   *
   * @param includeSubProcesses Whether to destroy all its sub-processes as well. False by default.
   * @param cancelReason The exception indicating the reason cancellation was invoked.
   * @param cancelBlock Code block to run during cancellation
   */
  fun cancel(
    includeSubProcesses: Boolean = false,
    cancelReason: Throwable? = null,
    cancelBlock: (() -> Unit)? = null,
  ) {
    val firstCallToCancel =
      cancelling.compareAndSet(
        false, // Expected value is NOT cancelled.
        true, // New value is set the cancel bit.
      )
    cancelReason?.let { orderedCancelReasons.add(it) }
    if (!firstCallToCancel) {
      return
    }
    cancelBlock?.invoke()
    if (includeSubProcesses) {
      ProcessHandle.current().children().forEach { it.destroy() }
    }
  }

  /**
   * Sets the cancellation status and waits until the main thread to exit.
   *
   * This function is typically called by the cancelling thread registered in the
   * [Runtime.addShutdownHook]. It will only run when the JVM process is interrupted externally and
   * not part of normal JVM shutdown.
   *
   * @param includeSubProcesses Whether to destroy all its sub-processes as well. False by default.
   * @param cancelReason The exception indicating the reason cancellation was invoked.
   * @param cancelBlock Code block to run during cancellation
   */
  fun cancelAndJoinMain(
    includeSubProcesses: Boolean = false,
    cancelReason: Throwable? = null,
    cancelBlock: (() -> Unit)? = null,
  ) {
    // Return if main thread has exited normally as part of JVM shutdown. Shouldn't need to cancel
    // anything if this has already happened.
    if (latch.count == 0L) return
    // The main thread has not exited, which means we are being called from the shutdown hook,
    // probably because the process is being interrupted. This means we're aborting and should
    // clean up as quickly as possible.
    aborting.set(true)
    cancel(includeSubProcesses, cancelReason, cancelBlock)
    if (gracePeriod != null) {
      latch.await(gracePeriod.seconds, TimeUnit.SECONDS)
    } else {
      latch.await()
    }
    coroutineJob.cancel()
    // Kills any descendant process forcibly before exiting
    ProcessHandle.current().descendants().forEach { it.destroyForcibly() }
  }

  /**
   * Called when the main thread is exiting soon.
   *
   * This function should be called by the main thread when it's exiting (e.g. immediately before
   * calling [System.exit]).
   */
  fun mainThreadExiting() {
    latch.countDown()
  }

  /**
   * Executes the given code block during normal execution, skip if the entire process is being
   * cancelled.
   *
   * Used to wrap any heavy-lifting task/logic, to operate cooperatively during process
   * cancellation.
   *
   * @param block Code block to execute if not being canceled.
   */
  fun <T> runUnlessCancelled(block: () -> T): T? = if (!isCancelling) block() else null

  /**
   * Executes the given code block as-is during normal execution, or run with the given [timeout]
   * when the entire process is being cancelled.
   *
   * Caveat: if the code block is not cancellable, the cancelling thread executing the code will
   * continue without really cancelling the code block. This should be fine during cancellation,
   * since we will eventually clean up everything at the end of cancellation.
   *
   * @param timeout Timeout in milliseconds. 1000ms by default.
   * @param block Code block to execute
   */
  fun <T> runWithTimeoutDuringCancellation(timeout: Long = 1000L, block: () -> T): T? =
    if (isCancelling) {
      runBlocking(coroutineScope.coroutineContext) {
        withTimeout(timeout) {
          coroutineScope
            .async(CoroutineName("ProcessCancellationContext RunWithTimeout")) { block() }
            .await()
        }
      }
    } else {
      block()
    }
}
