/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.protobuf.Message
import com.google.testing.platform.lib.logging.jvm.getLogger
import java.io.InputStream
import java.nio.file.Files
import java.nio.file.Paths

/**
 * Parses a proto file that contains T : [Message] values.
 */
abstract class FileConfigProvider<T : Message> constructor(
  protected val path: String
) : ConfigProvider<T> {
  companion object {
    @JvmStatic
    private val logger = getLogger()
  }

  /**
   * Returns whether this [ConfigProvider] can provide T : [Message].
   */
  override fun hasConfig(): Boolean = try {
    path.isNotBlank() && Paths.get(path).let { Files.exists(it) }
  } catch (ex: Exception) {
    logger.warning("Failed to load config file: '$ex'")
    false
  }

  /**
   * Returns a T : [Message] from a binary or text proto file.
   *
   * @throws [IllegalStateException] if the config is null or blank
   *         or [ConfigurationException] if the file can't be parsed
   */
  override fun getConfig(): T {
    check(hasConfig()) {
      "Specified protocol buffer config file doesn't exist: '$path'"
    }

    return Paths.get(path)
      .let { Files.newInputStream(it) }
      .let { getConfigFrom(it) }
  }

  protected abstract fun getConfigFrom(stream: InputStream): T
}
