package com.google.testing.platform.main.inject;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class MainModule_RootCoroutineScopeFactory implements Factory<CoroutineScope> {
  private final MainModule module;

  private final Provider<CoroutineDispatcher> rootCoroutineDispatcherProvider;

  public MainModule_RootCoroutineScopeFactory(MainModule module,
      Provider<CoroutineDispatcher> rootCoroutineDispatcherProvider) {
    this.module = module;
    this.rootCoroutineDispatcherProvider = rootCoroutineDispatcherProvider;
  }

  @Override
  public CoroutineScope get() {
    return rootCoroutineScope(module, rootCoroutineDispatcherProvider.get());
  }

  public static MainModule_RootCoroutineScopeFactory create(MainModule module,
      Provider<CoroutineDispatcher> rootCoroutineDispatcherProvider) {
    return new MainModule_RootCoroutineScopeFactory(module, rootCoroutineDispatcherProvider);
  }

  public static CoroutineScope rootCoroutineScope(MainModule instance,
      CoroutineDispatcher rootCoroutineDispatcher) {
    return Preconditions.checkNotNullFromProvides(instance.rootCoroutineScope(rootCoroutineDispatcher));
  }
}
