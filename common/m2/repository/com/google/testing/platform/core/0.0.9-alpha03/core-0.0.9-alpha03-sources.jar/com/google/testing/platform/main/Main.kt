/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.main

import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.coroutines.Dispatchers.cachedThreadDispatcher
import com.google.testing.platform.main.inject.MainComponent
import com.google.testing.platform.server.ServerStrategy
import java.util.logging.Level
import java.util.logging.Logger
import kotlin.concurrent.thread
import kotlin.coroutines.EmptyCoroutineContext
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.runBlocking

private val logger = Logger.getLogger("com.google.testing.platform.main.Main")

/**
 * Main entry point for the test [ServerStrategy].
 *
 * @param args command line args
 * @param exit function to report [ServerStrategy]'s exit behaviour
 */
@JvmOverloads
fun main(args: Array<String>, exit: (Int) -> Unit = { exitCode -> System.exit(exitCode) }) {
  Thread.setDefaultUncaughtExceptionHandler { _, uncaught ->
    try {
      logger.log(
        Level.SEVERE,
        "Fatal error while executing main with args: ${args.joinToString(" ")}",
        uncaught,
      )
    } catch (logError: Throwable) {
      // If there is an error thrown during logging try to log the message of the uncaught Exception
      // and the log error
      println(uncaught.message)
      println(logError.message)
    } finally {
      exit(2)
    }
  }

  val dispatcher = cachedThreadDispatcher("UTP")
  // No cancellation deadline is set for the extension process. Leave to the launcher process.
  val cancellationContext = ProcessCancellationContext(dispatcher = dispatcher)
  val strategy = MainComponent.getServerStrategy(args, cancellationContext, dispatcher)
  val shutdownHook = thread(start = false, name = "UTP Shutdown") {
    try {
      cancellationContext.cancelAndJoinMain { strategy.cancel(true) }
    } catch (t: Throwable) {
      logger.log(Level.WARNING, "Error occurred during cancellation!", t)
    }
  }

  Runtime.getRuntime().addShutdownHook(shutdownHook)

  exit(
    runBlocking<Int>(EmptyCoroutineContext + dispatcher + CoroutineName("Main")) {
      try {
        strategy.run()
      } finally {
        cancellationContext.mainThreadExiting()
        // Remove the shutdown hook to avoid a potential memory leak if this main method is called
        // multiple times from another piece of code, instead of being invoked directly as main from
        // the JVM.
        Runtime.getRuntime().removeShutdownHook(shutdownHook)
      }
    }
  )
}
