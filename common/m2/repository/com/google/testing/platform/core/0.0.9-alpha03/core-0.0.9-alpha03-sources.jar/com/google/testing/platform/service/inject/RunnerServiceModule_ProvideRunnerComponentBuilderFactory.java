package com.google.testing.platform.service.inject;

import com.google.testing.platform.inject.RunnerComponent;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RunnerServiceModule_ProvideRunnerComponentBuilderFactory implements Factory<RunnerComponent.Builder> {
  private final RunnerServiceModule module;

  public RunnerServiceModule_ProvideRunnerComponentBuilderFactory(RunnerServiceModule module) {
    this.module = module;
  }

  @Override
  public RunnerComponent.Builder get() {
    return provideRunnerComponentBuilder(module);
  }

  public static RunnerServiceModule_ProvideRunnerComponentBuilderFactory create(
      RunnerServiceModule module) {
    return new RunnerServiceModule_ProvideRunnerComponentBuilderFactory(module);
  }

  public static RunnerComponent.Builder provideRunnerComponentBuilder(
      RunnerServiceModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideRunnerComponentBuilder());
  }
}
