/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.proto

import com.google.protobuf.Descriptors.FieldDescriptor
import com.google.protobuf.Descriptors.FieldDescriptor.Type
import com.google.protobuf.Message

/**
 * Badly behaved libraries can emit strings that cause problems downstream, such as gRPC putting a
 * null in the middle of a string that it throws in an exception; writing that out in XML can cause
 * an org.xml.sax.SAXException: "An invalid XML character (Unicode: 0x0) was found in the node's
 * character data content."
 *
 * These sanitize functions strip anything problematic from strings (currently, just nulls).
 */
object Sanitize {
  /** Sanitizes a single string. */
  fun String.sanitize() = this.replace(Regex.fromLiteral("\u0000"), "")

  /** Sanitizes every String in a protobuf Message. */
  @Suppress("UNCHECKED_CAST")
  fun <T : Message> T.sanitize() = this.toBuilder().apply { sanitize() }.build() as T

  /** Sanitizes a Message.Builder in-place. */
  private fun Message.Builder.sanitize() {
    val descriptor = this.descriptorForType
    for (field in descriptor.fields) {
      when (field.type) {
        Type.MESSAGE ->
          when {
            field.isMapField() -> this.sanitizeMapField(field)
            field.isRepeated() -> {
              for (i in 0..this.getRepeatedFieldCount(field) - 1) {
                this.getRepeatedFieldBuilder(field, i).sanitize()
              }
            }
            else -> if (this.hasField(field)) this.getFieldBuilder(field).sanitize()
          }
        Type.STRING ->
          if (field.isRepeated()) {
            for (i in 0..this.getRepeatedFieldCount(field) - 1) {
              this.setRepeatedField(
                field,
                i,
                (this.getRepeatedField(field, i) as String).sanitize()
              )
            }
          } else if (this.hasField(field)) {
            this.setField(field, (this.getField(field) as String).sanitize())
          }
        else -> continue
      }
    }
  }

  /** Sanitizes a map field in-place. */
  private fun Message.Builder.sanitizeMapField(field: FieldDescriptor) {
    // Map fields are a repeated field of type MESSAGE where the message has "key" and "value"
    // fields. Internally, it's a com.google.protobuf.MapEntry, but that's an implementation detail
    // we aren't supposed to rely on. MapEntry is not well-behaved and we can't use
    // getRepeatedFieldBuilder() on it; if the value is of type Message, we can't even use
    // toBuilder().sanitize() on it! So we have to clear the field, sanitize the key and value
    // individually (if needed) and then add everything again.
    @Suppress("UNCHECKED_CAST") val entries = this.getField(field) as List<Message>
    if (entries.isEmpty()) return // NOMUTANTS -- efficiency

    val entryDescriptor = entries.first().descriptorForType
    val key = entryDescriptor.findFieldByName("key")
    val value = entryDescriptor.findFieldByName("value")
    if (!(key?.type == Type.STRING || (value?.type in setOf(Type.STRING, Type.MESSAGE))))
      return // NOMUTANTS -- efficiency

    this.clearField(field)
    for (entry in entries) {
      val builder = entry.toBuilder()
      if (key?.type == Type.STRING) {
        builder.setField(key, (builder.getField(key) as String).sanitize())
      }
      when (value?.type) {
        Type.STRING -> builder.setField(value, (builder.getField(value) as String).sanitize())
        Type.MESSAGE ->
          builder.setField(
            value,
            (builder.getField(value) as Message).toBuilder().apply { sanitize() }.build()
          )
        else -> {}
      }
      this.addRepeatedField(field, builder.build())
    }
  }
}
