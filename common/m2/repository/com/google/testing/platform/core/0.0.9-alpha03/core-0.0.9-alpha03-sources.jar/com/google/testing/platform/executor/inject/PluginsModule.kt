/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor.inject

import com.google.testing.platform.config.v1.extension.lookupTestFixtureById
import com.google.testing.platform.lib.cancellation.PluginCancellationDelegate
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.plugin.PluginGraphFactory
import com.google.testing.platform.plugin.PluginLifecycle
import com.google.testing.platform.plugin.PluginProviderFactory
import com.google.testing.platform.plugin.PluginProviderProxy
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.config.runnerConfig
import dagger.Module
import dagger.Provides
import dagger.Reusable
import java.time.Duration

/**
 * Provides all available plugins to be injected into the
 * [com.google.testing.platform.plugin.PluginLifecycle].
 */
@Module
class PluginsModule {
  @Provides
  @Reusable
  fun pluginProviders(
    runnerConfig: RunnerConfig
  ): Map<TestFixtureId, @JvmSuppressWildcards PluginProviderFactory> =
    runnerConfig.testFixtureList.associate {
      val factory =
        object : PluginProviderFactory {
          override fun create() = PluginProviderProxy(it)
        }
      Pair<TestFixtureId, PluginProviderFactory>(it.testFixtureId, factory)
    }

  @Provides
  @Reusable
  fun pluginLifecycles(
    factories: Map<TestFixtureId, @JvmSuppressWildcards PluginProviderFactory>,
    runnerConfig: RunnerConfig,
    cancellationContext: ProcessCancellationContext,
    pluginCancellationDelegate: PluginCancellationDelegate,
  ): Map<TestFixtureId, PluginLifecycle> =
    factories.mapValues { entry ->
      val pluginCleanupTimeout =
        if (
          runnerConfig.hasCancellationConfig() &&
            runnerConfig.cancellationConfig.pluginCleanupTimeoutMs > 0
        ) {
          Duration.ofMillis(runnerConfig.cancellationConfig.pluginCleanupTimeoutMs)
        } else {
          Duration.ofSeconds(1L)
        }
      val fixture = runnerConfig.lookupTestFixtureById(entry.key)
      PluginLifecycle(
        entry.value,
        PluginGraphFactory(runnerConfig, fixture),
        fixture,
        cancellationContext,
        pluginCancellationDelegate,
        pluginCleanupTimeout,
      )
    }
}
