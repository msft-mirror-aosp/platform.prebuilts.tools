/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.protobuf.TextFormat
import com.google.testing.platform.config.Environment
import com.google.testing.platform.proto.api.core.TestSuiteResultProto
import java.io.File
import java.io.IOException
import java.time.Instant
import javax.inject.Inject

const val TEXT_PROTO_LOG_FILENAME = "test-result.textproto"

class TextProtoLogWriter @Inject constructor(environment: Environment) : ProtoLogWriter {
  private val logDirectory = environment.outputDirectory
  override val logPath = File(logDirectory, TEXT_PROTO_LOG_FILENAME)

  override fun write(testSuiteResult: TestSuiteResultProto.TestSuiteResult) {
    try {
      if (!logPath.exists()) {
        logDirectory.mkdirs()
        logPath.createNewFile()
        // Provide a hint to tools that want to render the result.
        logPath.appendText(
          "# proto-message: google.testing.platform.proto.api.core.TestSuiteResult\n"
        )
      }
      // Always append, since we can have the output of multiple test suites from different devices.
      logPath.appendText("# ${Instant.now()}:\n")
      logPath.appendText(TextFormat.printer().printToString(testSuiteResult))
    } catch (e: IOException) {
      throw ProtoLogWriterException("Failed to write to log: $logPath", e)
    }
  }
}
