/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.extension

import com.google.testing.platform.lib.extension.internals.DefaultExtensionClassLoaderFactory
import com.google.testing.platform.lib.extension.internals.DefaultServiceLoaderWrapper
import com.google.testing.platform.lib.logging.jvm.getLogger

/**
 * Loads extensions for a extension interface.
 *
 * @param extensionSources the list of extensions sources, e.g. jar files that contain extension
 *   classes, resources and meta data
 * @param serviceLoaderWrapper optional [java.util.ServiceLoader] wrapper. By default this class
 *   uses a [DefaultServiceLoaderWrapper]. Custom wrappers will override the default wrapper and
 *   allow for customisation of the service loading implementation
 * @param extensionClassLoaderFactory a factory that creates an isolated classloader from a
 *   [ExtensionSource] and parent ClassLoader
 *
 * <P> specifies the extension interface type. I.e. given a extension interface type of type
 * {@code(FooExtension)}, this class will attempt to load any concrete implementations of
 * {@code(FooExtension)}.
 */
class ExtensionLoader<P>(
  private val extensionSources: List<ExtensionSource>,
  private val serviceLoaderWrapper: ServiceLoaderWrapper = DefaultServiceLoaderWrapper,
  private val extensionClassLoaderFactory: ExtensionClassLoaderFactory =
    DefaultExtensionClassLoaderFactory
) {

  companion object {
    @JvmStatic private val logger = getLogger()
  }

  /**
   * Loads all extension implementations of a extension interface.
   *
   * This method will use an isolated ClassLoader for each [ExtensionSource].
   *
   * @param extensionClass the extension interface type
   * @return a list of extensions implementing the extension interface
   */
  fun load(extensionClass: Class<P>): List<P> {
    return load(extensionClass, extensionSources)
  }

  /**
   * Loads the first implementation of a extension interface.
   *
   * @param extensionClass the extension interface type
   * @return first extension implementing the extension interface
   */
  fun loadFirst(extensionClass: Class<P>): P {
    return load(extensionClass, extensionSources).first()
  }

  /**
   * Loads a list of extensions, filtered by [ExtensionSource], e.g. allows to filter extensions by
   * name.
   *
   * @param extensionClass the extension interface type
   * @param filter lambda to filter extension interface type
   * @return a list of extensions implementing the extension interface
   */
  fun loadByExtensionSource(
    extensionClass: Class<P>,
    filter: (ExtensionSource) -> Boolean
  ): List<P> = load(extensionClass, extensionSources.filter { filter(it) }.toList())

  private fun load(extensionClass: Class<P>, extensionSources: List<ExtensionSource>): List<P> {
    return extensionSources
      .flatMap { extensionSource ->
        logger.fine(
          """Loading extension for interface: $extensionClass
          |From extension source: $extensionSource"""
            .trimMargin()
        )
        var loadedExtensions: List<P>
        try {
          loadedExtensions =
            serviceLoaderWrapper.loadService(
              extensionClass,
              extensionClassLoaderFactory.createFromSource(extensionSource)
            )
        } catch (throwable: Throwable) {
          throw ExtensionLoaderException(
            ExtensionLoaderErrorSummary.EXTENSION_LOAD_FAILED,
            "Extension cannot be loaded from extension source: $extensionSource",
            throwable
          )
        }
        loadedExtensions
      }
      .toList()
  }
}
