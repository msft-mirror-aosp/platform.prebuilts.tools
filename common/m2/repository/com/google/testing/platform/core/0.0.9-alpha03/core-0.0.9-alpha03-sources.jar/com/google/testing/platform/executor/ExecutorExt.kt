/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.core.event.MutableEvents
import com.google.testing.platform.core.event.consume
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.coroutines.job.findName
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.CancellationConfigProto.CancellationConfig
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.result.TestSuiteResultExt.summarizeCancellations
import java.util.logging.Level
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

/** Extension functions shared by multiple implementations of Executor. */
object ExecutorExt {
  val logger = getLogger()

  /** Reports cancellation to the TestResultPublisher. */
  fun ProcessCancellationContext.reportCancellation(
    testSuiteId: TestSuiteMetaData,
    testResultPublisher: TestResultPublisher,
  ) {
    val status =
      if (cancelReasons.isEmpty()) {
        // Externally triggered meaning an outside actor cancelled the test.
        // A SIGINT/SIGTERM was initiated on the UTP process.
        // No component has errored here, the Core and configured extensions were running
        // normally when an external signal was received and the run was cancelled. Hence
        // ABORTED, there isn't an explicit error/exception associated in this state.
        TestStatus.ABORTED
      } else {
        // Triggered via PluginCancellation while running asynchronously.
        // A plugin running asynchronously errored out and has cancelled the test with the
        // supplied exception. The behavior is equivalent to a regular exception thrown by
        // a plugin but in the background hence triggering the core's cancellation
        // operations.
        TestStatus.ERROR
      }
    testResultPublisher.failTestSuite(testSuiteId, summarizeCancellations(cancelReasons))
    testResultPublisher.setTestSuiteStatus(testSuiteId, status)
  }

  /** Reports Issue events to the TestResultPublisher. */
  fun Events.reportEvents(
    testSuiteId: TestSuiteMetaData,
    testResultPublisher: TestResultPublisher,
  ) {
    try {
      if (this is MutableEvents) {
        // Catch any final Issues coming from releaseDevice() (or provideDevice() if that threw an
        // exception). pluginLifecycle.onAfterAll usually handles everything else beforehand.
        for (issue in consume<Issue>()) {
          testResultPublisher.addTestSuiteIssue(testSuiteId, issue)
        }
        // Pick up any artifacts being emitted at the test suite level.
        for (artifact in consume<Artifact>()) {
          testResultPublisher.addTestSuiteArtifact(testSuiteId, artifact)
        }
      }
    } catch (t: Throwable) {
      logger.log(Level.WARNING, "Exception thrown while trying to report any last Issues", t)
    }
  }

  /**
   * Joins a SupervisorJob with RunnerConfig timeout parameters, canceling if necessary.
   *
   * This will allow plugins that are running coroutines (e.g. to stream logs) time to clean up.
   *
   * @return true if a cancellation was performed
   */
  @CanIgnoreReturnValue
  suspend fun CompletableJob.joinOrCancelOnTimeout(
    cancellationConfig: CancellationConfig
  ): Boolean {
    logger.fine("Supervisor job has ${children.count()} children")
    for (child in children) {
      logger.finest("child: ${child.findName()}")
    }
    val timeout = cancellationConfig.executorCancellationTimeoutMs.milliseconds
    try {
      withTimeout(timeout) { join() }
      return false
    } catch (t: TimeoutCancellationException) {
      logger.warning("Supervisor job failed to join in ${timeout}; canceling")
      // Waiting for a regular join timed out. Cancel the executor-level SupervisorJob and return.
      // Any host plugin will cut over to the cleanupJob to finish processing.
      // ServerStrategy.cancel() will clean everything else up.
      cancel(CancellationException("Canceled by Executor"))
      return true
    }
  }

  /** Catch any errors thrown from cancel() and log them. */
  fun Cancellable.cancelAndCatch(aborted: Boolean): Boolean {
    try {
      return cancel(aborted)
    } catch (t: Throwable) {
      logger.log(Level.WARNING, "Error canceling ${this::class.simpleName!!}", t)
      return true
    }
  }
}
