/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.service.manager

import com.google.testing.platform.Runner
import com.google.testing.platform.proto.api.service.RunIdProto.RunId
import com.google.testing.platform.service.RunnerManager
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentMap
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

class RunnerManagerImpl(
  private val runners: ConcurrentMap<RunId, Runner> = ConcurrentHashMap<RunId, Runner>(),
  private val workers: ConcurrentMap<RunId, Job> = ConcurrentHashMap<RunId, Job>(),
  parentScope: CoroutineScope,
) : RunnerManager {

  private val runScope = parentScope

  override val coroutineContext = runScope.coroutineContext

  override fun run(id: RunId, runner: Runner): Boolean {
    return if (runners.putIfAbsent(id, runner) == null) {
      workers[id] =
        runScope
          .launch(CoroutineName("RunnerManagerImpl")) { coroutineScope { runner.run() } }
          .also {
            it.invokeOnCompletion {
              workers.remove(id)
              runners.remove(id)
            }
          }

      true
    } else {
      false
    }
  }

  override fun cancel(id: RunId): Boolean {
    workers[id]?.cancel()
    return runners.remove(id) != null
  }

  override fun isRunning(id: RunId): Boolean = runners.containsKey(id)

  override val anyRunning: Boolean
    get() = runners.any()
}
