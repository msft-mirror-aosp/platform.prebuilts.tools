package com.google.testing.platform.lib.cancellation

import com.google.testing.platform.api.cancel.PluginCancellationContext
import com.google.testing.platform.core.error.UtpException

/**
 * Class that delegates to the global singleton [ProcessCancellationContext] object to trigger
 * cancellation. This class also exposes the API visible to plugins via the
 * [PluginCancellationContext] interface.
 */
class PluginCancellationDelegate
constructor(
  private val processCancellationContext: ProcessCancellationContext,
  private val cancelBlock: (() -> Unit)? = null,
) : PluginCancellationContext {

  override fun isCancelling() = processCancellationContext.isCancelling

  override fun isAborting() = processCancellationContext.isAborting

  override fun cancel(cancelReason: UtpException) {
    processCancellationContext.cancel(cancelReason = cancelReason, cancelBlock = cancelBlock)
  }
}
