/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.errorprone.annotations.ThreadSafe
import com.google.protobuf.Parser
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.events
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.plugin.CLEAR_PLATFORM_ERRORS_EVENT
import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.api.plugin.PluginException
import com.google.testing.platform.api.plugin.eventName
import com.google.testing.platform.api.plugins.PluginConfigImpl
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.core.event.MutableEvents
import com.google.testing.platform.core.event.consume
import com.google.testing.platform.core.event.consumeEnum
import com.google.testing.platform.core.plugin.PluginErrorSummary
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.lib.cancellation.PluginCancellationDelegate
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.AndroidSdkProto.AndroidSdk
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixture
import com.google.testing.platform.proto.api.core.ErrorProto.Error
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.testCase
import java.time.Duration
import java.util.logging.Level
import java.util.logging.Logger
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException

/** Utility class that invokes lifecycle methods of a set of [HostPlugin]s. */
class PluginLifecycle
constructor(
  pluginProviderFactory: PluginProviderFactory,
  pluginGraphFactory: PluginGraphFactory,
  private val testFixture: TestFixture,
  private val cancellationContext: ProcessCancellationContext,
  private val pluginCancellationDelegate: PluginCancellationDelegate,
  private val pluginCleanupTimeout: Duration,
  private val logger: Logger,
) {
  @Inject
  constructor(
    pluginProviderFactory: PluginProviderFactory,
    pluginGraphFactory: PluginGraphFactory,
    testFixture: TestFixture,
    cancellationContext: ProcessCancellationContext,
    pluginCancellationDelegate: PluginCancellationDelegate,
    pluginCleanupTimeout: Duration,
  ) : this(
    pluginProviderFactory,
    pluginGraphFactory,
    testFixture,
    cancellationContext,
    pluginCancellationDelegate,
    pluginCleanupTimeout,
    defaultLogger,
  )

  /**
   * Hook the [TestResultPublisher] for its involvement in the test life cycle.
   *
   * This does not hook beforeTestSuite, which needs to be called after test discovery, while
   * [onBeforeAll] needs to be called before test discovery.
   */
  fun hookPublisher(
    publisher: TestResultPublisher,
    deviceController: DeviceController,
  ): TestResultPublisher =
    object : TestResultPublisher by publisher {
      override fun beforeTest(testCase: TestCase) {
        onBeforeEach(testCase, deviceController)
        publisher.beforeTest(testCase)
      }

      override fun afterTest(testResult: TestResult) {
        // If a test is ignored or cancelled, don't even tell the plugins about it. Do tell them
        // about SKIPPED, as that is how tests show up on multidevice when they don't exist on
        // auxiliary test suites.
        if (testResult.testStatus in setOf(TestStatus.IGNORED, TestStatus.CANCELLED)) {
          publisher.afterTest(testResult)
        } else {
          publisher.afterTest(onAfterEach(testResult, deviceController))
        }
      }
    }

  enum class Ordering(val phase: String) {
    CONFIGURE("configure"),
    BEFORE_ALL("beforeAll"),
    BEFORE_EACH("beforeEach"),
    AFTER_EACH("afterEach"),
    AFTER_ALL("afterAll"),
  }

  // The PluginGraph provides the plugins as a sequence so as to lazily apply intermediate
  // processing steps on each element of the sequence. This allows filters to check for
  // the cancellation signal in between plugin operations, which could be time consuming.
  private val plugins = pluginGraphFactory.create(pluginProviderFactory.create().plugins)
  // Only calculate the beforeEach and afterEach graphs once.
  private lateinit var beforeEachPlugins: Sequence<HostPlugin>
  private lateinit var afterEachPlugins: Sequence<HostPlugin>
  private val pluginToContextMap = mutableMapOf<String, Context>()
  private lateinit var context: Context

  val HostPlugin.events: Events
    get() = pluginToContextMap[this.javaClass.name]!!.events

  /**
   * After a lifecycle method runs, check to see whether the plugin emitted a TestStatus as one of
   * its events. If at least one TestStatus was emitted, return the last one and log a warning.
   *
   * @return The last TestStatus emitted by the plugin as an event, or null if no TestStatus was
   *   emitted
   */
  private fun HostPlugin.checkAndReturnLastStatus(order: Ordering): TestStatus? {
    val events = this.events as MutableEvents
    val name = this.javaClass.name
    with(events.consumeEnum<TestStatus>()) {
      return if (this.isNotEmpty()) {
        val lastStatus = this.last()
        logger.warning("Plugin $name explicitly emitted status $lastStatus in ${order.phase}")
        lastStatus
      } else {
        null
      }
    }
  }

  /**
   * When a HostPlugin runs, use its custom Context to verify that the code running in the provided
   * block gets and sends the events it has specified in annotations.
   */
  private fun <R> HostPlugin.verify(
    phase: Ordering,
    maybeProvides: Set<String> = emptySet(),
    block: () -> R,
  ): R = this.events.verify(phase.phase, maybeProvides) { block() }

  private fun MutableEvents.consumeTestResultUpdates(testResult: TestResult): List<TestResult> {
    val messages = this.consume(testResult.eventName)
    @Suppress("UNCHECKED_CAST")
    val parser = TestResult::class.java.getMethod("parser").invoke(null) as Parser<TestResult>
    return messages.map { parser.parseFrom(it) }
  }

  /**
   * Invokes the [HostPlugin.configure] method on all plugins.
   *
   * @param testFixtureProto host plugin configuration is stored inside a [TestFixture].
   */
  fun onConfigure(testFixtureProto: TestFixture, context: Context) =
    Telemetry.createEvent("$TELEMETRY_EVENT_PREFIX.onConfigure") {
        phase = TestPhase.SETUP
        run {
          this@PluginLifecycle.context = context
          val protoConfigs = testFixtureProto.hostPluginList
          // TODO(b/204658333): Keep the current behavior for now. Follow up in design discussion.
          plugins
            .order(context, Ordering.CONFIGURE.phase)
            .filter { !cancellationContext.isCancelling }
            .forEach { plugin ->
              val pluginClassToConfig = protoConfigs.associateBy { it.className }
              val pluginName = plugin.javaClass.name
              invokeOrThrow(pluginName, "onConfigure", TestPhase.SETUP, logger) {
                val extensionProto =
                  pluginClassToConfig[pluginName]
                    ?: throw PluginException(
                      PluginErrorSummary.PLUGIN_CONFIG_ERROR,
                      "Failed to find host plugin config for $pluginName",
                    )

                val pluginConfiguration =
                  PluginConfigImpl(
                    environmentProto = testFixture.environment,
                    androidSdkProto =
                      if (testFixture.environment.hasAndroidEnvironment()) {
                        testFixture.environment.androidEnvironment.androidSdk
                      } else AndroidSdk.getDefaultInstance(),
                    testSetupProto = testFixture.setup,
                    configProto = if (extensionProto.hasConfig()) extensionProto.config else null,
                    configResource =
                      if (extensionProto.hasResource()) extensionProto.resource else null,
                  )
                val pluginContext =
                  plugins.customContext(
                    context,
                    pluginConfiguration,
                    pluginCancellationDelegate,
                    plugin,
                  )
                pluginToContextMap[pluginName] = pluginContext
                plugin.verify(Ordering.CONFIGURE) { plugin.configure(pluginContext) }
              }
            }
        }
      }
      .getOrThrow()

  /**
   * Invoke the [HostPlugin#beforeAll] method on all plugins.
   *
   * @param deviceController the deviceController passed to [HostPlugin]s.
   */
  fun onBeforeAll(deviceController: DeviceController) =
    Telemetry.createEvent("$TELEMETRY_EVENT_PREFIX.onBeforeAll") {
        phase = TestPhase.SETUP
        run {
          // TODO(b/204658333): Keep the current behavior for now. Follow up in design discussion.
          plugins
            .order(context, Ordering.BEFORE_ALL.phase)
            .filter { it.canRun() && !cancellationContext.isCancelling }
            .forEach { plugin ->
              invokeOrThrow(plugin.javaClass.name, "onBeforeAll", TestPhase.SETUP, logger) {
                plugin.verify(Ordering.BEFORE_ALL) { plugin.beforeAll(deviceController) }
              }
            }
        }
      }
      .getOrThrow()

  /** Invoke the [HostPlugin.beforeEach] method on all plugins. */
  fun onBeforeEach(testCase: TestCase?, deviceController: DeviceController) {
    val testNameSuffix =
      if (testCase == null) {
        ""
      } else {
        " ${testCase.getTestCaseName()}"
      }
    if (!::beforeEachPlugins.isInitialized) {
      beforeEachPlugins = plugins.order(context, Ordering.BEFORE_EACH.phase)
    }
    return Telemetry.createEvent("$TELEMETRY_EVENT_PREFIX.onBeforeEach") {
        displayName = "$TELEMETRY_EVENT_PREFIX.onBeforeEach$testNameSuffix"
        phase = TestPhase.TEST_SETUP
        run {
          // TODO(b/204658333): Keep the current behavior for now. Follow up in design discussion.
          beforeEachPlugins
            .filter { it.canRun() && !cancellationContext.isCancelling }
            .forEach { plugin ->
              invokeOrThrow(
                plugin.javaClass.name,
                "onBeforeEach",
                TestPhase.TEST_SETUP,
                logger,
                testCase?.getTestCaseName(),
              ) {
                plugin.verify(Ordering.BEFORE_EACH) {
                  plugin.beforeEach(testCase, deviceController)
                }
              }
            }
        }
      }
      .getOrThrow()
  }

  /**
   * Invoke the [HostPlugin.afterEach] method on all plugins.
   *
   * @param testResult the testResult passed to [HostPlugin]s. Test results from different plugins
   *   are merged together, so that plugins can mutate the state of the test result or attach
   *   [Artifact]s to it.
   * @return the merged test result.
   * @see <a
   *   href="https://developers.google.com/protocol-buffers/docs/reference/java/com/google/protobuf/Message.Builder#mergeFrom-com.google.protobuf.Message-">
   *   Message.Builder mergeFrom(Message other)</a>
   */
  fun onAfterEach(testResult: TestResult, deviceController: DeviceController): TestResult {
    val testNameSuffix = " ${testResult.testCase.getTestCaseName()}"
    if (!::afterEachPlugins.isInitialized) {
      afterEachPlugins = plugins.order(context, Ordering.AFTER_EACH.phase)
    }

    return Telemetry.createEvent("$TELEMETRY_EVENT_PREFIX.onAfterEach") {
        displayName = "$TELEMETRY_EVENT_PREFIX.onAfterEach$testNameSuffix"
        phase = TestPhase.TEST_TEARDOWN
        run {
          var eventStatus: TestStatus? = null
          val testErrors = mutableListOf<Error>()
          val testArtifacts = mutableListOf<Artifact>()
          val testResultUpdates = mutableListOf<TestResult>()
          val pluginSequence = afterEachPlugins.filter { it.canRun() }
          pluginSequence.forEach { plugin ->
            try {
              invokeOrThrow(
                plugin.javaClass.name,
                "onAfterEach",
                TestPhase.TEST_TEARDOWN,
                logger,
                testResult.testCase.getTestCaseName(),
              ) {
                plugin.verify(
                  Ordering.AFTER_EACH,
                  AFTER_EACH_RESULT_EVENTS + setOf(testResult.eventName),
                ) {
                  plugin.afterEach(testResult, deviceController, cancellationContext.isCancelling)
                }
              }
            } finally {
              if (plugin.events is MutableEvents) {
                val events = plugin.events as MutableEvents

                plugin.checkAndReturnLastStatus(Ordering.AFTER_EACH)?.let { eventStatus = it }
                testErrors.addAll(events.consume())
                testArtifacts.addAll(events.consume())
                testResultUpdates.addAll(events.consumeTestResultUpdates(testResult))
              } else {
                logger.warning(
                  """
                  |Plugin ${plugin.javaClass.name} using events type
                  ${plugin.events.javaClass.name}. Result updates via the event system are not
                  compatible with this implementation
                  """
                    .trimMargin()
                )
              }
            }
          }

          return@run with(testResult.toBuilder()) {
              eventStatus?.let { testStatus = it }
              if (testErrors.isNotEmpty()) {
                error = testErrors.last()
              }
              addAllOutputArtifact(testArtifacts.distinctBy { it })
              testResultUpdates.forEach { update -> mergeFrom(update) }
              build()
            }
            .canonicalize()
        }
      }
      .getOrThrow()
  }

  /**
   * Invoke the [HostPlugin.afterAll] method on all plugins.
   *
   * This method will run even if the UTP execution has been cancelled.
   *
   * @param testSuiteResult the testSuiteResult passed to the [HostPlugin]s.
   * @param deviceController the deviceController to pass to a [HostPlugin]s.
   * @return the testSuiteResult.
   * @throws TimeoutCancellationException if the plugins collectively exceed the cleanup timeout.
   */
  fun onAfterAll(
    testSuite: TestSuiteMetaData,
    publisher: TestResultPublisher,
    deviceController: DeviceController,
  ) {
    Telemetry.createEvent("$TELEMETRY_EVENT_PREFIX.onAfterAll") {
      val testSuiteResult = publisher.workingDraft(testSuite)
      phase = TestPhase.TEARDOWN
      run {
        val pluginSequence = plugins.order(context, Ordering.AFTER_ALL.phase).filter { it.canRun() }
        val updateEventNames = testSuiteResult.testResultList.map { it.eventName }

        cancellationContext.runWithTimeoutDuringCancellation(pluginCleanupTimeout.toMillis()) {
          pluginSequence.forEach { plugin ->
            try {
              invokeOrThrow(plugin.javaClass.name, "onAfterAll", TestPhase.TEARDOWN, logger) {
                plugin.verify(Ordering.AFTER_ALL, AFTER_ALL_RESULT_EVENTS + updateEventNames) {
                  plugin.afterAll(
                    testSuiteResult,
                    deviceController,
                    cancellationContext.isCancelling,
                  )
                }
              }
            } catch (throwable: Throwable) {
              // All plugins run afterAll so they have a chance to clean up even if one plugin
              // threw an exception from afterAll.
              logger.severe(
                "Plugin ${plugin.javaClass.name}.afterAll failure: ${throwable.stackTraceToString()}"
              )
              publisher.failTestSuite(testSuite, throwable)
            } finally {
              if (plugin.events is MutableEvents) {
                publisher.consumeSuiteEvents(plugin.events as MutableEvents, testSuite, plugin)
              } else {
                logger.warning(
                  """
                    |Plugin ${plugin.javaClass.name} using events type
                    ${plugin.events.javaClass.name}. Result updates via the event system are not
                    compatible with this implementation
                    """
                    .trimMargin()
                )
              }
            }
          }
        }
      }
    }
  }

  private fun TestResultPublisher.consumeSuiteEvents(
    events: MutableEvents,
    testSuite: TestSuiteMetaData,
    plugin: HostPlugin,
  ) {
    if (events.consume(CLEAR_PLATFORM_ERRORS_EVENT).isNotEmpty()) {
      clearFailures(testSuite)
    }
    for (artifact in events.consume<Artifact>().filterNoSourcePath().distinctBy { it }) {
      addTestSuiteArtifact(testSuite, artifact)
    }
    for (issue in events.consume<Issue>().distinctBy { it }) {
      addTestSuiteIssue(testSuite, issue)
    }
    for (testResult in events.consume<TestResult>().distinctBy { it }) {
      afterTest(testResult)
    }
    for (testResult in workingDraft(testSuite).testResultList) {
      for (update in events.consumeTestResultUpdates(testResult)) {
        afterTest(update)
      }
    }
    plugin.checkAndReturnLastStatus(Ordering.AFTER_ALL)?.let { setTestSuiteStatus(testSuite, it) }
  }

  private fun TestResult.canonicalize(): TestResult {
    return this.toBuilder()
      .apply {
        // Remove all duplicate class annotations.
        testCaseBuilder.clearTestClassAnnotation()
        testCaseBuilder.addAllTestClassAnnotation(
          this@canonicalize.testCase.testClassAnnotationList.distinctBy { it }
        )

        // Remove all duplicate method annotations.
        testCaseBuilder.clearTestMethodAnnotation()
        testCaseBuilder.addAllTestMethodAnnotation(
          this@canonicalize.testCase.testMethodAnnotationList.distinctBy { it }
        )

        // Remove all duplicate artifacts and filter out all artifacts with no sourcePath.
        clearOutputArtifact()
        addAllOutputArtifact(
          this@canonicalize.outputArtifactList.distinctBy { it }.filterNoSourcePath()
        )
      }
      .build()
  }

  private fun List<Artifact>.filterNoSourcePath(): List<Artifact> {
    return this.filter {
      if (it.sourcePath.path.isNullOrBlank()) {
        logger.warning(
          """
            Filtering out output artifact with destination path = '${it.destinationPath.path}' and
            label '${it.label}' in output artifacts because it has no source path. It is up to the
            plugins to properly process this artifact and add artifacts with the corresponding
            source paths to the list of output artifacts.
          """
            .trimMargin()
        )
        false
      } else {
        true
      }
    }
  }

  companion object {
    @JvmStatic private val defaultLogger = getLogger()

    private const val TELEMETRY_EVENT_PREFIX = "PluginLifecycle"

    private val AFTER_EACH_RESULT_EVENTS =
      setOf(Artifact::class.java.name, Error::class.java.name, TestStatus::class.java.name)
    private val AFTER_ALL_RESULT_EVENTS =
      setOf(
        Artifact::class.java.name,
        Issue::class.java.name,
        TestResult::class.java.name,
        TestStatus::class.java.name,
        CLEAR_PLATFORM_ERRORS_EVENT,
      )
  }
}

/**
 * Invokes the block with `this`, catches all exceptions and wraps them in a [PluginException].
 *
 * @param testCase name of the test case for which beforeEach/afterEach lifecycle call is performed.
 * @param pluginName the [HostPlugin] the call is performed on.
 * @param lifecycleEventName name of the lifecycle call invoked on the [HostPlugin].
 * @param block lambda function that performs calls on a [HostPlugin].
 * @throws [PluginException] if an error occurred during block invocation.
 */
private fun invokeOrThrow(
  pluginName: String,
  lifecycleEventName: String,
  testPhase: TestPhase,
  logger: Logger,
  testCase: String? = null,
  block: () -> Unit,
) {
  try {
    val pluginShortName = pluginName.substring(pluginName.lastIndexOf(".") + 1)
    // add test name to display name if applicable
    val testNameSuffix =
      if (testCase != null) {
        " $testCase"
      } else {
        ""
      }
    return Telemetry.createEvent<Unit>("$pluginName.$lifecycleEventName") {
        // note that this is "$pluginShortName.$lifecycleEventName $testCase" if the case is
        // specified, "$pluginShortName.$lifecycleEventName" otherwise
        displayName = "$pluginShortName.$lifecycleEventName$testNameSuffix"
        phase = testPhase
        run { block() }
      }
      .getOrThrow()
  } catch (x: CancellationException) {
    // Do not rethrow the exception; simply make a note of it.
    logger.log(Level.WARNING, "Plugin ${pluginName} was cancelled in $lifecycleEventName.", x)
    return
  } catch (x: PluginException) {
    // We can presume the plugin knows what it's doing.
    throw x
  } catch (utpEx: UtpException) {
    // Propagate the underlying exception message so that it is visible at the top for consumers.
    throw PluginException(
      message = utpEx.message ?: "Exception thrown in Host Plugin.",
      errorSummary = PluginErrorSummary.PLUGIN_ERROR,
      cause = utpEx,
    )
  } catch (throwable: Throwable) {
    // The call stack can be quite long, so repeat the message of the throwable in the
    // PluginException.
    throw PluginException(
      PluginErrorSummary.PLUGIN_ERROR,
      "Exception thrown during $lifecycleEventName invocation of " +
        "plugin ${pluginName.split(".").last()}" +
        "${testCase?.let { " for test case $it" } ?: ""}: ${throwable.message}",
      throwable,
    )
  }
}

/** Gets the full test method name from the [TestCase] proto. */
private fun TestCase.getTestCaseName() = "${this.testClass}#${this.testMethod}"
