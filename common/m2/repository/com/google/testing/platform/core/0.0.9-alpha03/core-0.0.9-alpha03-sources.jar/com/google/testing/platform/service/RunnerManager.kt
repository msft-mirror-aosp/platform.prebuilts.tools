/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.service

import com.google.testing.platform.Runner
import com.google.testing.platform.proto.api.service.RunIdProto.RunId
import kotlin.coroutines.CoroutineContext

/** Manages performing atomic runs and cancels of [Runner]s. */
interface RunnerManager {
  /**
   * Starts the runner specified in the request.
   *
   * @param [RunId] unique for each managed [Runner]
   * @param [Runner] to run
   * @return [Boolean] [true] if unique and ran, else [false]
   */
  fun run(id: RunId, runner: Runner): Boolean

  /**
   * Cancels active [Runner] identified by [id].
   *
   * @param [RunId] id of [Runner] to cancel.
   * @return [Boolean] [true] if active [Runner] with [id] was found, else [false]
   */
  fun cancel(id: RunId): Boolean

  /** @return [Boolean] [true] if there is an active [Runner] identified by [id]. */
  fun isRunning(id: RunId): Boolean

  /** @return [Boolean] [true] if there is any active [Runner]s */
  val anyRunning: Boolean

  /** The coroutine context in which the RunnerManager operates. */
  val coroutineContext: CoroutineContext
}
