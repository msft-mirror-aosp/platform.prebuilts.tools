/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.testing.platform.api.config.Config
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig

/**
 * [Config] containing a [RunnerConfig] proto for "proxy" classes to correctly construct a new
 * [com.google.testing.platform.api.config.ConfigBase] for the class they are delegating to.
 *
 * @see com.google.testing.platform.api.config.ConfigBase
 * @see com.google.testing.platform.executor.DeviceProviderProxy
 */
data class ProxyConfig(
  val runnerConfig: RunnerConfig,
  val deviceId: DeviceId,
  val testFixtureId: TestFixtureId
) : Config
