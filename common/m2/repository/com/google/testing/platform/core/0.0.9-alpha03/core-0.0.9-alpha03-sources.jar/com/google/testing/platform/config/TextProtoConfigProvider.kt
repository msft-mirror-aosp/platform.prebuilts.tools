/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.protobuf.Message
import com.google.protobuf.TextFormat
import com.google.protobuf.TextFormat.ParseException
import com.google.testing.platform.config.inject.BaseMessageProvider
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets.UTF_8
import javax.inject.Inject
import javax.inject.Provider

/**
 * Parses a .textproto file that contains configuration values.
 *
 * The configuration file can be specified as a text proto and contain multiple configuration
 * sections, for example:
 *
 * <pre>{@code
 * target_runtime {
 *   identifier: ANDROID
 *   android_sdk_config {
 *     sdk_path: "path/to/sdk"
 * }}</pre>
 */
class TextProtoConfigProvider<T : Message> @Inject constructor(
  path: String,
  @BaseMessageProvider private val baseMessageProvider: Provider<T>
) : FileConfigProvider<T>(path) {

  /**
   * Returns a T : [Message] from a text proto.
   *
   * @throws [ConfigurationException] if the file can't be parsed
   */
  override fun getConfigFrom(stream: InputStream): T {
    try {
      val messageBuilder = baseMessageProvider.get().toBuilder()
      InputStreamReader(stream, UTF_8).use { reader ->
        TextFormat.merge(reader, messageBuilder)
      }

      @Suppress("UNCHECKED_CAST")
      return messageBuilder.build() as T
    } catch (pe: ParseException) {
      throw ConfigurationException("Invalid Text Protocol Buffer file: $path", pe)
    }
  }
}
