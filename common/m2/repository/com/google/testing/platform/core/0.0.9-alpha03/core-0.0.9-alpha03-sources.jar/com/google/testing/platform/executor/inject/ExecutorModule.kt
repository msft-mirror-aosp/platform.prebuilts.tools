/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor.inject

import com.google.testing.platform.core.executor.Executor
import com.google.testing.platform.executor.MultiDeviceExecutor
import com.google.testing.platform.executor.SingleDeviceExecutor
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.result.inject.ListenerModule
import dagger.Lazy
import dagger.Module
import dagger.Provides

/**
 * Dagger module to add the [com.google.testing.platform.core.executor.Executor] dependencies to the
 * object graph.
 */
@Module(
  includes =
    [SingleDeviceExecutorModule::class, MultiDeviceExecutorModule::class, ListenerModule::class]
)
class ExecutorModule {

  @Provides
  fun executor(
    runnerConfig: RunnerConfig,
    singleDeviceExecutor: Lazy<SingleDeviceExecutor>,
    multiDeviceExecutor: Lazy<MultiDeviceExecutor>
  ): Executor {
    // Another possible approach here is to instantiate the executors directly based on the config,
    // rather than relying on the Lazy objects coming from individual modules. At this time, I don't
    // see an advantage to that refactoring; if we run into difficulty debugging the injection of
    // Executors, fixing this would be a good place to start.
    when {
      runnerConfig.hasSingleDeviceExecutor() -> return singleDeviceExecutor.get()
      runnerConfig.hasMultiDeviceExecutor() -> return multiDeviceExecutor.get()
      else -> throw IllegalStateException("RunnerConfig does not have a supported executor")
    }
  }
}
