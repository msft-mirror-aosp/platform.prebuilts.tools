/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.event

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

const val NAMESPACE = "com.google.testing.platform"

/**
 * Different error summaries for events. Each error summary contains a name, type, code and
 * namespace.
 */
enum class EventErrorSummary(override val errorCode: Int, override val errorType: Enum<*>) :
  ErrorSummary {

  /** An extension did not provide all events that it declared in its annotations. */
  NOT_PROVIDING_DECLARED_EVENTS(5001, ErrorType.UNDERLYING_TOOL),

  /** An extension is providing events it did not declare in its annotations. */
  PROVIDING_UNDECLARED_EVENT(5002, ErrorType.UNDERLYING_TOOL),

  /** An extension attempted to read an event it did not declare in its annotations. */
  READING_UNDECLARED_EVENT(5003, ErrorType.UNDERLYING_TOOL),

  /** An extension did not read an event it required in its annotations. */
  FAILURE_TO_READ_EVENT(5004, ErrorType.UNDERLYING_TOOL),

  /** Unable to determine this event error type */
  UNDETERMINED(5999, ErrorType.UNDERLYING_TOOL);

  override val errorName = this.name
  override val namespace = NAMESPACE
}
