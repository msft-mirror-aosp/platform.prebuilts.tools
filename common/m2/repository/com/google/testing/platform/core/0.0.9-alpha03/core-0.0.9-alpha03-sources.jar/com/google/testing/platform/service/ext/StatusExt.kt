/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.service.ext

import com.google.protobuf.Any as AnyProto
import com.google.protobuf.Message
import com.google.rpc.Status as StatusProto
import io.grpc.Status

/**
 * Converts [Status] to [StatusProto].
 */
fun Status.toMessage(): StatusProto =
  let {
    StatusProto.newBuilder().apply {
      code = it.code.ordinal
      it.description?.let { message = it }
    }.build()
  }

/**
 * Converts [Status] to [StatusProto], including a details field.
 *
 * @param [Message] details message
 */
fun Status.toMessage(details: Message): StatusProto =
  let {
    StatusProto.newBuilder().let { builder ->
      builder.code = it.code.ordinal
      it.description?.let { builder.message = it }
      builder.addDetails(AnyProto.pack(details))
    }.build()
  }
