package com.google.testing.platform.server.inject;

import com.google.testing.platform.service.RunnerServiceImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import io.grpc.BindableService;
import javax.annotation.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class CoreServicesModule_ProvidesRunnerServiceFactory implements Factory<BindableService> {
  private final CoreServicesModule module;

  private final Provider<RunnerServiceImpl> serviceProvider;

  public CoreServicesModule_ProvidesRunnerServiceFactory(CoreServicesModule module,
      Provider<RunnerServiceImpl> serviceProvider) {
    this.module = module;
    this.serviceProvider = serviceProvider;
  }

  @Override
  public BindableService get() {
    return providesRunnerService(module, serviceProvider.get());
  }

  public static CoreServicesModule_ProvidesRunnerServiceFactory create(CoreServicesModule module,
      Provider<RunnerServiceImpl> serviceProvider) {
    return new CoreServicesModule_ProvidesRunnerServiceFactory(module, serviceProvider);
  }

  public static BindableService providesRunnerService(CoreServicesModule instance,
      RunnerServiceImpl service) {
    return Preconditions.checkNotNullFromProvides(instance.providesRunnerService(service));
  }
}
