package com.google.testing.platform.main.inject;

import com.google.common.collect.ImmutableSet;
import com.google.testing.platform.api.event.Events;
import com.google.testing.platform.config.CommandLineArgs;
import com.google.testing.platform.config.ConfigProvider;
import com.google.testing.platform.config.ProtoConfigProvider;
import com.google.testing.platform.config.inject.ConfigModule_ProvidesBinaryParserFactory;
import com.google.testing.platform.config.inject.ConfigModule_ProvidesRunnerConfigBaseMessageFactory;
import com.google.testing.platform.core.event.inject.EventsModule;
import com.google.testing.platform.core.event.inject.EventsModule_EventsFactory;
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext;
import com.google.testing.platform.proto.api.config.RunnerConfigProto;
import com.google.testing.platform.proto.api.service.ServerConfigProto;
import com.google.testing.platform.server.ServerStrategy;
import com.google.testing.platform.server.inject.ConfigModule;
import com.google.testing.platform.server.inject.ConfigModule_BinaryParserFactory;
import com.google.testing.platform.server.inject.ConfigModule_ServerConfigBaseProviderFactory;
import dagger.internal.DaggerGenerated;
import dagger.internal.DoubleCheck;
import dagger.internal.InstanceFactory;
import dagger.internal.Preconditions;
import dagger.internal.SingleCheck;
import java.util.Set;
import javax.annotation.Generated;
import javax.inject.Provider;
import kotlinx.coroutines.CoroutineDispatcher;
import kotlinx.coroutines.CoroutineScope;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DaggerMainComponent {
  private DaggerMainComponent() {
  }

  public static MainComponent.Builder builder() {
    return new Builder();
  }

  private static final class Builder implements MainComponent.Builder {
    private String[] args;

    private ProcessCancellationContext cancellationContext;

    private CoroutineDispatcher rootCoroutineDispatcher;

    @Override
    public Builder args(String[] args) {
      this.args = Preconditions.checkNotNull(args);
      return this;
    }

    @Override
    public Builder cancellationContext(ProcessCancellationContext cancellationContext) {
      this.cancellationContext = Preconditions.checkNotNull(cancellationContext);
      return this;
    }

    @Override
    public Builder rootCoroutineDispatcher(CoroutineDispatcher dispatcher) {
      this.rootCoroutineDispatcher = Preconditions.checkNotNull(dispatcher);
      return this;
    }

    @Override
    public MainComponent build() {
      Preconditions.checkBuilderRequirement(args, String[].class);
      Preconditions.checkBuilderRequirement(cancellationContext, ProcessCancellationContext.class);
      Preconditions.checkBuilderRequirement(rootCoroutineDispatcher, CoroutineDispatcher.class);
      return new MainComponentImpl(new MainModule(), new EventsModule(), new CommandLineModule(), new ConfigModule(), new com.google.testing.platform.config.inject.ConfigModule(), args, cancellationContext, rootCoroutineDispatcher);
    }
  }

  private static final class MainComponentImpl implements MainComponent {
    private final MainModule mainModule;

    private final String[] args;

    private final CommandLineModule commandLineModule;

    private final ConfigModule configModule;

    private final com.google.testing.platform.config.inject.ConfigModule configModule2;

    private final ProcessCancellationContext cancellationContext;

    private final MainComponentImpl mainComponentImpl = this;

    private Provider<ServerConfigProto.ServerConfig> serverConfigBaseProvider;

    private Provider<RunnerConfigProto.RunnerConfig> providesRunnerConfigBaseMessageProvider;

    private Provider<CoroutineDispatcher> rootCoroutineDispatcherProvider;

    private Provider<CoroutineScope> rootCoroutineScopeProvider;

    private Provider<Events> eventsProvider;

    private MainComponentImpl(MainModule mainModuleParam, EventsModule eventsModuleParam,
        CommandLineModule commandLineModuleParam, ConfigModule configModuleParam,
        com.google.testing.platform.config.inject.ConfigModule configModuleParam2,
        String[] argsParam, ProcessCancellationContext cancellationContextParam,
        CoroutineDispatcher rootCoroutineDispatcherParam) {
      this.mainModule = mainModuleParam;
      this.args = argsParam;
      this.commandLineModule = commandLineModuleParam;
      this.configModule = configModuleParam;
      this.configModule2 = configModuleParam2;
      this.cancellationContext = cancellationContextParam;
      initialize(mainModuleParam, eventsModuleParam, commandLineModuleParam, configModuleParam, configModuleParam2, argsParam, cancellationContextParam, rootCoroutineDispatcherParam);

    }

    private CommandLineArgs commandLineArgs() {
      return new CommandLineArgs(args);
    }

    private ConfigProvider<ServerConfigProto.ServerConfig> providesServerTextProtoProvider() {
      return CommandLineModule_ProvidesServerTextProtoProviderFactory.providesServerTextProtoProvider(commandLineModule, commandLineArgs(), serverConfigBaseProvider);
    }

    private ConfigProvider<ServerConfigProto.ServerConfig> providesServerBinaryProtoProvider() {
      return CommandLineModule_ProvidesServerBinaryProtoProviderFactory.providesServerBinaryProtoProvider(commandLineModule, commandLineArgs(), ConfigModule_BinaryParserFactory.binaryParser(configModule));
    }

    private Set<ConfigProvider<ServerConfigProto.ServerConfig>> setOfConfigProviderOfServerConfig(
        ) {
      return ImmutableSet.<ConfigProvider<ServerConfigProto.ServerConfig>>of(providesServerTextProtoProvider(), providesServerBinaryProtoProvider());
    }

    private ProtoConfigProvider<ServerConfigProto.ServerConfig> protoConfigProviderOfServerConfig(
        ) {
      return new ProtoConfigProvider<ServerConfigProto.ServerConfig>(setOfConfigProviderOfServerConfig(), serverConfigBaseProvider);
    }

    private ServerConfigProto.ServerConfig.Builder serverConfigBuilder() {
      return configModule.serverConfig(protoConfigProviderOfServerConfig());
    }

    private ServerConfigProto.ServerConfig serverConfig() {
      return commandLineModule.providesOverrideServerConfig(commandLineArgs(), serverConfigBuilder());
    }

    private ConfigProvider<RunnerConfigProto.RunnerConfig> providesBinaryProvider() {
      return CommandLineModule_ProvidesBinaryProviderFactory.providesBinaryProvider(commandLineModule, commandLineArgs(), ConfigModule_ProvidesBinaryParserFactory.providesBinaryParser(configModule2));
    }

    private ConfigProvider<RunnerConfigProto.RunnerConfig> providesTextProvider() {
      return CommandLineModule_ProvidesTextProviderFactory.providesTextProvider(commandLineModule, commandLineArgs(), providesRunnerConfigBaseMessageProvider);
    }

    private Set<ConfigProvider<RunnerConfigProto.RunnerConfig>> setOfConfigProviderOfRunnerConfig(
        ) {
      return ImmutableSet.<ConfigProvider<RunnerConfigProto.RunnerConfig>>of(providesBinaryProvider(), providesTextProvider());
    }

    private ProtoConfigProvider<RunnerConfigProto.RunnerConfig> protoConfigProviderOfRunnerConfig(
        ) {
      return new ProtoConfigProvider<RunnerConfigProto.RunnerConfig>(setOfConfigProviderOfRunnerConfig(), providesRunnerConfigBaseMessageProvider);
    }

    private RunnerConfigProto.RunnerConfig runnerConfig() {
      return configModule2.providesRunnerConfig(protoConfigProviderOfRunnerConfig());
    }

    @SuppressWarnings("unchecked")
    private void initialize(final MainModule mainModuleParam, final EventsModule eventsModuleParam,
        final CommandLineModule commandLineModuleParam, final ConfigModule configModuleParam,
        final com.google.testing.platform.config.inject.ConfigModule configModuleParam2,
        final String[] argsParam, final ProcessCancellationContext cancellationContextParam,
        final CoroutineDispatcher rootCoroutineDispatcherParam) {
      this.serverConfigBaseProvider = ConfigModule_ServerConfigBaseProviderFactory.create(configModuleParam);
      this.providesRunnerConfigBaseMessageProvider = ConfigModule_ProvidesRunnerConfigBaseMessageFactory.create(configModuleParam2);
      this.rootCoroutineDispatcherProvider = InstanceFactory.create(rootCoroutineDispatcherParam);
      this.rootCoroutineScopeProvider = DoubleCheck.provider(MainModule_RootCoroutineScopeFactory.create(mainModuleParam, rootCoroutineDispatcherProvider));
      this.eventsProvider = SingleCheck.provider(EventsModule_EventsFactory.create(eventsModuleParam));
    }

    @Override
    public ServerStrategy getStrategy() {
      return MainModule_ProvidesServerStrategyFactory.providesServerStrategy(mainModule, serverConfig(), runnerConfig(), rootCoroutineScopeProvider.get(), cancellationContext, eventsProvider.get());
    }
  }
}
