/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.inject

import com.google.testing.platform.config.v1.extension.androidSdkOrEmpty
import com.google.testing.platform.config.v1.extension.diagnosticsOrEmpty
import com.google.testing.platform.config.v1.extension.firstEnvironmentOrEmpty
import com.google.testing.platform.config.v1.extension.firstTestSetupOrEmpty
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.core.telemetry.common.noop.NoopDiagnostics
import com.google.testing.platform.core.telemetry.opencensus.OpencensusDiagnostics
import com.google.testing.platform.core.telemetry.proto.DiagnosticsProto
import com.google.testing.platform.proto.api.config.RunnerConfigProto
import dagger.Module
import dagger.Provides

/**
 * Creates [Diagnostics] instances via Dagger
 */
@Module
class DiagnosticsModule {

  @Provides
  fun diagnosticsConfig(
    runnerConfig: RunnerConfigProto.RunnerConfig?
  ) = (runnerConfig ?: RunnerConfigProto.RunnerConfig.getDefaultInstance()).diagnosticsOrEmpty

  @Provides
  fun environment(
    runnerConfig: RunnerConfigProto.RunnerConfig?
  ) = (runnerConfig ?: RunnerConfigProto.RunnerConfig.getDefaultInstance()).firstEnvironmentOrEmpty

  @Provides
  fun androidSdk(
    runnerConfig: RunnerConfigProto.RunnerConfig?
  ) = (runnerConfig ?: RunnerConfigProto.RunnerConfig.getDefaultInstance()).androidSdkOrEmpty

  @Provides
  fun testSetup(
    runnerConfig: RunnerConfigProto.RunnerConfig?
  ) = (runnerConfig ?: RunnerConfigProto.RunnerConfig.getDefaultInstance()).firstTestSetupOrEmpty

  @Provides
  fun diagnostics(
    diagnostics: OpencensusDiagnostics,
    diagnosticsConfig: DiagnosticsProto.Diagnostics
  ): Diagnostics = if (diagnosticsConfig.enableDiagnostics) {
    Telemetry.diagnostics = diagnostics
    diagnostics
  } else NoopDiagnostics()
}
