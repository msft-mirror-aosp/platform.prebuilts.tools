/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.event

/** Storage for all events across extensions within a single extension "phase". */
class PhaseGlobalEvents : MutableEvents {
  private val eventsMap = mutableMapOf<String, MutableList<ByteArray>>()

  override fun send(event: String, message: ByteArray) {
    val messages = eventsMap.getOrDefault(event, mutableListOf())
    messages.add(message)
    eventsMap[event] = messages
  }

  override fun get(event: String): List<ByteArray> {
    return HardenedList(eventsMap.getOrDefault(event, mutableListOf()))
  }

  /**
   * Generally unsafe way of exposing mutable lists since the mutable list _could_ change contents
   * after delegation. However, we know this list won't change because we guarantee that all senders
   * have sent before a getter retrieves this list. Without this wrapper, a clever getter could cast
   * our return value back to a [MutableList] and add whatever they wanted to it.
   */
  private class HardenedList<T>(mutable: MutableList<T>) : List<T> by mutable

  override fun consume(event: String): List<ByteArray> {
    return this.eventsMap.remove(event)?.toList() ?: emptyList()
  }
}
