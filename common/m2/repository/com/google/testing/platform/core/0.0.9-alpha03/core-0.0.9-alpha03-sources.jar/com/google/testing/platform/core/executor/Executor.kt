/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.executor

import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult

/**
 * An executor for running tests.
 *
 * An {@code Executor} knows how to prepare the execution environment, such as installing test apps
 * and data and how to run the tests.
 *
 * {@code configure()} will get called before {@code execute()}.
 */
interface Executor : Cancellable {
  /**
   * Prepare the test execution environment, including running scripts or setting up test data.
   *
   * If [configure] throws an exception, the test runner will stop test execution.
   *
   * @param config Configuration values proto
   */
  fun configure(config: RunnerConfig)

  /**
   * Execute the tests using the underlying test runner(s) and report the results for each test in
   * the suite.
   *
   * @param testResultPublisher Updates the UI to show a progress testResultUpdate.
   * @return Indicates whether the test suite passed or not.
   */
  fun execute(testResultPublisher: TestResultPublisher): List<TestSuiteResult>
}
