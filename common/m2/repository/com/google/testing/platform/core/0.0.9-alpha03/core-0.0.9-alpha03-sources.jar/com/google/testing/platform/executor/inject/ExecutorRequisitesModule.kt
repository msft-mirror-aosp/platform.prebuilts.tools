/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor.inject

import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.error.config.ErrorMessageUpdater
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.net.inject.DaggerPortPickerComponent
import com.google.testing.platform.driver.TestDriverProxy
import com.google.testing.platform.executor.DeviceProviderProxy
import com.google.testing.platform.lib.dagger.LazyImpl
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import dagger.Lazy
import dagger.Module
import dagger.Provides
import dagger.Reusable

/** All the requisites required for creating an Executor. */
@Module
class ExecutorRequisitesModule {
  @Provides
  @Reusable
  fun portPicker(runnerConfig: RunnerConfig): PortPicker? =
    DaggerPortPickerComponent.builder().config(runnerConfig).build().portPicker()

  @Provides
  fun errorMessageUpdater(runnerConfig: RunnerConfig): ErrorUpdater =
    ErrorMessageUpdater(runnerConfig.errorConfig)

  @Provides
  @Reusable
  fun deviceProviders(
    runnerConfig: RunnerConfig,
    portPicker: PortPicker?
  ): Map<DeviceId, @JvmSuppressWildcards Lazy<DeviceProvider<DeviceController>>> =
    runnerConfig.deviceList
      .map { it.deviceId }
      .associateWith { LazyImpl { DeviceProviderProxy(runnerConfig, it, portPicker) } }

  @Provides
  @Reusable
  fun testDriverProviders(
    runnerConfig: RunnerConfig,
    portPicker: PortPicker?
  ): Map<TestFixtureId, @JvmSuppressWildcards Lazy<TestDriver>> =
    runnerConfig.testFixtureList
      .map { it.testFixtureId }
      .associateWith { LazyImpl { TestDriverProxy(runnerConfig, it, portPicker) } }
}
