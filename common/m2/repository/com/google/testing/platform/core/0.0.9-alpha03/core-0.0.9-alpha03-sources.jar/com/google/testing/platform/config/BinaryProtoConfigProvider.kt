/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.config

import com.google.protobuf.InvalidProtocolBufferException
import com.google.protobuf.Message
import com.google.protobuf.Parser
import java.io.BufferedInputStream
import java.io.InputStream
import javax.inject.Inject

/**
 * Parses a binary proto file that contains T : [Message] values.
 *
 * @param filepath path to binary proto file
 */
class BinaryProtoConfigProvider<T : Message> @Inject constructor(
  path: String,
  private val parser: Parser<T>
) : FileConfigProvider<T>(path) {

  /**
   * Returns a T : [Message] from a binary proto.
   *
   * @throws [ConfigurationException] if the file can't be parsed
   */
  override fun getConfigFrom(stream: InputStream): T {
    try {
      return parser.parseFrom(BufferedInputStream(stream))
    } catch (ipbe: InvalidProtocolBufferException) {
      throw ConfigurationException("Invalid Binary Protocol Buffer file: $path", ipbe)
    }
  }
}
