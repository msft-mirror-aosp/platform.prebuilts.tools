/*
 * Copyright (C) 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.coroutines.job

import java.util.logging.Logger
import kotlin.coroutines.Continuation
import kotlin.coroutines.CoroutineContext
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout

/** Given a Job, find the matching CoroutineContext. */
private fun Job.findContext(): CoroutineContext? {
  // AbstractCoroutine is a Job, and a Continuation...
  (this as? Continuation<*>)?.context?.let {
    return it
  }
  // *and* a CoroutineScope!
  (this as? CoroutineScope)?.coroutineContext?.let {
    return it
  }
  this.parent?.findContext()?.let {
    return it
  }
  return null
}

/**
 * Given a Job, make best effort to find a human-readable name for it. A Job created by Job() has no
 * opportunity to add a CoroutineName, but a coroutine job created through launch does.
 */
fun Job.findName(): String {
  this[CoroutineName]?.name?.let {
    return it
  }
  this.findContext()?.get(CoroutineName)?.name?.let {
    return it
  }
  return this.toString()
}

/**
 * Given a Job that is failing to join, log the names of its children every time we hit the timeout.
 */
suspend fun Job.verboseJoin(logger: Logger, timeout: Duration = 1.seconds) {
  while (true) {
    try {
      return withTimeout(timeout) { join() }
    } catch (x: TimeoutCancellationException) {
      logger.info("Job did not join in $timeout")
      for (child in children) {
        logger.info("Child: ${child.findName()}")
      }
    }
  }
}
