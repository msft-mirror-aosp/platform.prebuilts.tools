/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server.strategy

import com.google.testing.platform.Runner
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.config.ConfigurationException
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.inject.DaggerRunnerComponent
import com.google.testing.platform.lib.cancellation.PluginCancellationDelegate
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.coroutines.job.findName
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.server.ServerStrategy
import java.util.logging.Level
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

/**
 * Runs the server for the lifetime of a single [Runner]. Does not allow other runs to be started on
 * the server.
 */
class NonInteractiveServerStrategy
@Inject
constructor(
  private val runnerConfig: RunnerConfig,
  private val diagnostics: Diagnostics,
  private val rootCoroutineScope: CoroutineScope,
  private val cancellationContext: ProcessCancellationContext,
  private val events: Events,
) : ServerStrategy {
  companion object {
    @JvmStatic private val logger = getLogger()
    private const val runnerEventDesc = "Runner.Run"
    private const val runnerCoroutineCleanupEventDesc = "Runner.CoroutineCleanup"
    private const val runnerCancelEventDesc = "Runner.Cancel"
    private const val statusDesc = "Status"
  }

  // Take over management of the top-level backstop SupervisorJob created in MainModule. This is
  // here to facilitate fast cancellation of all UTP coroutines in the event of a test timeout.
  private val rootSupervisorJob: CompletableJob =
    rootCoroutineScope.coroutineContext[Job] as CompletableJob

  private lateinit var runner: Runner

  constructor(
    toRun: Runner,
    diagnostics: Diagnostics,
    rootCoroutineScope: CoroutineScope,
    cancellationContext: ProcessCancellationContext,
    events: Events,
  ) : this(
    RunnerConfig.getDefaultInstance(),
    diagnostics,
    rootCoroutineScope,
    cancellationContext,
    events,
  ) {
    runner = toRun
  }

  /**
   * Starts server and runs single Runner using provided runner config.
   *
   * @returns [Int] from [Runner].run()
   */
  override suspend fun run(): Int {
    if (!this::runner.isInitialized) {
      logger.info("Constructing runner from config.")
      try {
        runner =
          DaggerRunnerComponent.builder()
            .config(runnerConfig)
            .cancellationContext(cancellationContext)
            .events(events)
            .pluginCancellationDelegate(
              PluginCancellationDelegate(cancellationContext) {
                val unused = this@NonInteractiveServerStrategy.cancel(false)
              }
            )
            .rootCoroutineScope(rootCoroutineScope)
            .build()
            .runner
      } catch (ex: Exception) {
        logger.warning(
          "Failed to construct runner from config $runnerConfig \ndue to exception: $ex"
        )
        throw ConfigurationException("Invalid config for building runner.", ex)
      }
    }
    // TODO(b/147985540): Move to runner, until Carbon starts each test invocation in a separate
    // process.
    diagnostics.initialize()

    return try {
      val exitCode =
        Telemetry.createEvent(runnerEventDesc) {
            displayName = "RunTests"
            onComplete { exit -> mapOf(statusDesc to Detail("$exit")) }
            run { runner.run() }
          }
          .getOrThrow()
      Telemetry.createEvent(runnerCoroutineCleanupEventDesc) {
          displayName = "CoroutineCleanup"
          run {
            runBlocking {
              rootSupervisorJob.complete()
              try {
                rootSupervisorJob.join()
              } catch (t: Throwable) {
                logger.log(Level.WARNING, "Top-level supervisor job joined with error:", t)
              }
            }
          }
        }
        .getOrThrow()
      exitCode
    } finally {
      diagnostics.finish()
    }
  }

  private fun cancelSupervisorJob() =
    runBlocking<Boolean> {
      var result = false
      val timeout = runnerConfig.cancellationConfig.executorCancellationAbortMs.milliseconds
      try {
        withTimeout(timeout) { rootSupervisorJob.join() }
      } catch (x: CancellationException) {
        result = true
        logger.warning(
          "Root supervisor job did not join within $timeout and has ${rootSupervisorJob.children.count()} children. Canceling."
        )
        val shutdown = CancellationException("UTP is shutting down!")
        for (child in rootSupervisorJob.children) {
          logger.info("Child coroutine: ${child.findName()}")
          (child as? CompletableJob)?.let {
            if (!it.isCompleted) {
              it.completeExceptionally(shutdown)
            }
          }
        }
        rootCoroutineScope.cancel(shutdown)
      }
      result
    }

  override fun cancel(aborted: Boolean): Boolean {
    try {
      return Telemetry.createEvent(runnerCancelEventDesc) {
          displayName = "CancelTests"
          run {
            var result = runner.cancel(aborted)
            if (aborted && cancelSupervisorJob()) result = true
            result
          }
        }
        .getOrThrow()
    } finally {
      diagnostics.finish()
    }
  }
}
