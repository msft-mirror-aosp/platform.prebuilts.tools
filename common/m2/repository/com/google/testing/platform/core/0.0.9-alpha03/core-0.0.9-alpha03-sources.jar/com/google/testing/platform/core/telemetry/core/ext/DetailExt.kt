/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.core.ext

import com.google.testing.platform.core.telemetry.core.Detail
import io.opencensus.trace.AttributeValue
import java.lang.IllegalStateException

/** Converts a map of [Detail]s into opencensus [AttributeValue]. */
fun Map<String, Detail<*>>.toAttributeValueMap(): Map<String, AttributeValue> = this.mapValues {
  when (it.value.value::class.java) {
    Long::class.java, java.lang.Long::class.java -> AttributeValue.longAttributeValue(
      it.value.value as Long
    )
    Int::class.java, java.lang.Integer::class.java -> AttributeValue.longAttributeValue(
      (it.value.value as Int).toLong()
    )
    Boolean::class.java, java.lang.Boolean::class.java -> AttributeValue.booleanAttributeValue(
      it.value.value as Boolean
    )
    String::class.java -> AttributeValue.stringAttributeValue(it.value.value as String)
    else -> throw IllegalStateException("Unsupported type while parsing detail.")
  }
}
