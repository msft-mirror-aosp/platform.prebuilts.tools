/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.common.annotations.VisibleForTesting
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.context.coroutineContext
import com.google.testing.platform.api.context.devicePrefix
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.api.provider.DeviceProviderConfigImpl
import com.google.testing.platform.config.v1.extension.androidSdkOrEmpty
import com.google.testing.platform.config.v1.extension.lookupDeviceById
import com.google.testing.platform.config.v1.extension.lookupTestFixtureById
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.device.DeviceProviderErrorSummary
import com.google.testing.platform.core.device.DeviceProviderException
import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.core.extension.isExtensionValid
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.extension.loadAndConfigure
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase
import javax.inject.Inject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class DeviceProviderProxy
@VisibleForTesting
constructor(
  private val deviceProviderDelegate: DeviceProvider<DeviceController>,
  private val deviceId: DeviceId,
  private val portPicker: PortPicker? = null,
) : DeviceProvider<DeviceController> by deviceProviderDelegate {

  private lateinit var parentContext: Context
  private lateinit var delegateContext: Context
  private lateinit var scope: CoroutineScope

  private companion object {
    private const val PROVIDER_NAME = "ProviderName"

    fun loadDelegate(
      runnerConfig: RunnerConfig,
      deviceId: DeviceId,
    ): DeviceProvider<DeviceController> {
      val device = runnerConfig.lookupDeviceById(deviceId)

      val deviceProvider = device.provider

      if (!deviceProvider.isExtensionValid()) {
        throw DeviceProviderException(
          "Invalid device provider configuration! Proper label or jar path was not given for " +
            "DeviceProvider.",
          DeviceProviderErrorSummary.DEVICE_PROVIDER_CONFIG_ERROR,
        )
      }

      // TODO(b/129083096): Differentiate between "not found" and "cannot load" in exception message
      return loadAndConfigure<DeviceProvider<DeviceController>>(
        deviceProvider.label.label,
        deviceProvider.className,
        listOf(
          extensionSourceFrom(
            deviceProvider.label.label,
            deviceProvider.jarList.map { it.path },
            deviceProvider.useSingleClassLoader,
          )
        ),
      )
        ?: throw DeviceProviderException(
          "Cannot load device provider: ${deviceProvider.className}!",
          UtpCoreErrorSummary.EXTENSION_CLASS_LOADING_FAILURE,
        )
    }

    /** Build the [Detail] map to attach to [EventRecord] */
    private fun buildAttributes(provider: DeviceProvider<DeviceController>) =
      mutableMapOf(PROVIDER_NAME to Detail(provider::class.java.name))
  }

  private var serial: String = ""

  @Inject
  constructor(
    runnerConfig: RunnerConfig,
    deviceId: DeviceId,
    portPicker: PortPicker?,
  ) : this(loadDelegate(runnerConfig, deviceId), deviceId, portPicker)

  override fun configure(context: Context) {
    parentContext = context
    scope =
      CoroutineScope(
        parentContext.coroutineContext +
          SupervisorJob(parentContext.coroutineContext[Job]) +
          CoroutineName(context.devicePrefix + "device_provider_proxy")
      )
    val config = context.config as ProxyConfig
    val runnerConfig = config.runnerConfig
    val providerProto = runnerConfig.lookupDeviceById(deviceId).provider
    val fixtureProto = runnerConfig.lookupTestFixtureById(config.testFixtureId)
    val providerConfiguration =
      DeviceProviderConfigImpl(
        environmentProto = fixtureProto.environment,
        androidSdkProto = fixtureProto.androidSdkOrEmpty,
        testSetupProto = fixtureProto.setup,
        configProto = if (providerProto.hasConfig()) providerProto.config else null,
        configResource = if (providerProto.hasResource()) providerProto.resource else null,
        portPicker = portPicker,
        coroutineScope = scope,
        deviceId = deviceId,
      )
    // The ExtensionContextImpl will delegate to the parentContext, so other keys like
    // Context.EVENTS_KEY will be inherited.
    delegateContext =
      ExtensionContextImpl(
        parentContext = context,
        contextMap = mutableMapOf(Context.CONFIG_KEY to providerConfiguration),
      )
    try {
      deviceProviderDelegate.configure(delegateContext)
    } catch (dpx: DeviceProviderException) {
      scope.cancel(dpx.message ?: dpx::class.simpleName!!, dpx)
      throw dpx
    } catch (exception: Exception) {
      scope.cancel(exception.message ?: exception::class.simpleName!!, exception)
      throw DeviceProviderException(
        "Configuring device provider <${deviceProviderDelegate::class.java.name}> failed!",
        DeviceProviderErrorSummary.DEVICE_PROVIDER_CONFIG_ERROR,
        exception,
      )
    }
  }

  override fun provideDevice(): DeviceController {
    return try {
      Telemetry.createEvent("ProvideDevice") {
          displayName = "GetDeviceReady"
          phase = TestPhase.SETUP
          addAllAttributes(buildAttributes(deviceProviderDelegate))
          run {
            DeviceControllerProxy(deviceProviderDelegate.provideDevice(), scope).also {
              serial = it.getDevice().serial
            }
          }
        }
        .getOrThrow()
    } catch (dpx: DeviceProviderException) {
      scope.cancel(dpx.message ?: dpx::class.simpleName!!, dpx)
      throw dpx
    } catch (utpEx: UtpException) {
      // Propagate the underlying exception message so that it is visible at the top for consumers.
      scope.cancel(utpEx.message ?: utpEx::class.simpleName!!, utpEx)
      throw DeviceProviderException(
        message = utpEx.message ?: "Exception thrown in Device Provider while providing device.",
        errorSummary = DeviceProviderErrorSummary.DEVICE_PROVISION_FAILED,
        throwable = utpEx,
      )
    } catch (exception: Exception) {
      scope.cancel(exception.message ?: exception::class.simpleName!!, exception)
      throw DeviceProviderException(
        "Device provider <${deviceProviderDelegate::class.java.name}> failed trying to provide " +
          "device controller.",
        DeviceProviderErrorSummary.DEVICE_PROVISION_FAILED,
        exception,
      )
    }
  }

  override fun releaseDevice() {
    return try {
      Telemetry.createEvent("UTP.DeviceProviderProxy.ReleaseDevice") {
          displayName = "ReleaseDevice"
          phase = TestPhase.TEARDOWN
          addAllAttributes(buildAttributes(deviceProviderDelegate))
          run { deviceProviderDelegate.releaseDevice() }
        }
        .getOrThrow()
    } catch (dpx: DeviceProviderException) {
      throw dpx
    } catch (utpEx: UtpException) {
      // Propagate the underlying exception message so that it is visible at the top for consumers.
      throw DeviceProviderException(
        message = utpEx.message ?: "Exception thrown in Device Provider while releasing device.",
        errorSummary = DeviceProviderErrorSummary.DEVICE_PROVISION_FAILED,
        throwable = utpEx,
      )
    } catch (exception: Exception) {
      throw DeviceProviderException(
        "Releasing device with serial <$serial> failed!",
        DeviceProviderErrorSummary.DEVICE_RELEASE_FAILED,
        exception,
      )
    } finally {
      // This is necessary to terminate ongoing jobs that are doing things like processing log
      // files, where there's no clear way to detect that it's done.
      scope.cancel(CancellationException("DeviceProviderProxy releaseDevice"))
    }
  }

  override fun cancel(aborted: Boolean): Boolean {
    try {
      return deviceProviderDelegate.cancel(aborted)
    } catch (dpx: DeviceProviderException) {
      throw dpx
    } catch (exception: Exception) {
      throw DeviceProviderException(
        "Error cancelling DeviceProvider.",
        DeviceProviderErrorSummary.UNDETERMINED,
        exception,
      )
    } finally {
      scope.cancel(CancellationException("DeviceProviderProxy cancelled"))
    }
  }
}
