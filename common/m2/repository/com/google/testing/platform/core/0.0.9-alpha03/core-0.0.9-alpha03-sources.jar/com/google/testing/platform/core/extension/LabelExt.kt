/*
 * Copyright (C) 2019 The Android Open Source Project
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.extension

import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.LabelProto.Label

private val logger by lazy { getLogger<Label>() }

/**
 * Verifies if message specifies label.
 *
 * @return true if label is non-empty, false otherwise.
 */
fun Label.isLabelValid(): Boolean = when {
  label.isNullOrEmpty() -> {
    logger.fine("Label field cannot be empty.")
    false
  }
  else -> true
}
