/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server

import com.google.testing.platform.proto.api.service.ServerConfigProto.ServerConfig
import io.grpc.BindableService
import io.grpc.ServerBuilder
import io.grpc.netty.NettyServerBuilder
import java.io.File
import java.lang.IllegalArgumentException
import java.net.URI

/**
 * Creates and configures [ServerBuilder]
 */
object ServerBuilderFactory {
  /**
   * Supported [ServerBuilder] types
   */
  private enum class ServerType {
    TCP,
  }

  /**
   * Creates [ServerBuilder] based on resolving address in [ServerConfig] and adds all services.
   * Currently only supports creating TCP socket servers (no UNIX or in-process support).
   *
   * @return [ServerBuilder]
   */
  fun create(config: ServerConfig, services: Set<BindableService>): ServerBuilder<*> {
    require(config.address.isNotBlank()) {
      "Invalid address provided for server: ${config.address}"
    }

    return when (resolve(config.address)) {
      ServerType.TCP -> TcpServerBuilderFactory.create(config)
    }.apply {
      services.forEach {
        addService(it)
      }
    }
  }

  /**
   * Determines [ServerType] of [ServerBuilder] to use create
   */
  private fun resolve(target: String): ServerType =
    when {
      TcpServerBuilderFactory.isValid(target) -> ServerType.TCP
      else -> throw IllegalArgumentException("Provided target address is not valid: $target")
    }

  /**
   * Factory for creating [Server] listening on TCP socket using Netty.
   */
  private object TcpServerBuilderFactory {
    fun isValid(target: String): Boolean {
      val uri = parseUri(target)
      return uri.host != null && uri.port > 0
    }

    fun parseUri(rawUri: String) = URI("//$rawUri")

    fun create(config: ServerConfig): ServerBuilder<*> {
      val port = parseUri(config.address).port

      return NettyServerBuilder.forPort(port).apply {
        config.securityConfig.let {
          if (it.hasCertChain() && it.hasPrivateKey())
            useTransportSecurity(
              File(config.securityConfig.certChain.path),
              File(config.securityConfig.privateKey.path)
            )
        }
      }
    }
  }
}
