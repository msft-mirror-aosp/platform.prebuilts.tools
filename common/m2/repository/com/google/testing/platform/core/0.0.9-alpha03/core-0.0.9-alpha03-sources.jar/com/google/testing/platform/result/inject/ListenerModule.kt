/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.result.inject

import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.core.result.TestSuiteCreator
import com.google.testing.platform.core.result.TestSuiteCreatorFactory
import com.google.testing.platform.result.GlobalTestResultPublisher
import com.google.testing.platform.result.TestResultListenerLoader
import com.google.testing.platform.result.TestResultListenerManager
import com.google.testing.platform.result.TestSuiteCreatorImpl
import dagger.Module
import dagger.Provides
import dagger.multibindings.ElementsIntoSet
import kotlinx.coroutines.CoroutineScope

/** Dagger module to provide various external listener to send test results to. */
@Module(includes = [ProtoLogModule::class])
class ListenerModule {
  @Provides
  @ElementsIntoSet
  fun externalListeners(
    testResultListenerLoader: TestResultListenerLoader,
    rootCoroutineScope: CoroutineScope,
  ): Set<@JvmSuppressWildcards TestResultListener> =
    testResultListenerLoader.loadAndConfigureListeners(rootCoroutineScope).toSet()

  @Provides
  fun testSuiteCreator(testSuiteCreator: TestSuiteCreatorImpl): TestSuiteCreator = testSuiteCreator

  @Provides
  fun testSuiteCreatorFactory(): TestSuiteCreatorFactory =
    object : TestSuiteCreatorFactory {
      override fun create() = TestSuiteCreatorImpl()
    }

  @Provides
  fun testResultPublisher(
    testResultListenerManager: TestResultListenerManager,
    testSuiteCreatorFactory: TestSuiteCreatorFactory,
  ): TestResultPublisher =
    GlobalTestResultPublisher(testResultListenerManager, testSuiteCreatorFactory)
}
