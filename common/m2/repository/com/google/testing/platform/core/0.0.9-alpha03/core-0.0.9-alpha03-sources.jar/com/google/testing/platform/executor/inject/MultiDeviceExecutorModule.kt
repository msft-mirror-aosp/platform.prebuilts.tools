/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor.inject

import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.event.inject.AuxiliaryEvents
import com.google.testing.platform.core.event.inject.EventsModule
import com.google.testing.platform.core.event.inject.PrimaryEvents
import com.google.testing.platform.executor.Execution
import com.google.testing.platform.executor.MultiDeviceExecutor
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.plugin.PluginLifecycle
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.ExecutionProto.DeviceExecution
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import dagger.Lazy
import dagger.Module
import dagger.Provides
import javax.inject.Provider
import kotlinx.coroutines.CoroutineScope

/** Provides the MultiDeviceExecutor. */
@Module(includes = [ExecutorRequisitesModule::class, EventsModule::class])
class MultiDeviceExecutorModule {
  @Provides
  fun executions(
    runnerConfig: RunnerConfig,
    deviceProviders: Map<DeviceId, @JvmSuppressWildcards Lazy<DeviceProvider<DeviceController>>>,
    testDrivers: Map<TestFixtureId, @JvmSuppressWildcards Lazy<TestDriver>>,
    pluginLifecycles: Map<TestFixtureId, PluginLifecycle>,
    @PrimaryEvents events: Events,
    @AuxiliaryEvents auxiliaryEvents: Provider<Events>,
  ): List<Execution> =
    listOf(
      runnerConfig.multiDeviceExecutor.primaryDeviceExecution.toExecution(
        deviceProviders,
        testDrivers,
        pluginLifecycles,
        events,
      )
    ) +
      runnerConfig.multiDeviceExecutor.companionDeviceExecutionList.map {
        it.toExecution(deviceProviders, testDrivers, pluginLifecycles, auxiliaryEvents.get())
      }

  @Provides
  fun multiDeviceExecutor(
    executions: List<Execution>,
    rootCoroutineScope: CoroutineScope,
    cancellationContext: ProcessCancellationContext,
    errorUpdater: ErrorUpdater,
    portPicker: PortPicker?,
  ): MultiDeviceExecutor =
    MultiDeviceExecutor(
      executions,
      rootCoroutineScope,
      cancellationContext,
      errorUpdater,
      portPicker,
    )
}

private fun DeviceExecution.toExecution(
  deviceProviders: Map<DeviceId, @JvmSuppressWildcards Lazy<DeviceProvider<DeviceController>>>,
  testDrivers: Map<TestFixtureId, @JvmSuppressWildcards Lazy<TestDriver>>,
  pluginLifecycles: Map<TestFixtureId, PluginLifecycle>,
  events: Events,
) =
  Execution(
    deviceId,
    testFixtureId,
    deviceProviders[deviceId] ?: throw IllegalStateException("Device ${deviceId} not found"),
    testDrivers[testFixtureId]
      ?: throw IllegalStateException("Test fixture ${testFixtureId} not found"),
    pluginLifecycles[testFixtureId]
      ?: throw IllegalStateException("Plugins for ${testFixtureId} not found"),
    events,
  )
