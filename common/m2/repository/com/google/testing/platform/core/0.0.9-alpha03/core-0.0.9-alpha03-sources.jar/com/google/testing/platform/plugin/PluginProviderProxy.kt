/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.core.extension.isExtensionValid
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.lib.extension.ExtensionLoader
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixture

/**
 * Takes all the available plugins registered in the Dagger object graph and filters them to return
 * only the ones that are configured in the proto.
 */
class PluginProviderProxy(private val config: TestFixture) : PluginProvider {
  companion object {
    @JvmStatic private val logger = getLogger()
  }

  /**
   * Lazily loads [HostPlugin]s from [com.google.testing.platform.proto.api.config.HostPluginProto]
   * definitions.
   *
   * The plugin proto config processing involves multiple steps:
   * <ol>
   * <li>Extract host plugin list from
   *   [com.google.testing.platform.proto.api.config.FixtureProto.TestFixture] proto.
   * <li>Validate and de-duping host plugin list.
   * <li>Create a [ExtensionLoader] per host plugin and dynamically load plugins from an isolated
   *   classloader.
   * </ol>
   *
   * @return set of dynamically loaded [HostPlugin]s
   */
  override val plugins: Set<HostPlugin> by lazy {
    config.hostPluginList
      .asSequence()
      .filter { hostPlugin ->
        if (!hostPlugin.isExtensionValid()) {
          logger.warning("Plugin cannot be loaded: $hostPlugin")
          false
        } else true
      }
      .distinctBy { hostPlugin -> hostPlugin.className }
      .mapNotNull { hostPlugin ->
        val pluginLoader =
          ExtensionLoader<HostPlugin>(
            extensionSources =
              arrayListOf(
                extensionSourceFrom(
                  hostPlugin.className,
                  hostPlugin.jarList.map { it.path },
                  hostPlugin.useSingleClassLoader,
                )
              )
          )
        @Suppress("UNCHECKED_CAST")
        val loadedPlugins =
          pluginLoader.load(
            Class.forName(HostPlugin::class.java.canonicalName!!) as Class<HostPlugin>
          )
        if (loadedPlugins.isEmpty()) {
          throw IllegalStateException("Plugin: ${hostPlugin.className} could not be loaded!")
        } else if (loadedPlugins.size > 1) {
          logger.fine(
            """More than 1 implementation found for host plugin:
              |$hostPlugin
              |Implementations found:
              |{${loadedPlugins.forEach { it.toString() }}}"""
              .trimMargin()
          )
        }
        loadedPlugins.first()
      }
      .toSet()
  }
}
