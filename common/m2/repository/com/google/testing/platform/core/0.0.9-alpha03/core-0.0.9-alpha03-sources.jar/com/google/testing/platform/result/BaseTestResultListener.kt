/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.proto.api.core.TestCaseProto
import com.google.testing.platform.proto.api.core.TestResultProto
import com.google.testing.platform.proto.api.core.TestSuiteResultProto
import java.lang.IllegalStateException

/**
 * A default no-op [TestResultListener] implementation which can be used as a delegate plugin.
 *
 * All the methods have no-op implementations except the [afterTestSuite] method as it is mandatory
 * to report an output in this extension interface.
 */
@ThreadSafe
class BaseTestResultListener : TestResultListener {

  /** No-op implementation. */
  override fun configure(context: Context) = Unit

  /** No-op implementation. */
  override fun beforeTestSuite(testSuiteMetaData: TestSuiteResultProto.TestSuiteMetaData?) = Unit

  /** No-op implementation. */
  override fun beforeTest(testCase: TestCaseProto.TestCase?) = Unit

  /** No-op implementation. */
  override fun afterTest(testResult: TestResultProto.TestResult) = Unit

  /** Will throw an exception if this method is accessed directly. */
  override fun afterTestSuite(testSuiteResult: TestSuiteResultProto.TestSuiteResult) =
    throw IllegalStateException(
      """
      Every TestResultListener must have an explicit afterTestSuite implementation
      to report outputs.
      """
    )

  /** No-op implementation. Remember to implement this if you support multi-device testing! */
  override fun afterAllTestSuites() = Unit
}
