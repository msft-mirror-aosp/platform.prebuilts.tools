/*
 * Copyright (C) 2022 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.extension

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.ErrorType

/** Summaries of errors that can occur during extension loading. */
enum class ExtensionLoaderErrorSummary(
  override val errorCode: Int,
  override val errorType: Enum<*>
) : ErrorSummary {
  EXTENSION_LOAD_FAILED(1001, ErrorType.CONFIG);

  override val errorName = this.name
  override val namespace =
    "com.google.testing.platform.lib.extension.ExtensionLoader"
}
