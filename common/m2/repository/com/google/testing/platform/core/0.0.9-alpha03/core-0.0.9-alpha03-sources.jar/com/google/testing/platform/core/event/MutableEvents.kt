package com.google.testing.platform.core.event

import com.google.protobuf.Message
import com.google.protobuf.Parser
import com.google.testing.platform.api.event.Events

interface MutableEvents : Events {

  /** Retrieves and removes all serialized Events of a specific type */
  fun consume(event: String): List<ByteArray>
}

/** Retrieves and removes messages from the event graph. */
inline fun <reified T : Message> MutableEvents.consume(): List<T> {
  val messages = consume(T::class.java.name)
  @Suppress("UNCHECKED_CAST")
  val parser = T::class.java.getMethod("parser").invoke(null) as Parser<T>
  return messages.map { parser.parseFrom(it) as T }
}

/** Retrieves and removes enum values from the event graph */
inline fun <reified T : Enum<T>> MutableEvents.consumeEnum(): List<T> =
  consume(T::class.java.name).map {
    T::class
      .java
      .getMethod("valueOf", String::class.java)
      .invoke(null, String(it, Charsets.UTF_8)) as T
  }
