/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.telemetry.opencensus.exporter

import com.google.testing.platform.core.telemetry.exporter.DiagnosticExporter
import com.google.testing.platform.core.telemetry.opencensus.TraceProtoUtils
import io.opencensus.proto.trace.v1.Span
import io.opencensus.trace.export.SpanData
import io.opencensus.trace.export.SpanExporter

/** A [SpanExporter.Handler] that exports [Span]s to a [DiagnosticExporter]. */
class OpencensusSpanExporter(private val diagnosticExporter: DiagnosticExporter) :
  SpanExporter.Handler() {

  /** Converts [SpanData] to [Span] and exports it to a [DiagnosticExporter]. */
  override fun export(spanDataList: Collection<SpanData>) {
    diagnosticExporter.export(spanDataList.map { span -> TraceProtoUtils.toSpanProto(span) })
  }
}
