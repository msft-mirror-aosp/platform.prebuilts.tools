/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.core.error.ext

import com.google.testing.platform.api.error.ErrorSummary
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.proto.api.core.ErrorDetailProto

/** Creates an [ErrorDetailProto] with the given [Throwable]. */
fun Throwable.toErrorDetail(errorSummary: ErrorSummary?): ErrorDetailProto.ErrorDetail =
  ErrorDetailProto.ErrorDetail.newBuilder()
    .apply {
      summaryBuilder.apply {
        errorSummary?.let {
          namespaceBuilder.namespace = it.namespace
          errorCode = it.errorCode
          errorName = it.errorName
          errorClassification = it.errorType.toString()
        }
        this@toErrorDetail.message?.let { errorMessage = it.substringAfter("Message: ") }
        stackTrace = this@toErrorDetail.stackTraceToString()
      }

      this@toErrorDetail.cause?.let {
        setCause(it.toErrorDetail(if (it is UtpException) it.errorSummary else null))
      }
      this@toErrorDetail.suppressed.forEach {
        addSuppressed(it.toErrorDetail(if (it is UtpException) it.errorSummary else null))
      }
    }
    .build()

/**
 * Extracts the signature from the stack trace of the given [Throwable].
 *
 * The signature of a [Throwable] consists of the [Throwable]'s runtime class name, its message, the
 * first trace line, and its cause's signature recursively (if any). For example, for a
 * [RuntimeException] with a [RuntimeException] cause, its signature may look something like:
 * ```
 * java.lang.RuntimeException: Message Foo
 * at com.google.ClassFoo.methodFoo(ClassFoo.kt:)
 * Caused by: java.lang.RuntimeException: Message Cause Foo
 * at com.google.ClassCauseFoo.methodCauseFoo(ClassCauseFoo.kt:)
 * ```
 */
val Throwable.signature: String
  get() {
    val runtimeClassName = this::class.qualifiedName
    val messageString =
      if (!message.isNullOrBlank()) {
        ": ${sanitizeMessage(message!!)}"
      } else {
        ""
      }
    val firstTraceLine = "at $firstTraceFrameString"
    val causeSignature =
      if (cause != null) {
        "\nCaused by: " + cause!!.signature
      } else {
        ""
      }
    val signature = "$runtimeClassName$messageString\n$firstTraceLine$causeSignature"
    return signature
  }

/**
 * Sanitize a message string before passing it along.
 *
 * For now, the only modification done is to replace UUIDs with all xs.
 */
private fun sanitizeMessage(message: String): String =
  message.replace(
    "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}".toRegex(),
    "xxxxxxxx-xxxx-xxxx-xxxxxxxxxxxx"
  )

/**
 * Returns the string representation of the first stack trace frame in the [Throwable], in the
 * format of `className.methodName(fileName)`.
 */
private val Throwable.firstTraceFrameString: String
  get() =
    if (stackTrace.size == 0) {
      ""
    } else {
      val firstTraceFrame = stackTrace[0]
      "${firstTraceFrame.className}.${firstTraceFrame.methodName}(${firstTraceFrame.fileName})"
    }
