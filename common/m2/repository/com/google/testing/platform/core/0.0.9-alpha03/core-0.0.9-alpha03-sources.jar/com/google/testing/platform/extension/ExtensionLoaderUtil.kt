/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.extension

import com.google.testing.platform.lib.extension.ExtensionLoader as ExtensionLoaderLib
import com.google.testing.platform.lib.extension.ExtensionSource
import java.net.URLClassLoader
import java.nio.file.Paths
import java.util.Collections
import java.util.logging.Logger

val default_logger: Logger =
  Logger.getLogger("com.google.testing.platform.extension.ExtensionLoaderUtil")

/**
 * Configures and loads extensions using a [ExtensionLoader].
 *
 * @param label label of the class to load.
 * @param className the class name of the extension to load.
 * @param extensionSources list of [ExtensionSource]s.
 * @param logger optional logger for logging.
 * @return a list of loaded extensions
 */
inline fun <reified P : Any> loadAndConfigure(
  label: String,
  className: String,
  extensionSources: List<ExtensionSource>,
  logger: Logger = default_logger,
): P? {
  val extensionLoader = ExtensionLoaderLib<P>(extensionSources)
  val loadedExtensions = extensionLoader.load(P::class.java)
  return loadedExtensions.firstOrNull { extension -> extension::class.java.name == className }
    ?: run {
      logger.warning(
        """$className in extension with label '$label' not found.
        |${loadedExtensions.size} implementations found.
        |Implementations found:
        |${loadedExtensions.joinToString(", ")}
      """
          .trimMargin()
      )
      null
    }
}

private object ExtensionLoaderUtil {
  val extensionClassLoaders = Collections.synchronizedMap(mutableMapOf<List<String>, ClassLoader>())
}

/**
 * Creates a [ExtensionSource] from a extension class and a list of jar files.
 *
 * All unique vectors of jars share a class loader, and longer vectors have shorter vectors as
 * parents. e.g.: A,B,C and A,B,D are distinct class loaders that share a parent class loader of
 * A,B. A,B,C and A,C,D only share the class loader for A. A,B,C and C,A,B are entirely separate.
 *
 * Jars are specified by their full path. Different versions of the same jar can coexist within the
 * same process, since they will only be visible to their own class loader and child class loaders
 * that explicitly reference them.
 *
 * @param label the extension's label.
 * @param extensionJarList a list of jars that contain extension code.
 * @param useSingleClassLoader load all jars in a single class loader; ignore the cache.
 * @return a [ExtensionSource] source instance.
 */
fun extensionSourceFrom(
  label: String,
  extensionJarList: List<String>,
  useSingleClassLoader: Boolean,
): ExtensionSource {
  require(extensionJarList.size > 0)

  // The docs on ClassLoader say "some implementations may use {@code null}", so rather than worry
  // about implementations, let's be explicit about where we're getting things. Take the current
  // class loader if it happens to be the system class loader, or its parent if it isn't.
  var loader = ExtensionLoaderUtil::class.java.classLoader
  if (loader != ClassLoader.getSystemClassLoader()) loader = loader?.parent

  val rootClassLoader = loader ?: ClassLoader.getSystemClassLoader()

  if (useSingleClassLoader) {
    val classLoader =
      URLClassLoader(
        extensionJarList.map { Paths.get(it).toUri().toURL() }.toTypedArray(),
        rootClassLoader,
      )
    return ExtensionSource(label, classLoader)
  }

  // A Java thread can acquire a lock that it already owns, so this is safe.
  val classLoader =
    synchronized(ExtensionLoaderUtil.extensionClassLoaders) {
      ExtensionLoaderUtil.extensionClassLoaders.getOrPut(extensionJarList) {
        val ancestry = extensionJarList.dropLast(1)
        val parent =
          if (ancestry.isNotEmpty()) {
            // The parent class loader is cached under the complete list of jars that comes before
            // the final one.
            extensionSourceFrom(label, ancestry, false).classLoader
          } else {
            rootClassLoader
          }
        val child = Paths.get(extensionJarList.last()).toUri().toURL()
        default_logger.finest(
          "Creating class loader for $child with parents ${ancestry.joinToString(" -> ")}"
        )
        URLClassLoader(listOf(child).toTypedArray(), parent)
      }
    }

  return ExtensionSource(label, classLoader)
}

/** For testing purposes: clears all loaded extensions. */
fun clearLoadedExtensions() {
  ExtensionLoaderUtil.extensionClassLoaders.clear()
}
