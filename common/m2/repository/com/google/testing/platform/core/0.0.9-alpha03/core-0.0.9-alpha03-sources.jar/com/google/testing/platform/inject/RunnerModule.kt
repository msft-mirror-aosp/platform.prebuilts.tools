/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.inject

import com.google.testing.platform.Runner
import com.google.testing.platform.RunnerImpl
import com.google.testing.platform.config.Environment
import com.google.testing.platform.executor.inject.ExecutorModule
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import dagger.Module
import dagger.Provides

/**
 * Dagger module to add configuration and runtime classes to the final object graph
 * to be used as the entry-point into Unified Test Platform runner.
 */
@Module(includes = [ExecutorModule::class])
class RunnerModule {
  @Provides
  fun providesEnvironment(runnerConfig: RunnerConfig): Environment {
    return Environment.Creator.parseFrom(runnerConfig)
  }

  @Provides
  fun providesRunner(runner: RunnerImpl): Runner = runner
}
