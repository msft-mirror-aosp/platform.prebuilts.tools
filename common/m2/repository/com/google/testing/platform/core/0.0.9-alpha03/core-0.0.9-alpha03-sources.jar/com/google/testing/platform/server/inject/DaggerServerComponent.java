package com.google.testing.platform.server.inject;

import com.google.common.collect.ImmutableSet;
import com.google.testing.platform.api.event.Events;
import com.google.testing.platform.core.telemetry.core.Diagnostics;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule_AndroidSdkFactory;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule_DiagnosticsConfigFactory;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule_DiagnosticsFactory;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule_EnvironmentFactory;
import com.google.testing.platform.core.telemetry.inject.DiagnosticsModule_TestSetupFactory;
import com.google.testing.platform.core.telemetry.opencensus.OpencensusDiagnostics;
import com.google.testing.platform.core.telemetry.proto.DiagnosticsProto;
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext;
import com.google.testing.platform.proto.api.config.AndroidSdkProto;
import com.google.testing.platform.proto.api.config.EnvironmentProto;
import com.google.testing.platform.proto.api.config.RunnerConfigProto;
import com.google.testing.platform.proto.api.config.SetupProto;
import com.google.testing.platform.proto.api.service.ServerConfigProto;
import com.google.testing.platform.server.ServerStrategy;
import com.google.testing.platform.service.RunnerManager;
import com.google.testing.platform.service.RunnerServiceImpl;
import com.google.testing.platform.service.inject.RunnerServiceModule;
import com.google.testing.platform.service.inject.RunnerServiceModule_ProvideRunnerComponentBuilderFactory;
import com.google.testing.platform.service.inject.RunnerServiceModule_ProvideRunnerManagerFactory;
import dagger.internal.DaggerGenerated;
import dagger.internal.Preconditions;
import io.grpc.BindableService;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import java.util.Set;
import javax.annotation.Generated;
import javax.inject.Provider;
import kotlinx.coroutines.CoroutineScope;

@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class DaggerServerComponent {
  private DaggerServerComponent() {
  }

  public static ServerComponent.Builder builder() {
    return new Builder();
  }

  private static final class Builder implements ServerComponent.Builder {
    private ServerConfigProto.ServerConfig serverConfig;

    private RunnerConfigProto.RunnerConfig runnerConfig;

    private ProcessCancellationContext cancellationContext;

    private Events events;

    private CoroutineScope rootCoroutineScope;

    @Override
    public Builder serverConfig(ServerConfigProto.ServerConfig config) {
      this.serverConfig = config;
      return this;
    }

    @Override
    public Builder runnerConfig(RunnerConfigProto.RunnerConfig config) {
      this.runnerConfig = config;
      return this;
    }

    @Override
    public Builder cancellationContext(ProcessCancellationContext cancellationContext) {
      this.cancellationContext = Preconditions.checkNotNull(cancellationContext);
      return this;
    }

    @Override
    public Builder events(Events events) {
      this.events = Preconditions.checkNotNull(events);
      return this;
    }

    @Override
    public Builder rootCoroutineScope(CoroutineScope rootCoroutineScope) {
      this.rootCoroutineScope = Preconditions.checkNotNull(rootCoroutineScope);
      return this;
    }

    @Override
    public ServerComponent build() {
      Preconditions.checkBuilderRequirement(cancellationContext, ProcessCancellationContext.class);
      Preconditions.checkBuilderRequirement(events, Events.class);
      Preconditions.checkBuilderRequirement(rootCoroutineScope, CoroutineScope.class);
      return new ServerComponentImpl(new ServerStrategyModule(), new ServerModule(), new CoreServicesModule(), new RunnerServiceModule(), new DiagnosticsModule(), serverConfig, runnerConfig, cancellationContext, events, rootCoroutineScope);
    }
  }

  private static final class ServerComponentImpl implements ServerComponent {
    private final ServerConfigProto.ServerConfig serverConfig;

    private final CoreServicesModule coreServicesModule;

    private final RunnerServiceModule runnerServiceModule;

    private final CoroutineScope rootCoroutineScope;

    private final Events events;

    private final ServerModule serverModule;

    private final ServerStrategyModule serverStrategyModule;

    private final RunnerConfigProto.RunnerConfig runnerConfig;

    private final DiagnosticsModule diagnosticsModule;

    private final ProcessCancellationContext cancellationContext;

    private final ServerComponentImpl serverComponentImpl = this;

    private Provider<com.google.testing.platform.inject.RunnerComponent.Builder> provideRunnerComponentBuilderProvider;

    private ServerComponentImpl(ServerStrategyModule serverStrategyModuleParam,
        ServerModule serverModuleParam, CoreServicesModule coreServicesModuleParam,
        RunnerServiceModule runnerServiceModuleParam, DiagnosticsModule diagnosticsModuleParam,
        ServerConfigProto.ServerConfig serverConfigParam,
        RunnerConfigProto.RunnerConfig runnerConfigParam,
        ProcessCancellationContext cancellationContextParam, Events eventsParam,
        CoroutineScope rootCoroutineScopeParam) {
      this.serverConfig = serverConfigParam;
      this.coreServicesModule = coreServicesModuleParam;
      this.runnerServiceModule = runnerServiceModuleParam;
      this.rootCoroutineScope = rootCoroutineScopeParam;
      this.events = eventsParam;
      this.serverModule = serverModuleParam;
      this.serverStrategyModule = serverStrategyModuleParam;
      this.runnerConfig = runnerConfigParam;
      this.diagnosticsModule = diagnosticsModuleParam;
      this.cancellationContext = cancellationContextParam;
      initialize(serverStrategyModuleParam, serverModuleParam, coreServicesModuleParam, runnerServiceModuleParam, diagnosticsModuleParam, serverConfigParam, runnerConfigParam, cancellationContextParam, eventsParam, rootCoroutineScopeParam);

    }

    private RunnerManager runnerManager() {
      return RunnerServiceModule_ProvideRunnerManagerFactory.provideRunnerManager(runnerServiceModule, rootCoroutineScope);
    }

    private RunnerServiceImpl runnerServiceImpl() {
      return new RunnerServiceImpl(runnerManager(), provideRunnerComponentBuilderProvider, events);
    }

    private BindableService providesRunnerService() {
      return CoreServicesModule_ProvidesRunnerServiceFactory.providesRunnerService(coreServicesModule, runnerServiceImpl());
    }

    private Set<BindableService> setOfBindableService() {
      return ImmutableSet.<BindableService>of(CoreServicesModule_ProvidesReflectionServiceFactory.providesReflectionService(coreServicesModule), providesRunnerService());
    }

    private ServerBuilder<?> serverBuilderOf() {
      return serverModule.provideServerBuilder(serverConfig, setOfBindableService());
    }

    private DiagnosticsProto.Diagnostics diagnostics2() {
      return DiagnosticsModule_DiagnosticsConfigFactory.diagnosticsConfig(diagnosticsModule, runnerConfig);
    }

    private EnvironmentProto.Environment environment() {
      return DiagnosticsModule_EnvironmentFactory.environment(diagnosticsModule, runnerConfig);
    }

    private SetupProto.TestSetup testSetup() {
      return DiagnosticsModule_TestSetupFactory.testSetup(diagnosticsModule, runnerConfig);
    }

    private AndroidSdkProto.AndroidSdk androidSdk() {
      return DiagnosticsModule_AndroidSdkFactory.androidSdk(diagnosticsModule, runnerConfig);
    }

    private OpencensusDiagnostics opencensusDiagnostics() {
      return new OpencensusDiagnostics(diagnostics2(), environment(), testSetup(), androidSdk(), events);
    }

    private Diagnostics diagnostics() {
      return DiagnosticsModule_DiagnosticsFactory.diagnostics(diagnosticsModule, opencensusDiagnostics(), diagnostics2());
    }

    @SuppressWarnings("unchecked")
    private void initialize(final ServerStrategyModule serverStrategyModuleParam,
        final ServerModule serverModuleParam, final CoreServicesModule coreServicesModuleParam,
        final RunnerServiceModule runnerServiceModuleParam,
        final DiagnosticsModule diagnosticsModuleParam,
        final ServerConfigProto.ServerConfig serverConfigParam,
        final RunnerConfigProto.RunnerConfig runnerConfigParam,
        final ProcessCancellationContext cancellationContextParam, final Events eventsParam,
        final CoroutineScope rootCoroutineScopeParam) {
      this.provideRunnerComponentBuilderProvider = RunnerServiceModule_ProvideRunnerComponentBuilderFactory.create(runnerServiceModuleParam);
    }

    @Override
    public Server getServer() {
      return serverModule.provideServer(serverBuilderOf());
    }

    @Override
    public ServerStrategy getStrategy() {
      return ServerStrategyModule_ProvidesServerStrategyFactory.providesServerStrategy(serverStrategyModule, runnerConfig, getServer(), diagnostics(), rootCoroutineScope, cancellationContext, events);
    }
  }
}
