/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin.annotations

import kotlin.reflect.KClass

/**
 * An annotation used to build up a dependency graph, announcing that a plugin consumes a particular
 * protobuf message.
 *
 * @param message The class of the consumed protobuf message. Plugin methods must have a unique
 *   signature of OrderExpects and OrderProvides annotations to have a stable position in the graph;
 *   if there is any ambiguity, the order will be randomized to guard against accidental dependency
 *   on other factors.
 * @param required If true, it is an error to build the graph without a provider for the consumed
 *   message.
 */
@Repeatable
@Target(AnnotationTarget.FUNCTION)
@Retention(AnnotationRetention.RUNTIME)
annotation class OrderExpects(val message: KClass<*>, val required: Boolean = false)
