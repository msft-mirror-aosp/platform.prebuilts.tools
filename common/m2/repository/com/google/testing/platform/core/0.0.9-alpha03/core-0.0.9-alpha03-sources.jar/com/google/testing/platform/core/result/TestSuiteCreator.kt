/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.core.result

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.proto.api.core.ErrorDetailProto.ErrorDetail
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult

/**
 * Accumulates a [TestSuiteResult] from multiple [TestResult] protos and other relevant events and
 * returns it when buildTestSuiteResult is called.
 */
interface TestSuiteCreator {
  /**
   * Add [TestSuiteMetaData] to the [TestSuiteResult]. If called multiple times, the protobufs will
   * be merged, so fields like TestSuiteMetaData.scheduledTestCaseCount can be updated.
   *
   * @param testSuiteMetaData: the metadata.
   */
  fun addTestSuiteMetadata(testSuiteMetaData: TestSuiteMetaData)

  /**
   * Adds the [TestResult] to the [TestSuiteResult].
   *
   * @param testResult The result to add (or update).
   * @return true if the testResult is new; false if it was an update.
   */
  @CanIgnoreReturnValue fun addTestResult(testResult: TestResult): Boolean

  /**
   * Adds the [Artifact] to the [TestSuiteResult].
   *
   * @param artifact The artifact to add.
   */
  fun addArtifact(artifact: Artifact)

  /**
   * Adds the [Issue] to the [TestSuiteResult].
   *
   * @param issue The Issue to log.
   */
  fun addIssue(issue: Issue)

  /**
   * Logs the [ErrorDetail] as a failure in the [TestSuiteResult]. This will show up in the
   * PlatformError.
   *
   * @param error The stack trace to log.
   */
  fun addError(error: ErrorDetail)

  /**
   * Logs the [Throwable] as a failure in the [TestSuiteResult]. This will show up in the
   * PlatformError.
   *
   * @param error The stack trace to log.
   */
  fun addError(error: Throwable)

  /** Clears the PlatformError. */
  fun clearError()

  /**
   * Sets the status of the [TestSuiteResult], overriding any calculations based on other events.
   *
   * @param status The status to set.
   */
  fun setStatus(status: TestStatus)

  /** Build and return [TestSuiteResult]. */
  fun buildTestSuiteResult(inProgress: Boolean = false): TestSuiteResult
}

@ThreadSafe
interface TestSuiteCreatorFactory {
  fun create(): TestSuiteCreator
}
