/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.util.Collections
import javax.inject.Inject

/** [TestResultListener] that writes the [TestSuiteResult] it receives to log files. */
@ThreadSafe
class ProtoLogTestResultListener @Inject constructor(writers: Set<ProtoLogWriter>) :
  TestResultListener by BaseTestResultListener() {
  private val logWriters = writers.toSet()
  private val suites = Collections.synchronizedMap(mutableMapOf<String, TestSuiteResult>())

  /** Stores the [TestSuiteResult], which might be updated. */
  override fun afterTestSuite(testSuiteResult: TestSuiteResult) {
    suites[testSuiteResult.testSuiteMetaData.device.id] = testSuiteResult
  }

  /** Writes the [TestSuiteResult] to log files. */
  override fun afterAllTestSuites() {
    val snapshot = synchronized(suites) { suites.toMap().values }
    for (testSuiteResult in snapshot) {
      for (logWriter in logWriters) {
        logWriter.write(testSuiteResult)
      }
    }
  }
}
