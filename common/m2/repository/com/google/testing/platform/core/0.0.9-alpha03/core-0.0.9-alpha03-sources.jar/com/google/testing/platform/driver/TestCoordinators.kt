/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.driver

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.device.Device
import com.google.testing.platform.api.driver.TestCoordinator
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import java.util.Collections
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.SendChannel
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.consumeAsFlow
import kotlinx.coroutines.flow.onCompletion
import kotlinx.coroutines.flow.onEach

object TestCoordinators {
  /** Test coordinator for the primary device. */
  @ThreadSafe
  class PrimaryTestCoordinator : TestCoordinator {
    private var auxiliaries =
      Collections.synchronizedList(mutableListOf<AuxiliaryTestCoordinator>())

    fun add(auxiliary: AuxiliaryTestCoordinator) {
      auxiliaries.add(auxiliary)
    }

    override suspend fun coordinate(
      device: Device,
      testCases: List<TestCase>,
      runner: TestCoordinator.Runner,
    ) {
      val snapshot = synchronized(auxiliaries) { auxiliaries.toList() }
      try {
        runner.devicesReady(listOf(device) + snapshot.map { it.getDevice() })
        for (testCase in testCases) {
          for (auxiliary in snapshot) {
            auxiliary.testChannel.send(testCase)
          }
          runner.run(testCase, testCase)
        }
      } catch (t: Throwable) {
        for (auxiliary in snapshot) {
          auxiliary.testChannel.close(t)
        }
        runner.fail(t)
      } finally {
        for (auxiliary in snapshot) {
          auxiliary.testChannel.close()
        }
      }
    }

    private companion object {
      val logger = getLogger()
    }
  }

  /** Test coordinator for an auxiliary device. */
  @ThreadSafe
  class AuxiliaryTestCoordinator(val deviceName: String, val warnOnMissedTest: Boolean = false) :
    TestCoordinator {
    private val channel = Channel<TestCase>(Channel.UNLIMITED)
    internal val testChannel: SendChannel<TestCase>
      get() = channel

    private val device = CompletableDeferred<Device>()

    internal suspend fun getDevice(): Device {
      return device.await()
    }

    override suspend fun coordinate(
      device: Device,
      testCases: List<TestCase>,
      runner: TestCoordinator.Runner,
    ) {
      this.device.complete(device)
      val localTestCases = testCases.associateBy { it.testMethod }.toMutableMap()
      channel
        .consumeAsFlow()
        .onEach { testCase -> runner.run(localTestCases.remove(testCase.testMethod), testCase) }
        .catch { t: Throwable -> runner.fail(t) }
        .onCompletion { logger.fine("Auxiliary test coordinator completed") }
        .collect()
      if (localTestCases.isNotEmpty()) {
        val message = "$deviceName missed test cases: ${localTestCases.keys.joinToString(", ")}"
        if (warnOnMissedTest) {
          logger.warning(message)
        } else {
          throw IllegalStateException(message)
        }
      }
    }

    private companion object {
      val logger = getLogger()
    }
  }
}
