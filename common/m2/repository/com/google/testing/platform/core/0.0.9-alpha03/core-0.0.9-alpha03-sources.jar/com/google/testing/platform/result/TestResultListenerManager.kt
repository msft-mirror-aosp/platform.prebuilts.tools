/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.ThreadSafe
import com.google.testing.platform.api.result.TestResultListener
import com.google.testing.platform.core.result.ResultConsumer
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import java.util.concurrent.atomic.AtomicBoolean
import java.util.logging.Level
import javax.inject.Inject

/**
 * A [TestResultListener] that facilitates communication between a
 * [com.google.testing.platform.core.executor.Executor]'s [ResultConsumer] and any
 * [TestResultListener] interested in receiving the testing progress and status from a run. Also
 * builds up the test suite result and returns it finally after the test run is complete.
 */
@ThreadSafe
class TestResultListenerManager
@Inject
constructor(listeners: Set<@JvmSuppressWildcards TestResultListener>) : TestResultListener {
  private val testResultListeners: Set<TestResultListener> = listeners.toSet()

  private val isAfterAllTestSuitesCalled = AtomicBoolean(false)

  /**
   * Add the [TestSuiteMetaData] if necessary and runs all [TestResultListener] when a test suite
   * starts.
   */
  override fun beforeTestSuite(testSuiteMetaData: TestSuiteMetaData?) {
    for (listener in testResultListeners) {
      invokeOrLog(listener::class.simpleName!!) { listener.beforeTestSuite(testSuiteMetaData) }
    }
  }

  /** Runs all TestResultListeners before a test run starts. */
  override fun beforeTest(testCase: TestCase?) {
    for (listener in testResultListeners) {
      invokeOrLog(listener::class.simpleName!!) { listener.beforeTest(testCase) }
    }
  }

  /**
   * Updates all testResultListeners with the next [TestResult] when it finishes.
   *
   * @param testResult the next [TestResult]
   */
  override fun afterTest(testResult: TestResult) {
    // Dispatch the final test result to registered listeners
    for (listener in testResultListeners) {
      invokeOrLog(listener::class.simpleName!!) { listener.afterTest(testResult) }
    }
  }

  /**
   * Updates all testResultListeners with the [TestSuiteResult].
   *
   * This function is synchronized as it can be called by the executor thread and the cancellation
   * thread.
   *
   * @param testSuiteResult a [TestSuiteResult] containing all [TestResult] protos in this run
   */
  @Synchronized
  override fun afterTestSuite(testSuiteResult: TestSuiteResult) {
    for (listener in testResultListeners) {
      invokeOrLog(listener::class.simpleName!!) { listener.afterTestSuite(testSuiteResult) }
    }
  }

  override fun afterAllTestSuites() {
    check(isAfterAllTestSuitesCalled.compareAndSet(false, true)) {
      "afterAllTestSuites should only be called once!"
    }
    for (listener in testResultListeners) {
      Telemetry.createEvent("${listener::class.simpleName!!}.afterAllTestSuites") {
          run { invokeOrLog(listener::class.simpleName!!) { listener.afterAllTestSuites() } }
        }
        .getOrThrow()
    }
    logger.fine("Finished final call of all the result listeners.")
  }

  /**
   * Invokes the block with `this`, catches all exceptions and logs them as warnings.
   *
   * @param block lambda function that performs calls on a [TestResultListener].s
   */
  private fun <R> invokeOrLog(listener: String, block: () -> R) {
    try {
      block()
    } catch (t: Throwable) {
      logger.log(
        Level.SEVERE,
        "Exception thrown during test result listener $listener invocation",
        t,
      )
    }
  }

  companion object {
    val logger = getLogger()
  }
}
