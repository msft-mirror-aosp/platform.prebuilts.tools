/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.executor

import com.google.testing.platform.api.cancel.Cancellable
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.device.DeviceProvider
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.config.v1.extension.deviceExecutionTestFixtureId
import com.google.testing.platform.config.v1.extension.lookupTestFixtureById
import com.google.testing.platform.core.context.GlobalContextImpl
import com.google.testing.platform.core.error.config.ErrorUpdater
import com.google.testing.platform.core.executor.Executor
import com.google.testing.platform.core.executor.configureOrThrow
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.driver.TestCoordinators.PrimaryTestCoordinator
import com.google.testing.platform.executor.ExecutorExt.cancelAndCatch
import com.google.testing.platform.executor.ExecutorExt.joinOrCancelOnTimeout
import com.google.testing.platform.executor.ExecutorExt.reportCancellation
import com.google.testing.platform.executor.ExecutorExt.reportEvents
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.coroutines.Dispatchers.cachedThreadDispatcher
import com.google.testing.platform.lib.coroutines.job.findName
import com.google.testing.platform.lib.coroutines.job.verboseJoin
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.plugin.PluginLifecycle
import com.google.testing.platform.proto.api.config.DeviceProto.DeviceId
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.proto.api.config.deviceId
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import com.google.testing.platform.proto.api.core.testSuiteMetaData
import com.google.testing.platform.result.DeviceTestResultPublisher
import dagger.Lazy
import java.util.Collections
import java.util.logging.Level
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.CoroutineName
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.newCoroutineContext
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

/** A single device executor */
class SingleDeviceExecutor
@Inject
constructor(
  private val lazyDeviceProvider: Lazy<DeviceProvider<DeviceController>>,
  private val lazyTestDriver: Lazy<TestDriver>,
  private val pluginLifecycle: PluginLifecycle,
  private val rootCoroutineScope: CoroutineScope,
  private val cancellationContext: ProcessCancellationContext,
  private val errorMessageUpdater: ErrorUpdater,
  private val events: Events,
  private val portPicker: PortPicker? = null,
) : Executor {

  private lateinit var deviceProvider: DeviceProvider<DeviceController>
  private lateinit var testDriver: TestDriver
  private lateinit var deviceId: DeviceId
  private lateinit var runnerConfig: RunnerConfig
  // A job to manage the lifespans of all the coroutines launched beneath this Executor. Once it
  // joins, we know it's reasonable to publish test results.
  private val supervisorJob = SupervisorJob(rootCoroutineScope.coroutineContext[Job])
  // If the supervisorJob is cancelled, this is provided for host plugins that do cleanup after
  // the cancellation unstuck things.
  private val cleanupJob = SupervisorJob(rootCoroutineScope.coroutineContext[Job])
  private val cancellable = Collections.synchronizedList(mutableListOf<Cancellable>())
  private var cancelling: Deferred<Boolean>? = null

  private companion object {
    private val logger = getLogger()

    private fun RunnerConfig.toProxyConfig() =
      ProxyConfig(
        this,
        this.singleDeviceExecutor.deviceExecution.deviceId.withDefaultName("primary"),
        this.singleDeviceExecutor.deviceExecution.testFixtureId,
      )

    private fun DeviceId.withDefaultName(defaultName: String): DeviceId {
      if (friendlyName.isNullOrEmpty())
        return deviceId {
          id = this@withDefaultName.id
          friendlyName = defaultName
        }
      else {
        return this
      }
    }
  }

  override fun configure(config: RunnerConfig) {
    runnerConfig = config
    try {
      configureOrThrow {
        deviceProvider = lazyDeviceProvider.get().also { cancellable.add(it) }
        testDriver = lazyTestDriver.get().also { cancellable.add(it) }
        val proxyConfig = config.toProxyConfig()
        val dispatcher = cachedThreadDispatcher(proxyConfig.deviceId.friendlyName)
        val coroutineContext =
          rootCoroutineScope.newCoroutineContext(
            supervisorJob + dispatcher + CoroutineName("SingleDeviceExecutor")
          )
        val globalContext =
          GlobalContextImpl(
            contextMap =
              mutableMapOf(
                Context.CLEANUP_JOB_KEY to cleanupJob,
                Context.CONFIG_KEY to proxyConfig,
                Context.COORDINATOR_KEY to PrimaryTestCoordinator(),
                Context.COROUTINE_CONTEXT_KEY to coroutineContext,
                Context.DIAGNOSTICS_KEY to Telemetry.diagnostics,
                Context.EVENTS_KEY to events,
                Context.PORTPICKER_KEY to portPicker,
              )
          )
        deviceProvider.configure(globalContext)
        testDriver.configure(globalContext)
        deviceId = proxyConfig.deviceId
        val testFixtureId = config.deviceExecutionTestFixtureId
        val testFixture = config.lookupTestFixtureById(testFixtureId)
        pluginLifecycle.onConfigure(testFixture, globalContext)
      }
    } catch (t: Throwable) {
      supervisorJob.complete()
      cleanupJob.complete()
      throw t
    }
  }

  override fun execute(testResultPublisher: TestResultPublisher): List<TestSuiteResult> {
    // The DeviceId is the underlying key used to track test results in the publisher. A more
    // detailed set of metadata will be supplied by the TestDriver.
    val testSuiteId = testSuiteMetaData { device = deviceId }
    // Wrap the TestResultPublisher with one that will guarantee that the device ID is set, even
    // if someone forgets to specify it.
    val deviceTestResultPublisher = DeviceTestResultPublisher(testResultPublisher, deviceId)
    var deviceController: DeviceController? = null
    try {
      // Keep all the execution logic within the try-catch block, so that the test suite result is
      // properly handled in [testResultPublisher].
      deviceController = cancellationContext.runUnlessCancelled { deviceProvider.provideDevice() }

      deviceController?.let {
        cancellationContext.runUnlessCancelled { pluginLifecycle.onBeforeAll(deviceController) }

        cancellationContext.runUnlessCancelled {
          testDriver.run(
            deviceController,
            pluginLifecycle.hookPublisher(deviceTestResultPublisher, deviceController),
          )
        }

        if (cancellationContext.isCancelling) {
          cancellationContext.reportCancellation(testSuiteId, deviceTestResultPublisher)
        }
      }
    } catch (throwable: Throwable) {
      var updatedThrowable = errorMessageUpdater.updateInfo(throwable)
      logger.log(Level.SEVERE, "Test execution failed with fatal error!", updatedThrowable)
      deviceTestResultPublisher.failTestSuite(testSuiteId, updatedThrowable)
    } finally {
      deviceController?.let {
        try {
          pluginLifecycle.onAfterAll(testSuiteId, deviceTestResultPublisher, deviceController)
        } catch (ce: CancellationException) {
          logger.log(Level.WARNING, "afterAll lifecycle canceled", ce)
        }
        releaseDevice()
        logger.finest("released device")
      }
      events.reportEvents(testSuiteId, deviceTestResultPublisher)
      deviceTestResultPublisher.afterTestSuite(testSuiteId)
      runBlocking(
        rootCoroutineScope.newCoroutineContext(CoroutineName("SingleDeviceExecutor completing"))
      ) {
        logger.finest("completing supervisor job")
        supervisorJob.complete()
        logger.finest(
          "waiting for supervisor job to join: ${supervisorJob.children.count()} children"
        )
        // Just in case there are any uncompleted child Jobs pending, complete them. The device has
        // already been released and no one should be spawning new ones at this time.
        for (child in supervisorJob.children) {
          logger.finest("child: ${child.findName()}")
          (child as? CompletableJob)?.complete()
        }
        try {
          supervisorJob.verboseJoin(logger)
        } catch (t: Throwable) {
          logger.log(Level.WARNING, "supervisor job joined with error", t)
        }
        logger.finest("supervisor job joined")
      }
    }
    // If an exception is thrown, RunnerImpl will be calling publish().
    return deviceTestResultPublisher.publish().also { cleanupJob.complete() }
  }

  private fun releaseDevice() {
    try {
      deviceProvider.releaseDevice()
    } catch (t: Throwable) {
      logger.log(Level.WARNING, "Failed to release device", t)
    }
  }

  override fun cancel(aborted: Boolean): Boolean {
    logger.fine("cancelling executor")
    if (supervisorJob.isCancelled) {
      // Nothing to do.
      return true
    }
    if (supervisorJob.isCompleted) {
      // Cancel got called after the device was released.
      return false
    }
    cancelling?.let {
      if (aborted) {
        // It is possible that a plugin cancels the test using cancel(false), then the cleanup
        // takes so long that cancel(true) comes in when the test times out. In this case, we
        // cancel the coroutine that is doing the lackadasical canceling so we can start one that
        // tells everyone to abort.
        it.cancel()
      } else {
        // Don't do anything on multiple cancel(false)
        return true
      }
    }

    // An ingredient for giving the coroutines distinct names.
    val aborting = if (aborted) " (aborting)" else ""

    // Cancel all the extensions loaded. This should stop any ongoing operation and prevent any
    // further operations by these extensions, allowing the main executor thread to finish. None
    // of the things that UnsafeCoroutineCrossing is complaining about are going to change by the
    // time this gets called.
    @Suppress("UnsafeCoroutineCrossing")
    val deferredCancelling =
      rootCoroutineScope.async(CoroutineName("SingleDeviceExecutor cancel$aborting")) {
        val extensionCancellations =
          async(CoroutineName("ExtensionCancellations$aborting")) {
            cancellable.reversed().map { it.cancelAndCatch(aborted) }.any { it }
          }
        var result = false
        if (aborted) result = supervisorJob.joinOrCancelOnTimeout(runnerConfig.cancellationConfig)
        result || extensionCancellations.await()
      }

    cancelling = deferredCancelling

    // Cancellation should be very fast. If it all happens in 100ms, get the actual result from
    // the coroutine. Otherwise, return true, since cancel is clearly doing work, and let the
    // job run. (Experiment with the unit test shows that 10ms is *too* short for the fast path
    // to reliably avoid timeout.)
    return runBlocking(
      rootCoroutineScope.newCoroutineContext(CoroutineName("SingleDeviceExecutor.cancel Wait"))
    ) {
      try {
        withTimeout(100.milliseconds) { deferredCancelling.await() }
          .also { logger.info("All cancellation jobs have joined.") }
      } catch (t: Throwable) {
        true
      }
    }
  }
}
