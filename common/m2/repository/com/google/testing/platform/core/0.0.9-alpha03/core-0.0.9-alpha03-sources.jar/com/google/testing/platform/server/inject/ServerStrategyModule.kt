/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.server.inject

import com.google.testing.platform.api.event.Events
import com.google.testing.platform.config.ConfigurationException
import com.google.testing.platform.core.telemetry.core.Diagnostics
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig
import com.google.testing.platform.server.ServerStrategy
import com.google.testing.platform.server.strategy.InteractiveServerStrategy
import com.google.testing.platform.server.strategy.NonInteractiveServerStrategy
import dagger.Module
import dagger.Provides
import io.grpc.Server
import kotlinx.coroutines.CoroutineScope

/** Provides [ServerStrategy] to run server. */
@Module
class ServerStrategyModule {
  @Provides
  fun providesServerStrategy(
    config: RunnerConfig?,
    server: Server?,
    diagnostics: Diagnostics,
    rootCoroutineScope: CoroutineScope,
    cancellationContext: ProcessCancellationContext,
    events: Events,
  ): ServerStrategy {
    if (config == null && server == null) {
      throw ConfigurationException(
        "Both RunnerConfig and ServerConfig cannot be empty, please provide at least one."
      )
    }
    return if (config != null) {
      NonInteractiveServerStrategy(
        config,
        diagnostics,
        rootCoroutineScope,
        cancellationContext,
        events,
      )
    } else {
      InteractiveServerStrategy(server!!)
    }
  }
}
