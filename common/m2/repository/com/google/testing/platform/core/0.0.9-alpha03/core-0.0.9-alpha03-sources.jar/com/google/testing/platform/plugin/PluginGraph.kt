/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.testing.platform.api.cancel.PluginCancellationContext
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.plugin.HostPlugin

/** Reads the annotations from a set of HostPlugins and orders them in a graph. */
interface PluginGraph {
  /** Returns the order in which to execute HostPlugins for the specified method. */
  fun order(context: Context, method: String): Sequence<HostPlugin>

  /**
   * Returns a custom context for the particular HostPlugin, with the specified configuration as the
   * CONFIG_KEY.
   *
   * Args:
   * @param parentContext: The parent Context, to which the custom Context will delegate.
   * @param configuration: Context.CONFIG_KEY in the custom Context will map to this.
   * @param pluginCancellationContext: Context.CANCEL_KEY will map to this enabling plugins to
   * cancel tests.
   * @param hostPlugin: the plugin for which this Context should be generated.
   */
  fun customContext(
    parentContext: Context,
    configuration: Any,
    pluginCancellationContext: PluginCancellationContext,
    hostPlugin: HostPlugin
  ): Context
}
