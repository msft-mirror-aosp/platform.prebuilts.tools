package com.google.testing.platform.service;

import com.google.testing.platform.api.event.Events;
import com.google.testing.platform.inject.RunnerComponent;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RunnerServiceImpl_Factory implements Factory<RunnerServiceImpl> {
  private final Provider<RunnerManager> managerProvider;

  private final Provider<RunnerComponent.Builder> builderProvider;

  private final Provider<Events> eventsProvider;

  public RunnerServiceImpl_Factory(Provider<RunnerManager> managerProvider,
      Provider<RunnerComponent.Builder> builderProvider, Provider<Events> eventsProvider) {
    this.managerProvider = managerProvider;
    this.builderProvider = builderProvider;
    this.eventsProvider = eventsProvider;
  }

  @Override
  public RunnerServiceImpl get() {
    return newInstance(managerProvider.get(), builderProvider, eventsProvider.get());
  }

  public static RunnerServiceImpl_Factory create(Provider<RunnerManager> managerProvider,
      Provider<RunnerComponent.Builder> builderProvider, Provider<Events> eventsProvider) {
    return new RunnerServiceImpl_Factory(managerProvider, builderProvider, eventsProvider);
  }

  public static RunnerServiceImpl newInstance(RunnerManager manager,
      Provider<RunnerComponent.Builder> builderProvider, Events events) {
    return new RunnerServiceImpl(manager, builderProvider, events);
  }
}
