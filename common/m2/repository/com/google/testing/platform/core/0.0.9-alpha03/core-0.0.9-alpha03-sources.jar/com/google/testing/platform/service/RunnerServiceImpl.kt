/*
 * Copyright (C) 2019 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.service

import com.google.rpc.Status as StatusProto
import com.google.testing.platform.api.event.Events
import com.google.testing.platform.config.ConfigurationException
import com.google.testing.platform.inject.RunnerComponent
import com.google.testing.platform.lib.cancellation.PluginCancellationDelegate
import com.google.testing.platform.lib.cancellation.ProcessCancellationContext
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.proto.api.service.CancelRequestProto.CancelRequest
import com.google.testing.platform.proto.api.service.RunIdProto.RunId
import com.google.testing.platform.proto.api.service.RunRequestProto.RunRequest
import com.google.testing.platform.proto.api.service.RunnerGrpc
import com.google.testing.platform.service.ext.toMessage
import io.grpc.Status
import io.grpc.stub.StreamObserver
import java.util.logging.Level
import java.util.logging.Logger
import javax.inject.Inject
import javax.inject.Provider
import kotlinx.coroutines.CoroutineScope

/** Service to start test runs and cancel test runs from remote processes. */
class RunnerServiceImpl
@Inject
constructor(
  private val manager: RunnerManager,
  private val builderProvider: Provider<RunnerComponent.Builder>,
  private val events: Events,
) : RunnerGrpc.RunnerImplBase() {
  companion object {
    @JvmStatic private val logger: Logger = getLogger()

    /** For [Status.description] field. */
    object ErrorMessages {
      fun invalidConfiguration(ex: Exception) = "The provided runner configuration was invalid: $ex"

      fun alreadyExists(id: RunId) = "Test run already exists with ID: ${id.id}"

      fun notFound(id: RunId) = "Test run not found with ID: ${id.id}"

      const val INTERNAL = "Failed due to internal server error."
    }
  }

  /**
   * Starts a test run and returns whether it was started. Validates the request in the order of the
   * returnable Status Codes.
   *
   * @param [RunRequest]
   * @returns [google.rpc.Code.InvalidArgument] if [RunRequest] is invalid.
   * @returns [google.rpc.Code.AlreadyExists] if [RunId] is already running on server.
   * @returns [google.rpc.Code.Ok] if valid [RunId] and [RunnerConfig].
   */
  override fun run(request: RunRequest?, responseObserver: StreamObserver<StatusProto>?) {
    check(request != null)
    check(responseObserver != null)

    try {
        val cancellationContext = ProcessCancellationContext()
        val runner =
          builderProvider
            .get()
            .config(request.runConfig)
            .cancellationContext(cancellationContext)
            .pluginCancellationDelegate(
              PluginCancellationDelegate(cancellationContext) { manager.cancel(request.id) }
            )
            .rootCoroutineScope(CoroutineScope(manager.coroutineContext))
            .events(events)
            .build()
            .runner

        if (manager.run(request.id, runner)) {
          Status.OK.withDescription("Test run started.")
        } else {
          Status.ALREADY_EXISTS.withDescription(ErrorMessages.alreadyExists(request.id))
        }
      } catch (ex: ConfigurationException) {
        logger.log(Level.SEVERE, "Configuration error", ex)
        Status.INVALID_ARGUMENT.withDescription(ErrorMessages.invalidConfiguration(ex))
          .withCause(ex)
      } catch (ex: Exception) {
        logger.log(Level.SEVERE, "Run rpc failed due to internal error", ex)

        Status.INTERNAL.withDescription(ErrorMessages.INTERNAL).withCause(ex)
      }
      .let { responseObserver.reply(it) }
  }

  /**
   * Cancels an in-progress test run.
   *
   * @param [RunRequest]
   * @returns [google.rpc.Code.Ok] if valid [RunId] was successfully cancelled.
   * @returns [google.rpc.Code.NotFound] if [RunId] is not active on server.
   */
  override fun cancel(request: CancelRequest?, responseObserver: StreamObserver<StatusProto>?) {
    check(request != null)
    check(responseObserver != null)

    try {
        if (!manager.cancel(request.id)) {
          Status.NOT_FOUND.withDescription(ErrorMessages.notFound(request.id))
        } else {
          Status.OK.withDescription("Test run cancelled.")
        }
      } catch (ex: Exception) {
        logger.severe("Cancel rpc failed due to internal error: $ex")

        Status.INTERNAL.withDescription(ErrorMessages.INTERNAL).withCause(ex)
      }
      .let { responseObserver.reply(it) }
  }
}

private fun StreamObserver<StatusProto>.reply(status: Status) =
  if (status.isOk) {
    onNext(status.toMessage())
    onCompleted()
  } else {
    status.asRuntimeException().let { onError(it) }
  }
