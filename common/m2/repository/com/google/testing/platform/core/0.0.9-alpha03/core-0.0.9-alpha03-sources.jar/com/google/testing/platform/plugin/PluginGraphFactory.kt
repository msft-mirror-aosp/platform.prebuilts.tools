/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin

import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixture
import com.google.testing.platform.proto.api.config.RunnerConfigProto.RunnerConfig

/** Creates a PluginGraph. */
class PluginGraphFactory
constructor(
  private val runnerConfig: RunnerConfig,
  private val testFixture: TestFixture,
) {
  fun create(plugins: Set<HostPlugin>): PluginGraph {
    val selfOrdering = runnerConfig.features.hostPluginSelfOrdering.takeIf { it.isInitialized }
    if (selfOrdering?.value == true) {
      return OrderedPluginGraph(plugins, testFixture.environment.randomSeed)
    } else {
      return TrivialPluginGraph(plugins)
    }
  }
}
