/*
 * Copyright (C) 2021 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.result

import com.google.errorprone.annotations.CanIgnoreReturnValue
import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.core.error.ext.signature
import com.google.testing.platform.core.error.ext.toErrorDetail
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.core.Detail
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.proto.api.core.ErrorDetailProto
import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.ABORTED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.CANCELLED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.ERROR
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.FAILED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.IGNORED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.PASSED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.SKIPPED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.STARTED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.TEST_STATUS_UNSPECIFIED
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import com.google.testing.platform.proto.api.core.errorDetail
import com.google.testing.platform.proto.api.core.errorSummary
import com.google.testing.platform.proto.api.core.label
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.TimeoutCancellationException

/** Extension functions for [TestSuiteResult] */
object TestSuiteResultExt {
  private val ERROR_FINAL_STATUSES = setOf(ERROR, TEST_STATUS_UNSPECIFIED, STARTED, ABORTED)
  private val FAILED_FINAL_STATUSES = setOf(FAILED, CANCELLED)
  private val PASSED_FINAL_STATUSES = setOf(PASSED, IGNORED, SKIPPED)
  private val SKIPPED_FINAL_STATUSES = setOf(IGNORED, SKIPPED)

  /**
   * Assigns a new [com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus] to this
   * [TestSuiteResult.Builder] based on all of the statuses of all of its
   * [com.google.testing.platform.proto.api.core.TestResultProto.TestResult]s.
   */
  @CanIgnoreReturnValue
  fun TestSuiteResult.Builder.determineStatusFromTestStatuses(): TestSuiteResult.Builder {
    val testResultStatuses = testResultList.map { it.testStatus }
    // Conditions evaluated sequentially, hence ABORTED > ERROR > FAILED > SKIPPED > PASSED
    testStatus =
      when {
        testResultStatuses.isEmpty() -> SKIPPED
        testResultStatuses.any { it == ABORTED } -> ABORTED
        testResultStatuses.any { it in ERROR_FINAL_STATUSES } -> ERROR
        testResultStatuses.any { it in FAILED_FINAL_STATUSES } -> FAILED
        testResultStatuses.all { it in SKIPPED_FINAL_STATUSES } -> SKIPPED
        testResultStatuses.all { it in PASSED_FINAL_STATUSES } -> PASSED
        // This should never happen.
        else ->
          throw IllegalStateException(
            "Invalid TestStatus detected: ${testResultStatuses.joinToString(", ")}"
          )
      }
    return this
  }

  @CanIgnoreReturnValue
  fun TestSuiteResult.Builder.handleError(throwable: Throwable): TestSuiteResult.Builder =
    // Note that we wrap the code around a Telemetry.createEvent call not because we expect the
    // duration to be long, but because we want stack trace information to be stored for searching
    // later. Only the stack trace's signature is added to avoid taking too much space.
    Telemetry.createEvent("TestSuiteResultExt.handleError") {
        phase = TestPhase.TEARDOWN
        addAllAttributes(buildDetails(throwable))
        run {
          this@handleError.apply {
            val detail = extractErrorDetail(throwable)
            platformErrorBuilder.addErrors(detail)
            var t: Throwable? = throwable
            do {
              if (t is TimeoutCancellationException) {
                // A TimeoutCancellationException should not cause ABORTED.
                break
              }
              if (t is CancellationException) {
                // A regular CancellationException should only be thrown from a test if the top
                // level SupervisorJob was canceled.
                testStatus = ABORTED
                break
              }
              t = t?.cause
            } while (t != null)
          }
        }
      }
      .getOrThrow()

  fun summarizeCancellations(cancellationReasons: Set<Throwable>): ErrorDetailProto.ErrorDetail {
    if (cancellationReasons.isEmpty()) {
      return errorDetail {
        summary = errorSummary {
          namespace = label { namespace = "com.google.testing.platform" }
          errorCode = UtpCoreErrorSummary.ABORTED.errorCode
          errorName = UtpCoreErrorSummary.ABORTED.name
          errorClassification = UtpCoreErrorSummary.ABORTED.errorType.name
          errorMessage = "UTP was aborted externally"
        }
      }
    }
    val mainErrorDetail = extractErrorDetail(cancellationReasons.first())
    val additionalErrorDetails =
      cancellationReasons.drop(1).map { extractErrorDetail(it).build() }.toSet()
    mainErrorDetail.addAllSuppressed(additionalErrorDetails)
    return mainErrorDetail.build()
  }

  fun extractErrorDetail(throwable: Throwable): ErrorDetailProto.ErrorDetail.Builder {
    return if (throwable is UtpException) {
        throwable.toErrorDetail(throwable.errorSummary)
      } else {
        throwable.toErrorDetail(UtpCoreErrorSummary.CORE_FAILED)
      }
      .toBuilder()
  }

  private fun buildDetails(throwable: Throwable) =
    mapOf("StackTraceSignature" to Detail(throwable.signature))
}
