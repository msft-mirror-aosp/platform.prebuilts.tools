/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.extension

/**
 * Factory that creates an isolated ClassLoader from a [ExtensionSource].
 */
interface ExtensionClassLoaderFactory {
  /**
   * Creates an isolated ClassLoader from extension sources.
   *
   * @param extensionSource the extension source of this ClassLoader
   *
   * @return the isolated ClassLoader
   */
  fun createFromSource(extensionSource: ExtensionSource): ClassLoader
}
