/*
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.driver

import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.driver.TestDriver
import com.google.testing.platform.api.driver.TestDriverConfigImpl
import com.google.testing.platform.api.net.PortPicker
import com.google.testing.platform.api.result.TestResultPublisher
import com.google.testing.platform.config.v1.extension.androidSdkOrEmpty
import com.google.testing.platform.config.v1.extension.lookupTestDriverById
import com.google.testing.platform.config.v1.extension.lookupTestFixtureById
import com.google.testing.platform.config.v1.extension.shardingConfig
import com.google.testing.platform.core.context.ExtensionContextImpl
import com.google.testing.platform.core.driver.TestDriverErrorSummary
import com.google.testing.platform.core.driver.TestDriverException
import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.UtpException
import com.google.testing.platform.core.telemetry.Telemetry
import com.google.testing.platform.core.telemetry.createEvent
import com.google.testing.platform.executor.ProxyConfig
import com.google.testing.platform.extension.extensionSourceFrom
import com.google.testing.platform.extension.loadAndConfigure
import com.google.testing.platform.proto.api.config.FixtureProto.TestFixtureId
import com.google.testing.platform.proto.api.config.RunnerConfigProto
import com.google.testing.platform.proto.api.core.ExtensionProto.Extension
import com.google.testing.platform.proto.api.core.PhaseProto.TestPhase
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException

/**
 * Proxy implementation of the [TestDriver] implementation which loads the supplied TestDriver and
 * delegates to it.
 */
class TestDriverProxy
constructor(
  private val delegateDriver: TestDriver,
  private val fixtureId: TestFixtureId,
  private val portPicker: PortPicker? = null,
) : TestDriver by delegateDriver {

  private lateinit var delegateContext: Context

  @Inject
  constructor(
    config: RunnerConfigProto.RunnerConfig,
    fixture: TestFixtureId,
    portPicker: PortPicker?,
  ) : this(
    delegateDriver = loadDelegateDriver(config.lookupTestDriverById(fixture)),
    fixture,
    portPicker = portPicker,
  )

  private companion object {
    private const val TEST_DRIVER_RUN_EVENT = "TestDriver.Run"

    private const val TEST_DRIVER_CANCEL_EVENT = "TestDriver.Cancel"

    /** Classload the driver service from the extension proto supplied. */
    fun loadDelegateDriver(driverProto: Extension): TestDriver {
      val driverClassName = driverProto.className
      val driverLabel = driverProto.label.label
      val driverJarPath = driverProto.jarList
      return loadAndConfigure<TestDriver>(
        driverLabel,
        driverClassName,
        listOf(
          extensionSourceFrom(
            driverClassName,
            driverJarPath.map { it.path },
            driverProto.useSingleClassLoader,
          )
        ),
      )
        ?: throw TestDriverException(
          "Cannot load test driver: <$driverClassName>",
          UtpCoreErrorSummary.EXTENSION_CLASS_LOADING_FAILURE,
        )
    }
  }

  override fun configure(context: Context) {
    val config = context.config as ProxyConfig
    val runnerConfig = config.runnerConfig
    val fixture = runnerConfig.lookupTestFixtureById(fixtureId)
    val extensionProto = fixture.testDriver
    val driverConfig =
      TestDriverConfigImpl.parseFrom(
        androidSdkProto = fixture.androidSdkOrEmpty,
        environmentProto = fixture.environment,
        testSetupProto = fixture.setup,
        shardingConfig = runnerConfig.shardingConfig,
        testDiscovery = fixture.testDiscovery,
        configProto = if (extensionProto.hasConfig()) extensionProto.config else null,
        configResource = if (extensionProto.hasResource()) extensionProto.resource else null,
        deviceId = config.deviceId,
        portPicker = portPicker,
      )
    // The ExtensionContextImpl will delegate to the parentContext, so other keys like
    // Context.EVENTS_KEY will be inherited.
    delegateContext =
      ExtensionContextImpl(
        parentContext = context,
        contextMap = mutableMapOf(Context.CONFIG_KEY to driverConfig),
      )
    try {
      delegateDriver.configure(delegateContext)
    } catch (x: TestDriverException) {
      // We can presume the TestDriver knows what it's doing.
      throw x
    } catch (throwable: Throwable) {
      throw TestDriverException(
        "Configuring test driver <${delegateDriver::class.java.name}> failed!",
        TestDriverErrorSummary.DRIVER_CONFIG_ERROR,
        throwable,
      )
    }
  }

  override fun run(controller: DeviceController, testResultPublisher: TestResultPublisher) {
    try {
      Telemetry.createEvent(TEST_DRIVER_RUN_EVENT) {
          phase = TestPhase.TEST
          run { delegateDriver.run(controller, testResultPublisher) }
        }
        .getOrThrow()
    } catch (x: TestDriverException) {
      // We can presume the TestDriver knows what it's doing.
      throw x
    } catch (utpEx: UtpException) {
      // Propagate the underlying exception message so that it is visible at the top for consumers.
      throw TestDriverException(
        message = utpEx.message ?: "Test execution failed in Test Driver.",
        errorSummary = TestDriverErrorSummary.TEST_EXECUTION_FAILED,
        throwable = utpEx,
      )
    } catch (x: CancellationException) {
      throw TestDriverException(
        message = "Test driver <${delegateDriver::class.java.name}> was canceled.",
        errorSummary = TestDriverErrorSummary.TEST_INTERRUPTED,
        throwable = x,
      )
    } catch (throwable: Throwable) {
      throw TestDriverException(
        "Test execution failed on test driver <${delegateDriver::class.java.name}>!" +
          "Test failures could be due to various issues like incorrectly configuring the driver, " +
          "timeouts, incorrect test environment etc. Check logs for more info.",
        TestDriverErrorSummary.TEST_EXECUTION_FAILED,
        throwable,
      )
    }
  }

  override fun cancel(aborted: Boolean): Boolean {
    return Telemetry.createEvent(TEST_DRIVER_CANCEL_EVENT) {
        phase = TestPhase.TEST
        run { delegateDriver.cancel(aborted) }
      }
      .getOrThrow()
  }
}
