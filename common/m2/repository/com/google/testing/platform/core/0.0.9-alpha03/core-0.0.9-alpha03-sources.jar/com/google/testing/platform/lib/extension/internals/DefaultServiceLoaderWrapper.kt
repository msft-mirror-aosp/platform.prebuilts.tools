/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.lib.extension.internals

import com.google.testing.platform.lib.extension.ServiceLoaderWrapper
import java.util.ServiceLoader

/**
 * Concrete Implementation of a [ServiceLoaderWrapper] that invokes [ServiceLoader.load].
 */
object DefaultServiceLoaderWrapper : ServiceLoaderWrapper {

  /**
   * Loads service implementations for a service interface.
   *
   * @param serviceClass the service implementation to load
   * @param classLoader the ClassLoader to load the service implementation from
   * @return List of service implementations
   */
  override fun <T> loadService(serviceClass: Class<T>, classLoader: ClassLoader): List<T> {
    return ServiceLoader.load(serviceClass, classLoader).toList()
  }
}
