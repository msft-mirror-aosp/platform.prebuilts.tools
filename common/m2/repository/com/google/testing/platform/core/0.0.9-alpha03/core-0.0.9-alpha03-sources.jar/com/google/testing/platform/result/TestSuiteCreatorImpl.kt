/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.testing.platform.result

import com.google.errorprone.annotations.concurrent.GuardedBy
import com.google.testing.platform.core.error.UtpCoreErrorSummary
import com.google.testing.platform.core.error.ext.toErrorDetail
import com.google.testing.platform.core.result.TestSuiteCreator
import com.google.testing.platform.lib.proto.Sanitize.sanitize
import com.google.testing.platform.proto.api.core.ErrorDetailProto.ErrorDetail
import com.google.testing.platform.proto.api.core.IssueProto.Issue
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.proto.api.core.TestCaseProto.TestCase
import com.google.testing.platform.proto.api.core.TestResultProto.TestResult
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.ABORTED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.CANCELLED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.ERROR
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.FAILED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.IGNORED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.IN_PROGRESS
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.PASSED
import com.google.testing.platform.proto.api.core.TestStatusProto.TestStatus.SKIPPED
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteMetaData
import com.google.testing.platform.proto.api.core.TestSuiteResultProto.TestSuiteResult
import com.google.testing.platform.proto.api.core.platformError
import com.google.testing.platform.result.TestSuiteResultExt.determineStatusFromTestStatuses
import com.google.testing.platform.result.TestSuiteResultExt.handleError
import java.lang.IllegalStateException
import javax.inject.Inject

/**
 * Creates a [TestSuiteResult] from multiple [TestResult] protos and returns it when buildTestResult
 * is called.
 */
class TestSuiteCreatorImpl @Inject constructor() : TestSuiteCreator {
  /**
   * The [TestSuiteResult.Builder] object with which all the test and result information will be
   * stored in.
   *
   * Ensure this object is accessed in a thread-safe manner.
   */
  @GuardedBy("this") private val testSuiteResultBuilder = TestSuiteResult.newBuilder()

  @Synchronized
  override fun addTestSuiteMetadata(testSuiteMetaData: TestSuiteMetaData) {
    if (!testSuiteResultBuilder.hasTestSuiteMetaData()) {
      testSuiteResultBuilder.testStatus = IN_PROGRESS
    }
    testSuiteResultBuilder.testSuiteMetaDataBuilder.mergeFrom(testSuiteMetaData)
  }

  @Synchronized
  override fun addArtifact(artifact: Artifact) {
    testSuiteResultBuilder.addOutputArtifact(artifact)
  }

  @Synchronized
  override fun addTestResult(testResult: TestResult): Boolean {
    for (result in testSuiteResultBuilder.testResultBuilderList) {
      if (result.testCase.matches(testResult.testCase)) {
        result.mergeFrom(testResult)
        return false
      }
    }
    testSuiteResultBuilder.addTestResult(testResult)
    return true
  }

  @Synchronized
  override fun addIssue(issue: Issue) {
    testSuiteResultBuilder.addIssue(issue)
  }

  @Synchronized
  override fun setStatus(status: TestStatus) {
    testSuiteResultBuilder.testStatus = status
  }

  @Synchronized
  override fun addError(error: ErrorDetail) {
    testSuiteResultBuilder.platformErrorBuilder.addErrors(error)
  }

  @Synchronized
  override fun addError(error: Throwable) {
    testSuiteResultBuilder.handleError(error)
  }

  @Synchronized
  override fun clearError() {
    testSuiteResultBuilder.clearPlatformError()
  }

  @Synchronized
  override fun buildTestSuiteResult(inProgress: Boolean): TestSuiteResult {
    val currentTestStatus = testSuiteResultBuilder.testStatus
    // Keep the ordering of check below in the order priority of TestStatuses, i.e.,
    // ABORTED > ERROR > FAILED > CANCELLED | IGNORED > PASSED | SKIPPED
    when {
      // ABORTED is from an external signal. Keep as is as platformErrors could be attached in this
      // state too.
      currentTestStatus == ABORTED -> Unit
      // Flip to ERROR status if there are any platformErrors set.
      testSuiteResultBuilder.hasPlatformError() -> testSuiteResultBuilder.testStatus = ERROR
      // When retrieving a draft copy, IN_PROGRESS should remain so.
      currentTestStatus == IN_PROGRESS ->
        if (!inProgress) testSuiteResultBuilder.determineStatusFromTestStatuses()
      // This should ideally never happen, signifies there's an extension (TestDriver or HostPlugin)
      // misbehaving.
      currentTestStatus !in TERMINAL_TEST_STATUSES -> {
        val platformError = platformError {
          errors +=
            IllegalStateException(
                "Illegal test_status while generating final " +
                  "TestSuiteResult: ${testSuiteResultBuilder.testStatus}"
              )
              .toErrorDetail(UtpCoreErrorSummary.ILLEGAL_TEST_STATUS)
        }
        testSuiteResultBuilder.platformError = platformError
        testSuiteResultBuilder.testStatus = ERROR
      }
    }
    return testSuiteResultBuilder.build().sanitize()
  }

  private companion object {
    // Final status that can be reported
    val TERMINAL_TEST_STATUSES = setOf(ERROR, ABORTED, CANCELLED, SKIPPED, IGNORED, FAILED, PASSED)
  }
}

private fun TestCase.matches(other: TestCase): Boolean {
  return testClass == other.testClass &&
    testPackage == other.testPackage &&
    testMethod == other.testMethod &&
    device == other.device
}
