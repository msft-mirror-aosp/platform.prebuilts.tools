package com.google.testing.platform.service.inject;

import com.google.testing.platform.service.RunnerManager;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.Generated;
import javax.inject.Provider;
import kotlinx.coroutines.CoroutineScope;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RunnerServiceModule_ProvideRunnerManagerFactory implements Factory<RunnerManager> {
  private final RunnerServiceModule module;

  private final Provider<CoroutineScope> rootCoroutineScopeProvider;

  public RunnerServiceModule_ProvideRunnerManagerFactory(RunnerServiceModule module,
      Provider<CoroutineScope> rootCoroutineScopeProvider) {
    this.module = module;
    this.rootCoroutineScopeProvider = rootCoroutineScopeProvider;
  }

  @Override
  public RunnerManager get() {
    return provideRunnerManager(module, rootCoroutineScopeProvider.get());
  }

  public static RunnerServiceModule_ProvideRunnerManagerFactory create(RunnerServiceModule module,
      Provider<CoroutineScope> rootCoroutineScopeProvider) {
    return new RunnerServiceModule_ProvideRunnerManagerFactory(module, rootCoroutineScopeProvider);
  }

  public static RunnerManager provideRunnerManager(RunnerServiceModule instance,
      CoroutineScope rootCoroutineScope) {
    return Preconditions.checkNotNullFromProvides(instance.provideRunnerManager(rootCoroutineScope));
  }
}
