/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin.android

import com.google.auto.service.AutoService
import com.google.testing.platform.api.config.parseConfig
import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.context.config
import com.google.testing.platform.api.context.events
import com.google.testing.platform.api.device.CommandResult
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.event.send
import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.api.plugin.PluginException
import com.google.testing.platform.api.plugins.PluginConfigImpl
import com.google.testing.platform.core.plugin.PluginErrorSummary
import com.google.testing.platform.lib.logging.jvm.getLogger
import com.google.testing.platform.plugin.android.proto.AndroidDevicePluginProto.AndroidDevicePlugin as AndroidDevicePluginConfig
import com.google.testing.platform.plugin.android.proto.AndroidDevicePluginProto.AndroidDevicePluginArtifactsInstalled
import com.google.testing.platform.plugin.android.proto.androidDevicePluginArtifactsInstalled
import com.google.testing.platform.plugin.annotations.OrderProvides
import com.google.testing.platform.plugin.common.BaseHostPlugin
import com.google.testing.platform.proto.api.core.TestArtifactProto.Artifact
import com.google.testing.platform.runtime.android.controller.ext.installMultiPackage
import com.google.testing.platform.runtime.android.device.AndroidDeviceProperties
import java.time.Duration

/** Base implementation of the Android device plugin. */
@AutoService(HostPlugin::class)
class AndroidDevicePlugin : HostPlugin by BaseHostPlugin() {
  private lateinit var context: Context
  private lateinit var installables: Set<Artifact>
  private lateinit var installConfig: AndroidDevicePluginConfig
  private lateinit var adbPath: String

  companion object {
    @JvmStatic private val logger = getLogger()
  }

  /** Reads installables from configuration. */
  override fun configure(context: Context) {
    this.context = context
    val config = context.config
    config as PluginConfigImpl
    installables = config.setup.installables
    if (installables.isEmpty()) {
      logger.info("No installables found in test fixture. Nothing to install.")
    }
    adbPath = config.androidSdk.adbPath
    installConfig = config.parseConfig() ?: AndroidDevicePluginConfig.getDefaultInstance()
  }

  /** Installs all installables on the device. */
  @OrderProvides(message = AndroidDevicePluginArtifactsInstalled::class)
  override fun beforeAll(deviceController: DeviceController) {
    val timeout =
      installConfig.installApkTimeout.seconds.takeIf { it > 0 }?.let { Duration.ofSeconds(it) }
    if (installConfig.installMultiPackage) {
      logger.fine("Treat APKs as multi-package.")
      if (deviceController.installMultiPackage(installables, timeout).statusCode != 0) {
        throw PluginException(
          PluginErrorSummary.PLUGIN_ERROR,
          "Failed to install APKs with 'install-multi-package': " +
            "${installables.map { it.sourcePath.path }}"
        )
      }
    } else {
      installables.forEach { artifact ->
        logger.fine("Installing APK: ${artifact.sourcePath.path}")
        if (deviceController.install(artifact).statusCode != 0) {
          throw PluginException(
            PluginErrorSummary.PLUGIN_ERROR,
            "Failed to install APK: ${artifact.sourcePath.path}"
          )
        }
      }
    }

    // Install test services.
    installConfig.testServiceApksList.forEach { artifact ->
      // Using more verbose logging since this isn't a common thing to do.
      logger.info("Installing Test Service APK: ${artifact.sourcePath.path}")
      val result = deviceController.installTestService(artifact)
      if (result.statusCode != 0) {
        throw PluginException(
          PluginErrorSummary.PLUGIN_ERROR,
          "Failed to install Test Service APK: ${artifact.sourcePath.path}"
        )
      }
    }

    // Install test APKs.
    val defaultInstallOptions = listOf("-r", "-t")
    val apiLevel =
      (deviceController.getDevice().properties as AndroidDeviceProperties).deviceApiLevel.toInt()
    installConfig.testApksList.forEach { installableApk ->
      logger.info("Installing APK: ${installableApk.testApk.sourcePath.path}")
      val additionalInstallOptions =
        installableApk.installOptionsList
          .filter { it.minDeviceApiLevel <= apiLevel }
          .map { it.commandLineParameter }
      val installOptions = defaultInstallOptions + additionalInstallOptions
      val result = deviceController.installApk(installableApk.testApk, installOptions)
      if (result.statusCode != 0) {
        throw PluginException(
          PluginErrorSummary.PLUGIN_ERROR,
          "Failed to install APK: ${installableApk.testApk.sourcePath.path}, " +
            "with option ${installOptions.joinToString(",")}"
        )
      }
    }
    context.events.send(androidDevicePluginArtifactsInstalled {})
  }

  /**
   * Regular [DeviceController.install] doesn't take additional arguments, so we need to do a custom
   * install here.
   */
  private fun DeviceController.installTestService(apk: Artifact): CommandResult {
    val apiLevel = (this.getDevice().properties as AndroidDeviceProperties).deviceApiLevel.toInt()
    val grantPermissions = apiLevel >= 23
    val addForceQueryable = apiLevel >= 30
    return this.installApk(
      apk = apk,
      installOptions =
        listOfNotNull(
          "-r",
          "-t",
          "-g".takeIf { grantPermissions },
          "--force-queryable".takeIf { addForceQueryable },
        )
    )
  }

  /**
   * Regular [DeviceController.install] uses hard coded install options, so we need to do a custom
   * install here.
   */
  private fun DeviceController.installApk(
    apk: Artifact,
    installOptions: List<String>
  ): CommandResult {
    val timeout =
      installConfig.installApkTimeout.seconds.takeIf { it > 0 }?.let { Duration.ofSeconds(it) }
    return this.execute(
      args =
        mutableListOf("install").apply {
          addAll(installOptions)
          add(apk.sourcePath.path)
        },
      timeout = timeout
    )
  }
}
