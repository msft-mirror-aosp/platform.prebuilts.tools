/*
 * Copyright (C) 2021 Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.testing.platform.plugin.common

import com.google.testing.platform.api.context.Context
import com.google.testing.platform.api.device.DeviceController
import com.google.testing.platform.api.plugin.HostPlugin
import com.google.testing.platform.proto.api.core.TestCaseProto
import com.google.testing.platform.proto.api.core.TestResultProto
import com.google.testing.platform.proto.api.core.TestSuiteResultProto

/**
 * A default no-op plugin which can be used as a delegate plugin.
 *
 * Can be used by [HostPlugin] implementors to delegate no-op operations to this class.
 */
class BaseHostPlugin : HostPlugin {

  /** No-op method. */
  override fun configure(context: Context) = Unit

  /** No-op method. */
  override fun beforeAll(deviceController: DeviceController) = Unit

  /** No-op method. */
  override fun beforeEach(testCase: TestCaseProto.TestCase?, deviceController: DeviceController) =
    Unit

  /**
   * No-op method.
   */
  override fun afterEach(
    testResult: TestResultProto.TestResult,
    deviceController: DeviceController,
    cancelled: Boolean
  ) = Unit

  /** No-op method. */
  override fun afterAll(
    testSuiteResult: TestSuiteResultProto.TestSuiteResult,
    deviceController: DeviceController,
    cancelled: Boolean
  ) = Unit

  /** Default Host plugin can always run. */
  override fun canRun() = true
}
