package com.google.turbine.binder;

import java.util.regex.Pattern;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Processing_SupportedAnnotationTypes extends Processing.SupportedAnnotationTypes {

  private final boolean everything;

  private final Pattern pattern;

  AutoValue_Processing_SupportedAnnotationTypes(
      boolean everything,
      Pattern pattern) {
    this.everything = everything;
    if (pattern == null) {
      throw new NullPointerException("Null pattern");
    }
    this.pattern = pattern;
  }

  @Override
  boolean everything() {
    return everything;
  }

  @Override
  Pattern pattern() {
    return pattern;
  }

  @Override
  public String toString() {
    return "SupportedAnnotationTypes{"
        + "everything=" + everything + ", "
        + "pattern=" + pattern
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Processing.SupportedAnnotationTypes) {
      Processing.SupportedAnnotationTypes that = (Processing.SupportedAnnotationTypes) o;
      return this.everything == that.everything()
          && this.pattern.equals(that.pattern());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= everything ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= pattern.hashCode();
    return h$;
  }

}
