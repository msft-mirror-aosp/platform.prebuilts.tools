package com.google.turbine.lower;

import com.google.turbine.options.LanguageVersion;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Lower_LowerOptions extends Lower.LowerOptions {

  private final LanguageVersion languageVersion;

  private final boolean emitPrivateFields;

  private AutoValue_Lower_LowerOptions(
      LanguageVersion languageVersion,
      boolean emitPrivateFields) {
    this.languageVersion = languageVersion;
    this.emitPrivateFields = emitPrivateFields;
  }

  @Override
  public LanguageVersion languageVersion() {
    return languageVersion;
  }

  @Override
  public boolean emitPrivateFields() {
    return emitPrivateFields;
  }

  @Override
  public String toString() {
    return "LowerOptions{"
        + "languageVersion=" + languageVersion + ", "
        + "emitPrivateFields=" + emitPrivateFields
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Lower.LowerOptions) {
      Lower.LowerOptions that = (Lower.LowerOptions) o;
      return this.languageVersion.equals(that.languageVersion())
          && this.emitPrivateFields == that.emitPrivateFields();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= languageVersion.hashCode();
    h$ *= 1000003;
    h$ ^= emitPrivateFields ? 1231 : 1237;
    return h$;
  }

  static final class Builder extends Lower.LowerOptions.Builder {
    private LanguageVersion languageVersion;
    private Boolean emitPrivateFields;
    Builder() {
    }
    @Override
    public Lower.LowerOptions.Builder languageVersion(LanguageVersion languageVersion) {
      if (languageVersion == null) {
        throw new NullPointerException("Null languageVersion");
      }
      this.languageVersion = languageVersion;
      return this;
    }
    @Override
    public Lower.LowerOptions.Builder emitPrivateFields(boolean emitPrivateFields) {
      this.emitPrivateFields = emitPrivateFields;
      return this;
    }
    @Override
    public Lower.LowerOptions build() {
      String missing = "";
      if (this.languageVersion == null) {
        missing += " languageVersion";
      }
      if (this.emitPrivateFields == null) {
        missing += " emitPrivateFields";
      }
      if (!missing.isEmpty()) {
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_Lower_LowerOptions(
          this.languageVersion,
          this.emitPrivateFields);
    }
  }

}
