package com.google.turbine.type;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.google.errorprone.annotations.concurrent.LazyInit;
import com.google.turbine.binder.sym.TyVarSymbol;
import java.lang.Object;
import java.lang.Override;
import java.lang.SuppressWarnings;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.extension.memoized.processor.MemoizeExtension")
final class AutoValue_Type_MethodTy extends $AutoValue_Type_MethodTy {
  @LazyInit
  @SuppressWarnings("Immutable")
  private transient volatile int hashCode;

  @LazyInit
  @SuppressWarnings("Immutable")
  private transient volatile boolean hashCode$Memoized;

  AutoValue_Type_MethodTy(ImmutableSet<TyVarSymbol> tyParams$, Type returnType$,
      @Nullable Type receiverType$, ImmutableList<Type> parameters$, ImmutableList<Type> thrown$) {
    super(tyParams$, returnType$, receiverType$, parameters$, thrown$);
  }

  @Override
  public int hashCode() {
    if (!hashCode$Memoized) {
      synchronized (this) {
        if (!hashCode$Memoized) {
          hashCode = super.hashCode();
          hashCode$Memoized = true;
        }
      }
    }
    return hashCode;
  }

  @Override
  public boolean equals(Object that) {
    if (this == that) {
      return true;
    }
    return that instanceof AutoValue_Type_MethodTy && this.hashCode() == that.hashCode() && super.equals(that);
  }
}
