package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_FormalParameterTarget extends ClassFile.TypeAnnotationInfo.FormalParameterTarget {

  private final int index;

  AutoValue_ClassFile_TypeAnnotationInfo_FormalParameterTarget(
      int index) {
    this.index = index;
  }

  @Override
  public int index() {
    return index;
  }

  @Override
  public String toString() {
    return "FormalParameterTarget{"
        + "index=" + index
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.FormalParameterTarget) {
      ClassFile.TypeAnnotationInfo.FormalParameterTarget that = (ClassFile.TypeAnnotationInfo.FormalParameterTarget) o;
      return this.index == that.index();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= index;
    return h$;
  }

}
