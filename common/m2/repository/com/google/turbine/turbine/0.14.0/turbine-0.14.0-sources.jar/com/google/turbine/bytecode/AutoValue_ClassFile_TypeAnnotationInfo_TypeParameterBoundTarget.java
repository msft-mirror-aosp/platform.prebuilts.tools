package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_TypeParameterBoundTarget extends ClassFile.TypeAnnotationInfo.TypeParameterBoundTarget {

  private final int typeParameterIndex;

  private final int boundIndex;

  AutoValue_ClassFile_TypeAnnotationInfo_TypeParameterBoundTarget(
      int typeParameterIndex,
      int boundIndex) {
    this.typeParameterIndex = typeParameterIndex;
    this.boundIndex = boundIndex;
  }

  @Override
  public int typeParameterIndex() {
    return typeParameterIndex;
  }

  @Override
  public int boundIndex() {
    return boundIndex;
  }

  @Override
  public String toString() {
    return "TypeParameterBoundTarget{"
        + "typeParameterIndex=" + typeParameterIndex + ", "
        + "boundIndex=" + boundIndex
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.TypeParameterBoundTarget) {
      ClassFile.TypeAnnotationInfo.TypeParameterBoundTarget that = (ClassFile.TypeAnnotationInfo.TypeParameterBoundTarget) o;
      return this.typeParameterIndex == that.typeParameterIndex()
          && this.boundIndex == that.boundIndex();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= typeParameterIndex;
    h$ *= 1000003;
    h$ ^= boundIndex;
    return h$;
  }

}
