package com.google.turbine.type;

import com.google.common.collect.ImmutableList;
import com.google.errorprone.annotations.concurrent.LazyInit;
import com.google.turbine.binder.sym.ClassSymbol;
import java.lang.Object;
import java.lang.Override;
import java.lang.SuppressWarnings;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.extension.memoized.processor.MemoizeExtension")
final class AutoValue_Type_ClassTy_SimpleClassTy extends $AutoValue_Type_ClassTy_SimpleClassTy {
  @LazyInit
  @SuppressWarnings("Immutable")
  private transient volatile int hashCode;

  @LazyInit
  @SuppressWarnings("Immutable")
  private transient volatile boolean hashCode$Memoized;

  AutoValue_Type_ClassTy_SimpleClassTy(ClassSymbol sym, ImmutableList<Type> targs,
      ImmutableList<AnnoInfo> annos) {
    super(sym, targs, annos);
  }

  @Override
  public int hashCode() {
    if (!hashCode$Memoized) {
      synchronized (this) {
        if (!hashCode$Memoized) {
          hashCode = super.hashCode();
          hashCode$Memoized = true;
        }
      }
    }
    return hashCode;
  }

  @Override
  public boolean equals(Object that) {
    if (this == that) {
      return true;
    }
    return that instanceof AutoValue_Type_ClassTy_SimpleClassTy && this.hashCode() == that.hashCode() && super.equals(that);
  }
}
