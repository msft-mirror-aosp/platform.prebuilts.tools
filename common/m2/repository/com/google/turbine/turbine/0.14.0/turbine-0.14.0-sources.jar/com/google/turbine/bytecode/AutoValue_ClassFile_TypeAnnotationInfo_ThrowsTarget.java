package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_ThrowsTarget extends ClassFile.TypeAnnotationInfo.ThrowsTarget {

  private final int index;

  AutoValue_ClassFile_TypeAnnotationInfo_ThrowsTarget(
      int index) {
    this.index = index;
  }

  @Override
  public int index() {
    return index;
  }

  @Override
  public String toString() {
    return "ThrowsTarget{"
        + "index=" + index
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.ThrowsTarget) {
      ClassFile.TypeAnnotationInfo.ThrowsTarget that = (ClassFile.TypeAnnotationInfo.ThrowsTarget) o;
      return this.index == that.index();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= index;
    return h$;
  }

}
