package com.google.turbine.lower;

import com.google.turbine.options.LanguageVersion;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_Lower_LowerOptions extends Lower.LowerOptions {

  private final LanguageVersion languageVersion;

  private final boolean emitPrivateFields;

  private final boolean methodParameters;

  private AutoValue_Lower_LowerOptions(
      LanguageVersion languageVersion,
      boolean emitPrivateFields,
      boolean methodParameters) {
    this.languageVersion = languageVersion;
    this.emitPrivateFields = emitPrivateFields;
    this.methodParameters = methodParameters;
  }

  @Override
  public LanguageVersion languageVersion() {
    return languageVersion;
  }

  @Override
  public boolean emitPrivateFields() {
    return emitPrivateFields;
  }

  @Override
  public boolean methodParameters() {
    return methodParameters;
  }

  @Override
  public String toString() {
    return "LowerOptions{"
        + "languageVersion=" + languageVersion + ", "
        + "emitPrivateFields=" + emitPrivateFields + ", "
        + "methodParameters=" + methodParameters
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof Lower.LowerOptions) {
      Lower.LowerOptions that = (Lower.LowerOptions) o;
      return this.languageVersion.equals(that.languageVersion())
          && this.emitPrivateFields == that.emitPrivateFields()
          && this.methodParameters == that.methodParameters();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= languageVersion.hashCode();
    h$ *= 1000003;
    h$ ^= emitPrivateFields ? 1231 : 1237;
    h$ *= 1000003;
    h$ ^= methodParameters ? 1231 : 1237;
    return h$;
  }

  static final class Builder extends Lower.LowerOptions.Builder {
    private LanguageVersion languageVersion;
    private boolean emitPrivateFields;
    private boolean methodParameters;
    private byte set$0;
    Builder() {
    }
    @Override
    public Lower.LowerOptions.Builder languageVersion(LanguageVersion languageVersion) {
      if (languageVersion == null) {
        throw new NullPointerException("Null languageVersion");
      }
      this.languageVersion = languageVersion;
      return this;
    }
    @Override
    public Lower.LowerOptions.Builder emitPrivateFields(boolean emitPrivateFields) {
      this.emitPrivateFields = emitPrivateFields;
      set$0 |= (byte) 1;
      return this;
    }
    @Override
    public Lower.LowerOptions.Builder methodParameters(boolean methodParameters) {
      this.methodParameters = methodParameters;
      set$0 |= (byte) 2;
      return this;
    }
    @Override
    public Lower.LowerOptions build() {
      if (set$0 != 3
          || this.languageVersion == null) {
        StringBuilder missing = new StringBuilder();
        if (this.languageVersion == null) {
          missing.append(" languageVersion");
        }
        if ((set$0 & 1) == 0) {
          missing.append(" emitPrivateFields");
        }
        if ((set$0 & 2) == 0) {
          missing.append(" methodParameters");
        }
        throw new IllegalStateException("Missing required properties:" + missing);
      }
      return new AutoValue_Lower_LowerOptions(
          this.languageVersion,
          this.emitPrivateFields,
          this.methodParameters);
    }
  }

}
