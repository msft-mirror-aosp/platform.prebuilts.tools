package com.google.turbine.bytecode;

import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ClassFile_TypeAnnotationInfo_TypePath extends ClassFile.TypeAnnotationInfo.TypePath {

  private final int typeArgumentIndex;

  private final ClassFile.TypeAnnotationInfo.TypePath.@Nullable Kind kind;

  private final ClassFile.TypeAnnotationInfo.@Nullable TypePath parent;

  AutoValue_ClassFile_TypeAnnotationInfo_TypePath(
      int typeArgumentIndex,
      ClassFile.TypeAnnotationInfo.TypePath.@Nullable Kind kind,
      ClassFile.TypeAnnotationInfo.@Nullable TypePath parent) {
    this.typeArgumentIndex = typeArgumentIndex;
    this.kind = kind;
    this.parent = parent;
  }

  @Override
  public int typeArgumentIndex() {
    return typeArgumentIndex;
  }

  @Override
  public ClassFile.TypeAnnotationInfo.TypePath.@Nullable Kind kind() {
    return kind;
  }

  @Override
  public ClassFile.TypeAnnotationInfo.@Nullable TypePath parent() {
    return parent;
  }

  @Override
  public String toString() {
    return "TypePath{"
        + "typeArgumentIndex=" + typeArgumentIndex + ", "
        + "kind=" + kind + ", "
        + "parent=" + parent
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ClassFile.TypeAnnotationInfo.TypePath) {
      ClassFile.TypeAnnotationInfo.TypePath that = (ClassFile.TypeAnnotationInfo.TypePath) o;
      return this.typeArgumentIndex == that.typeArgumentIndex()
          && (this.kind == null ? that.kind() == null : this.kind.equals(that.kind()))
          && (this.parent == null ? that.parent() == null : this.parent.equals(that.parent()));
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= typeArgumentIndex;
    h$ *= 1000003;
    h$ ^= (kind == null) ? 0 : kind.hashCode();
    h$ *= 1000003;
    h$ ^= (parent == null) ? 0 : parent.hashCode();
    return h$;
  }

}
