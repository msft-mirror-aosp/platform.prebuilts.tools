package com.google.turbine.options;

import java.util.OptionalInt;
import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_LanguageVersion extends LanguageVersion {

  private final int source;

  private final int target;

  private final OptionalInt release;

  AutoValue_LanguageVersion(
      int source,
      int target,
      OptionalInt release) {
    this.source = source;
    this.target = target;
    if (release == null) {
      throw new NullPointerException("Null release");
    }
    this.release = release;
  }

  @Override
  public int source() {
    return source;
  }

  @Override
  public int target() {
    return target;
  }

  @Override
  public OptionalInt release() {
    return release;
  }

  @Override
  public String toString() {
    return "LanguageVersion{"
        + "source=" + source + ", "
        + "target=" + target + ", "
        + "release=" + release
        + "}";
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof LanguageVersion) {
      LanguageVersion that = (LanguageVersion) o;
      return this.source == that.source()
          && this.target == that.target()
          && this.release.equals(that.release());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= source;
    h$ *= 1000003;
    h$ ^= target;
    h$ *= 1000003;
    h$ ^= release.hashCode();
    return h$;
  }

}
